# HTMLTrust Study 1 v0.2 post-fix results

> Historical v0.2 measurement. This file is retained for comparison and is not
> the current v0.3 result set. See [`README.md`](README.md) for the current
> workflow.

Corpus: **5146** real news-article body regions (Common Crawl CC-NEWS). Implementations: python, js, go, rust, php.

## E1 — Cross-implementation canonicalization on real HTML

### Per-implementation success rate (fraction of pages that canonicalize without error)

| implementation | success rate |
|---|---|
| python | 100.0% |
| js | 99.8% |
| go | 99.3% |
| rust | 99.8% |
| php | 99.0% |

**All five succeed AND agree byte-for-byte: 1589/5067 of mutually-successful pages = 31.4%.**

### Pairwise byte-identical agreement (among pages both implementations canonicalized)

| pair | both ok | agree | rate |
|---|---|---|---|
| python-js | 5137 | 1727 | 33.6% |
| python-go | 5110 | 3329 | 65.1% |
| python-rust | 5135 | 1796 | 35.0% |
| python-php | 5097 | 2323 | 45.6% |
| js-go | 5104 | 2292 | 44.9% |
| js-rust | 5135 | 3896 | 75.9% |
| js-php | 5095 | 2910 | 57.1% |
| go-rust | 5102 | 2022 | 39.6% |
| go-php | 5068 | 2148 | 42.4% |
| rust-php | 5095 | 2394 | 47.0% |

### Failure reasons

- **python**: `ValueError: Port out of range 0-65535` ×1; `ValueError: attribute-canonicalization-failed` ×1
- **js**: `attribute-canonicalization-failed: a.href` ×8; `attribute-canonicalization-failed: img.src` ×1
- **go**: `attribute-canonicalization-failed: a.href: parse "https://www.poslovni.hr/hrvatska/stizu-nove-financijske-naknade-od-110-eura-pa-i-vise-evo-tko-sve-zadovoljava-` ×3; `attribute-canonicalization-failed: a.href: parse "mailto:stics@sph.com.sg?subject=Reach%20Us&body=--%0D%0A\n  Your browser info has automatically been included ` ×2; `attribute-canonicalization-failed: a.href: parse "mailto:#?subject=Pluxee N.V. (PLXNF) Price Target Decreased by 21.60% to 24.69&body=From%20Nasdaq.com%0a%0aThe` ×1; `attribute-canonicalization-failed: img.src: parse "data:image/svg+xml,%3Csvg\n    xmlns='http://www.w3.org/2000/svg'\n    viewBox='0 0 3 2'%3E%3C/svg%3E": net/u` ×1; `attribute-canonicalization-failed: a.href: parse "%groupUnsubscribeUrl%": invalid URL escape "%gr"` ×1; `attribute-canonicalization-failed: img.src: parse "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 6\n                1'%3E%3C/svg%3E"` ×1
- **rust**: `attribute-canonicalization-failed` ×11
- **php**: `InvalidArgumentException: attribute-canonicalization-failed` ×49

### Disagreement taxonomy (each implementation vs the `rust` reference)

Counts of disagreeing records bucketed by the first meaningful difference.

| category | python | js | go | php |
|---|---|---|---|---|
| attr-other | 6 | 70 | 44 | 86 |
| attr-presence | 0 | 5 | 1 | 0 |
| content-length | 11 | 101 | 19 | 29 |
| entity | 0 | 10 | 10 | 11 |
| identical | 207 | 2307 | 433 | 805 |
| ok-status-divergence | 9 | 2 | 43 | 42 |
| structure | 200 | 288 | 254 | 290 |
| text-other | 299 | 429 | 330 | 482 |
| url-scheme | 190 | 33 | 168 | 229 |
| url-serialization | 2633 | 303 | 2254 | 1574 |

## E2 — Canonicalization stability under benign transformations

Measured on 5144 pages that canonicalize successfully. Preservation = fraction whose canonical hash is unchanged after the transform (1 − preservation is a false-negative source for signed content).

| transformation | preservation rate |
|---|---|
| reserialize_htmlparser | 94.4% |
| reserialize_lxml | 87.5% |
| whitespace_reflow | 25.4% |
| lowercase_tags | 100.0% |
