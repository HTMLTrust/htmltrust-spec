# Study 1 v0.2 results

> Historical record. This report predates the v0.3 corpus workflow and does
> not report the current v0.3 run. Use the repository README for reproduction
> instructions. Current output is generated under `STUDY1_DATA/runs/`.

The v0.2 corpus and measurements below are retained for round-history and
comparison. They are not a uniform sample of the web or of Common Crawl.

**Corpus:** 5,146 real news-article `<body>` regions, deterministically sampled from
Common Crawl **CC-NEWS** (crawl window 2026-01-15…02-15). **Implementations:** the
five HTMLTrust canonicalization bindings (JavaScript, Go, Python, Rust, PHP),
pinned in one Docker image (Node 22.23.1, Go 1.26, Rust 1.90, Python 3.12.13,
PHP 8.2.32). Reproduce with `make all`.

## Headline

The paper's core engineering claim — *byte-identical canonicalization across
independent implementations* — **passes on 54 synthetic conformance fixtures and
fails on the real web.** On real news HTML, before the fixes this study drove:

- The five implementations produced byte-identical output on only **20.0%** of the
  pages they all canonicalized successfully.
- Three of the five (Python, Go, PHP) **failed outright on ~53% of pages**, because
  real pages routinely contain `mailto:`/`tel:`/`javascript:`/`data:` URLs that the
  WHATWG-based bindings (JS, Rust) accept but the other three rejected.
- Running PHP in Docker (the first time the hand-written PHP binding was ever
  executed) revealed it agreed with the others only **~25%** of the time — its
  relative-URL resolver silently truncated paths on fragment-only links.

The study found two genuine, previously-invisible bugs, fixed both, and re-ran on
the same corpus to quantify the improvement.

## E1 — Cross-implementation agreement (baseline, buggy libraries)

### Per-implementation success rate

| implementation | success rate |
|---|---|
| python | 46.5% |
| js | 99.8% |
| go | 46.3% |
| rust | 99.8% |
| php | 46.4% |

**All five succeed *and* agree byte-for-byte: 471 / 2,356 mutually-successful pages = 20.0%.**

### Pairwise byte-identical agreement (selected)

| pair | rate | note |
|---|---|---|
| js ↔ rust | **75.9%** | the two WHATWG + real-parser bindings agree most |
| python ↔ go | 65.3% | |
| js ↔ php | 35.8% | |
| rust ↔ php | 24.8% | PHP is the outlier |

### Why they diverge — disagreement taxonomy (vs the Rust reference)

| category | what it is | scale |
|---|---|---|
| `ok-status-divergence` | one binding errors where another succeeds | ~2,750 (dominant) — opaque URL schemes |
| `url-serialization` | http(s) URLs serialize to different bytes | php 1,290 · py 1,153 · go 1,070 · js 303 |
| `structure` / `text-other` | regex tokenizer vs real HTML parser (implied end tags, mis-nesting) | ~hundreds |
| `url-scheme`, `entity`, `whitespace` | smaller buckets | tens |

The two dominant causes are both URL handling; the residual (`structure`) is the
regex-vs-real-parser differential that the paper already flags as a limitation.

## Two bugs found → fixed → re-measured

1. **Opaque URL schemes rejected (Python, Go, PHP).** The three netloc-requiring
   bindings raised `attribute-canonicalization-failed` on `mailto:`/`tel:`/
   `javascript:`/`data:`/`about:` URLs. The draft mandates the WHATWG URL
   serializer, which *accepts* these (`new URL("mailto:a@b").href` succeeds). Fix:
   accept opaque URLs and serialize them verbatim (scheme lowercased), matching
   `new URL().href`. Effect: Python/Go/PHP success rate ~46% → ~99%.
2. **PHP relative-URL resolver truncated paths.** PHP's hand-written resolver
   treated a fragment-only href `#x` as a path reference, stripping the last base
   segment (`.../article/1-20#x` → `.../article/#x`). Fix: replaced it with a
   correct RFC 3986 §5.2 transform-reference algorithm. Effect: PHP↔JS agreement
   ~28% → ~71% (measured on a 300-page probe; confirmed at scale below).

Both fixes keep all 54 synthetic conformance fixtures green, including PHP, which
now runs the conformance suite in Docker for the first time.

## E1 — Cross-implementation agreement (post-fix, same 5,146-page corpus)

### Success rate: the catastrophic failures are gone

| implementation | baseline | post-fix |
|---|---|---|
| python | 46.5% | **100.0%** |
| go | 46.3% | **99.3%** |
| php | 46.4% | **99.0%** |
| js | 99.8% | 99.8% |
| rust | 99.8% | 99.8% |

The opaque-URL fix eliminated the ~53% failure rate. Remaining failures are a
handful of genuinely malformed URLs (embedded newlines, `mailto:#…`, invalid
`%` escapes) that individual parsers reject — tens of pages, not thousands.

### Byte-identical agreement improved, but full agreement is still not reached

| metric | baseline | post-fix |
|---|---|---|
| **all five agree byte-for-byte** | 20.0% | **31.4%** |
| js ↔ rust (both native WHATWG + real parser) | 75.9% | 75.9% |
| js ↔ php | 35.8% | **57.1%** |
| rust ↔ php | 24.8% | **47.0%** |
| python ↔ go | 65.3% | 65.1% |

The PHP resolver fix roughly doubled PHP's agreement with the WHATWG bindings.
But **only 31.4% of real pages produce byte-identical output across all five
implementations even after the fixes**, and the best pair (js↔rust) is stuck at
76%.

### What's left — the residual disagreement is URL serialization and parsing

With the failures removed, more pages become comparable, and the dominant
remaining disagreement category (vs the Rust reference) is now **`url-serialization`**:
python 2,633 · go 2,254 · php 1,574 · js 303. The hand-rolled URL canonicalizers in
Python/Go/PHP (`urllib` / `net/url` / `parse_url` + manual dot-segment and IDNA
handling) still do **not** byte-match a true WHATWG serializer (`new URL`, the Rust
`url` crate) on real http(s) URLs — differences in percent-encoding, IDNA/UTS-46,
trailing-dot hosts, and path normalization. The next-largest categories are
`structure` and `text-other` (~200–480 each), which are the **regex-tokenizer vs
real-HTML-parser** differential — js↔rust are both WHATWG yet still disagree 24% of
the time for exactly this reason.

**So the fixes closed the two show-stoppers this study found, but they did not make
canonicalization byte-identical on the real web.** Achieving that requires (a) a
single shared WHATWG URL serializer rather than five per-language re-implementations,
and (b) a real HTML parser in every trust-gating binding rather than a regex
tokenizer. Both are now concrete, evidence-backed work items.

## E2 — Canonicalization stability under benign transformations

Measured on the 2,391 pages that canonicalize successfully. Preservation = fraction
whose canonical hash is unchanged after the transform; (1 − preservation) is a
false-negative source for signed content.

| transformation | preservation | interpretation |
|---|---|---|
| `reserialize_htmlparser` | 94.9% | same-parser round-trip; ~5% still shifts |
| `reserialize_lxml` | **89.6%** | **a *different* HTML parser's round-trip breaks the hash ~10% of the time** — the realistic CMS-reparse false-negative |
| `whitespace_reflow` | 25.9% | naive reindentation between inline elements changes rendered text; the hash *should* change, so this is mostly legitimate, not a pure false-negative |
| `lowercase_tags` | 100.0% | tag-case normalization is safe |

The load-bearing number is `reserialize_lxml` ≈ **90%**: a publisher whose CMS
re-parses and re-serializes signed HTML with a different HTML5 parser than the
signer used will see roughly one in ten signatures fail even though nothing a
reader sees has changed.

## Conclusion (for the paper)

- The "byte-identical across implementations" property is real for clean, synthetic
  inputs and **false for real-world HTML**. On 5,146 real pages, byte-identical
  agreement across all five implementations was 20% before the fixes and **31% after
  them**; the best-agreeing pair reaches only 76%.
- The two show-stoppers this study found are now fixed: opaque URL schemes
  (`mailto:`/`tel:`/`javascript:`/`data:`), which had made three of five bindings fail
  on ~53% of real pages, and PHP's broken relative-URL resolver. Success rates went
  from ~46% to ~99% for Python/Go/PHP.
- Full byte-identity remains **unachieved** and now has two concrete, evidence-backed
  causes: (a) the URL serializer is re-implemented five times (`urllib`/`net-url`/
  `parse_url` + hand-rolled dot-segment/IDNA logic) and these do not byte-match a true
  WHATWG serializer on real http URLs — the fix is one shared WHATWG implementation,
  not five; and (b) three bindings tokenize HTML with regexes rather than a real
  parser, which is why even the two WHATWG bindings disagree 24% of the time.
- Real-world **canonicalization stability** under a benign cross-parser reparse is
  ~88–90%: a materially non-zero false-negative rate a deployment must account for
  (e.g. by verifying the original server-response snapshot, not post-pipeline HTML).

This is the honest answer to "is the actual research ready": the systems artifact is
real, and the first empirical study of it on the open web shows the central
interoperability claim does not yet hold there — which is itself the finding, and it
points at exactly what must change.

## Limitations

- Common Crawl provides *server* HTML, so this study measures cross-implementation
  portability and robustness to server-side/parser transformations. It does **not**
  measure the live-DOM mutation false-negative (client-side script mutating a
  signed region), which needs a headless-browser harness and is separate work.
- The disagreement taxonomy buckets the *first* meaningful difference per record;
  a record may have several. Counts indicate dominant causes, not an exhaustive
  per-difference census.
- The corpus is English-and-European-language-heavy news publishers; other genres
  (forums, wikis, e-commerce) may exercise different constructs.
