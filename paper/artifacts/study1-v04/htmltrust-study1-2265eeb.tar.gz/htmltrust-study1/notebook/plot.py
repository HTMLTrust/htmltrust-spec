#!/usr/bin/env python3
"""Plot the Study 1 round-over-round trajectory from notebook/metrics.csv."""
import csv, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

here = os.path.dirname(os.path.abspath(__file__))
rows = list(csv.DictReader(open(os.path.join(here, "metrics.csv"))))

short = {
    "baseline": "R0\nbaseline\n(5 ports, buggy)",
    "round1": "R1\npatch ports\n(URL fixes)",
    "round2": "R2\nPython→core",
    "round3": "R3\n+Go→core",
    "round4": "R4\n+JS→core (wasm)",
    "round5": "R5\n+PHP→core",
}
x = [short.get(r["round"], r["round"]) for r in rows]
agree = [float(r["all5_agree_rate"]) * 100 for r in rows]
# also plot how many of the 5 languages are byte-identical to the Rust core
def n_core(r):
    t = r["technique"]
    return 1 + sum(t.count(l) for l in ["python", "go", "js", "php"]) if "core via" in t else (0 if r["round"] == "baseline" else 0)
langs_on_core = []
for r in rows:
    if r["round"] in ("baseline", "round1"):
        langs_on_core.append(1)  # only rust is "the core" natively
    else:
        core = r["technique"].split("core via ")[-1]
        langs_on_core.append(1 + sum(1 for l in ["python", "go", "js", "php"] if l in core))

fig, ax1 = plt.subplots(figsize=(10, 5.5))
ax1.plot(range(len(x)), agree, "-o", color="#1f77b4", linewidth=2.5, markersize=8,
         label="all-5 byte-identical agreement")
for i, v in enumerate(agree):
    ax1.annotate(f"{v:.0f}%", (i, v), textcoords="offset points", xytext=(0, 10),
                 ha="center", fontsize=10, color="#1f77b4", fontweight="bold")
ax1.set_ylabel("all-5 byte-identical agreement (%)", color="#1f77b4", fontsize=11)
ax1.set_ylim(0, 108)
ax1.tick_params(axis="y", labelcolor="#1f77b4")
ax1.set_xticks(range(len(x)))
ax1.set_xticklabels(x, fontsize=9)
ax1.grid(True, axis="y", alpha=0.3)

ax2 = ax1.twinx()
ax2.plot(range(len(x)), langs_on_core, "--s", color="#d62728", alpha=0.7,
         label="languages running the shared Rust core")
ax2.set_ylabel("# languages on the shared core (of 5)", color="#d62728", fontsize=11)
ax2.set_ylim(0, 5.4)
ax2.tick_params(axis="y", labelcolor="#d62728")

ax1.set_title("HTMLTrust Study 1 — canonicalization agreement on 5,146 real Common Crawl pages\n"
              "Patching 5 independent ports plateaus; binding every language to one Rust core reaches 100%",
              fontsize=11)
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc="center right", fontsize=9)
fig.tight_layout()
out = os.path.join(here, "agreement_trajectory.png")
fig.savefig(out, dpi=140)
print("wrote", out)
