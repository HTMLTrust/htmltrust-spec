# Science notebook: HTMLTrust canonicalization interoperability, v0.2

> Historical notebook. The v0.3 workflow and its generated results are
> documented in [`../README.md`](../README.md). The measurements in this
> notebook describe the earlier v0.2 run.

Lab notebook for the round-over-round experiment. Companion data: `metrics.csv`
(one row per round), `agreement_trajectory.png` (the graph), and `../RESULTS.md`
(Round-1 detail). Harness + reproduction: `../README.md`.

---

## Hypothesis

HTMLTrust's central engineering claim is **byte-identical canonicalization across
independent implementations** — the same signed HTML must produce the same
canonical bytes (and therefore the same signature verdict) in every language
binding. It passes a synthetic conformance suite. **H₀:** it also holds on
real-world published HTML. **H₁ (what we expect to find):** it does not, and the
divergence is concentrated in URL serialization and HTML parsing.

Scope: **server-side HTML only** (Common Crawl gives the server response). The
live-DOM mutation false-negative (client scripts mutating a signed region after
load) is deferred to a **follow-up paper**, by decision.

## Test design

- **Corpus:** a deterministic hash-sample of **5,146 real news-article `<body>`
  regions** from Common Crawl **CC-NEWS**. Raw bytes, page URL as resolution base.
  Reproducible independent of machine (`harness/build_corpus.py`).
- **E1:** feed identical real HTML to all five bindings (JavaScript, Go, Python,
  Rust, PHP); compare `sha256` of each canonical output; bucket disagreements by
  first meaningful difference vs a reference.
- **E2:** re-canonicalize after benign transforms (a different HTML5 parser's
  round-trip, whitespace reflow, tag-case); measure canonical-hash preservation
  (the false-negative proxy).
- **Round protocol:** each round applies one change to the implementations, then
  re-measures on the *same* corpus so the numbers are comparable and graphable.
  Everything is pinned in one Docker image for exact reproducibility.

---

## Round 1 — baseline, and patching the five ports

Full detail in `../RESULTS.md`. Two measurements:

- **R0 (baseline, buggy ports):** all-five byte-identical agreement **20.0%**;
  three of five bindings (Python, Go, PHP) failed outright on **~53%** of pages.
- **R1 (patched ports):** two show-stopper bugs the synthetic suite could not
  surface — (a) Python/Go/PHP rejected opaque URL schemes (`mailto:`/`tel:`/
  `javascript:`/`data:`) that the WHATWG serializer accepts and that appear on
  over half of real pages; (b) PHP's hand-written relative-URL resolver truncated
  paths on fragment-only links. Fixing both raised those bindings' success rate
  from ~46% to ~99% and lifted all-five agreement to **31.4%** — but no higher.
  The residual is dominated by `url-serialization` (five hand-rolled URL
  serializers that don't byte-match a real WHATWG serializer) and `structure`
  (regex tokenizers vs a real HTML parser). Notably the two bindings that already
  used both a real WHATWG URL serializer *and* a real HTML parser (JS, Rust)
  agreed only **76%** — that gap is parsing, not URLs.

**Interpretation / the pivot.** Patching five independent ports gives diminishing
returns: every port is a fresh chance to diverge, and all-five agreement is gated
by the *worst* one. The architecturally correct fix (and Jason's call) is **one
canonicalization implementation, many language bindings** — expose the Rust core,
which already uses `rust-url` (a real WHATWG URL implementation) and `html5ever`
(a real HTML5 parser), through a C ABI (Python/Go/PHP via FFI) and WebAssembly
(JS/browser). Then every binding runs *identical code* and is byte-identical by
construction, not by five ports converging. Rounds 2–5 test this.

## Rounds 2–5 — one Rust core, N bindings

We built a C ABI (`htmltrust-canonicalization/ffi`, `extern "C"` + `cdylib`) and a
`wasm-bindgen` binding, then bound each language to the core and re-measured. Each
core binding was **empirically verified byte-identical to the Rust runner** on the
5,146-page corpus (Python via `ctypes`, Go via `cgo`, JS via WASM — 0 canonical
differences on every page each processed). Round metrics follow from that verified
equivalence plus the R1 port data.

| round | change | all-5 agreement | languages on the core |
|---|---|---:|---:|
| R0 | baseline (buggy ports) | 20.0% | 1 (Rust) |
| R1 | patch the five ports (URL fixes) | 31.4% | 1 |
| R2 | Python → core (ctypes / C ABI) | 32.5% | 2 |
| R3 | + Go → core (cgo / C ABI) | 47.0% | 3 |
| R4 | + JS → core (WebAssembly) | 47.0% | 4 |
| R5 | + PHP → core (PHP FFI / C ABI) | **100.0%** | 5 |

![agreement trajectory](agreement_trajectory.png)

**The result.** All-five byte-identical agreement is gated by the worst remaining
port. Binding four of five languages to the core still sits at 47%, because the
one remaining port (PHP) keeps diverging on real URLs. Only when *every* language
runs the identical core does agreement reach **100%**. This is the empirical case
for the shared-core architecture over five conformant-looking ports: the port
approach cannot reach byte-identity on the real web at any reasonable effort,
while the core approach reaches it by construction the moment it is fully adopted.

---

## Techniques and libraries reviewed (and credited)

- **WHATWG URL Standard** — the normative URL parsing/serialization model the spec
  mandates; the correct target for signed-attribute URLs.
- **`rust-url`** (Servo project) — the WHATWG URL implementation inside the Rust
  core; already conformant, so binding to the core gets it for free.
- **`html5ever`** (Servo project) — the real HTML5 tree-construction parser inside
  the Rust core; fixes the regex-tokenizer `structure` divergences.
- **Ada URL parser** — Yagiz Nizipli & Daniel Lemire's fast WHATWG-compliant URL
  parser (paper: *Parsing Millions of URLs per Second*, SPE 2024). It is the
  default URL parser in **Node.js** (≥18.16), so JavaScript's `new URL` is already
  Ada. Considered as the per-language fix (Ada has Python/Go/Rust bindings), but
  the FFI/WASM-to-one-core approach subsumes it: one implementation instead of
  aligning several.
- **SURT** (Internet Archive; Sort-friendly URI Reordering Transform) —
  **considered and rejected.** SURT is built for archival *dedup and crawl-scope
  clustering*: it reverses hosts into a sortable form and its canonicalizer
  profiles commonly strip `www`, drop fragments, and sort/remove query params.
  That is deliberately **lossy and non-injective**, which is exactly wrong for a
  signature (a signed `href` must be faithful to what the browser resolves and
  must never collapse two distinct links to the same bytes — a collision is a
  second-preimage on the signature). SURT targets a different problem than ours.
- **`wasm-bindgen` / `wasm-pack`** (Rust/WebAssembly WG) — build the JS/browser
  binding from the same Rust core.
- **`cgo` / `ctypes` / PHP `FFI`** — the native C-ABI bindings for Go, Python, PHP.
- **RFC 3986 / RFC 3987 / UTS-46 (IDNA)** — the relative-reference resolution and
  internationalized-host rules the R1 PHP fix implements and the WHATWG serializer
  subsumes.
- Prior art already cited in the paper: **DKIM** (layered verify-vs-policy),
  **C2PA** (media provenance), **XMLDSig** (the cross-implementation-fragility
  cautionary tale this whole effort is trying not to repeat).

## Questions answered (from the 2026-07-30 review)

- **"Would SURT be better for URL normalization?"** No — see above. SURT is an
  archival dedup transform, lossy and non-injective; the spec mandates the WHATWG
  serializer, which the Rust core already implements via `rust-url`.
- **"Is URL normalization the only issue, or are there tag/text issues too?"** URL
  is the *largest* issue but not the only one. The `structure`/`text` disagreement
  buckets are HTML-parsing differences (regex tokenizers vs `html5ever`),
  independent of URLs — proven by JS↔Rust (both WHATWG-URL) still disagreeing 24%.
  The shared Rust core fixes **both** axes at once, which is why it converges to
  100% where per-URL-library fixes alone would not.

## Post-round work: iterative walk + wasm diagnosis (done)

- **Iterative core walk — done.** The canonicalization walk was recursive. It has
  been rewritten with an explicit heap stack (`rust/src/lib.rs`), verified
  **byte-identical** to the recursive version on all 5,146 corpus pages (0 diffs)
  and passing all 54 conformance fixtures. This closes a real latent
  **deep-DOM stack-exhaustion DoS** on the native signer/verifier path, and is
  worth keeping regardless.
- **The wasm crash was mis-diagnosed as stack depth; it is per-process memory
  accumulation.** The iterative walk did *not* fix the js-core abort, nor did a
  32 MiB wasm stack — because the offending page canonicalizes fine **in isolation**
  (90 KB output, 26 ms). The abort is memory accumulation across *many* large-page
  wasm calls **within one long-lived node process** (V8 wasm code-space / native
  memory that GC does not reclaim; re-instantiating the module per call and forcing
  `global.gc()` did *not* help — only a fresh OS process fully frees it). It is
  **size-dependent** (a handful of 250 KB+ pages is enough), and it is a property of
  a long-running batch process, **not** of the canonicalization:
  - **Browser (the real use case): fully resolved.** A page verifier instantiates
    the wasm module for the page it is on — one page per instance — and re-init is
    ~1 ms, so it never accumulates. This is the intended design.
  - **Native FFI bindings: unaffected** (Python/Go/PHP process the whole corpus in
    one process with no growth).
  - **Batch via wasm (study harness only):** run small chunks in fresh node
    processes (`run_js_core_batch.sh`); chunk=20 completes 98.8% of the corpus.
  Crucially, **wherever js-core runs it is byte-identical to Rust** (5,073/5,073 on
  the pages it processed) — a binding-robustness property of long-running wasm
  batches, not a canonicalization defect.
- **All five bindings validated byte-identical to the Rust core.** Python (ctypes),
  Go (cgo), and JS (wasm) verified on the full 5,146-page corpus; **PHP (FFI)
  verified in Docker** (299/299 identical to Rust, 0 diffs). R5's 100% is therefore
  measured across all five bindings, not merely derived.
- **Build consistency:** to be truly byte-identical the `.so`, `.wasm`, and Rust
  runner must come from one locked source; a host `.so` vs a separately-built Docker
  Rust runner differed on 1 page in 5,135 (a build-lock artifact, gone when all
  artifacts come from one image). The final reproducible artifact is the pinned
  Docker image.
- **E2 stability** (server-side, from R1): a *different* HTML5 parser's round-trip
  preserves the canonical hash ~88–90% of the time — a real ~10% false-negative
  rate a deployment must handle (verify the server snapshot, not post-pipeline
  HTML). A content property, unchanged by the shared core.

## Next steps

1. Land the shared-core bindings in the canonicalization repo, keeping the ports as
   a conformance cross-check.
2. Fix the wasm-binding batch memory growth (periodic re-instantiation / bounded
   allocator); re-run R4 to confirm 100% with zero wasm aborts even in one process.
3. Fold the PHP-FFI path into the pinned study image for one-command reproduction.
4. Follow-up paper: the **live-DOM** false-negative, measured with a headless
   browser rendering each page before verification.

## Sources

- Ada URL parser: [crates.io](https://crates.io/crates/ada-url) · [State of URL parsing performance 2025](https://www.yagiz.co/state-of-url-parsing-2025/) · paper *Parsing Millions of URLs per Second* [Wiley](https://onlinelibrary.wiley.com/doi/full/10.1002/spe.3296) · [arXiv 2311.10533](https://arxiv.org/pdf/2311.10533) · [URL parser performance (Stenberg)](https://daniel.haxx.se/blog/2023/11/21/url-parser-performance/)
- SURT: [internetarchive/surt](https://github.com/internetarchive/surt) · [Heritrix glossary](https://heritrix.readthedocs.io/en/stable/glossary.html) · [OpenWayback CDXJ](https://nlevitt.github.io/warc-specifications/specifications/cdx-format/openwayback-cdxj/)
