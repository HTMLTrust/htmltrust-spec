# HTMLTrust Study 1 v0.2 baseline

> Historical v0.2 measurement. This file is retained for comparison and is not
> the current v0.3 result set. See [`README.md`](README.md) for the current
> workflow.

Corpus: **5146** real news-article body regions (Common Crawl CC-NEWS). Implementations: python, js, go, rust, php.

## E1 — Cross-implementation canonicalization on real HTML

### Per-implementation success rate (fraction of pages that canonicalize without error)

| implementation | success rate |
|---|---|
| python | 46.5% |
| js | 99.8% |
| go | 46.3% |
| rust | 99.8% |
| php | 46.4% |

**All five succeed AND agree byte-for-byte: 471/2356 of mutually-successful pages = 20.0%.**

### Pairwise byte-identical agreement (among pages both implementations canonicalized)

| pair | both ok | agree | rate |
|---|---|---|---|
| python-js | 2390 | 906 | 37.9% |
| python-go | 2356 | 1538 | 65.3% |
| python-rust | 2390 | 957 | 40.0% |
| python-php | 2364 | 755 | 31.9% |
| js-go | 2379 | 1085 | 45.6% |
| js-rust | 5135 | 3896 | 75.9% |
| js-php | 2388 | 854 | 35.8% |
| go-rust | 2379 | 982 | 41.3% |
| go-php | 2379 | 655 | 27.5% |
| rust-php | 2388 | 592 | 24.8% |

### Failure reasons

- **python**: `ValueError: attribute-canonicalization-failed` ×2754; `ValueError: Port out of range 0-65535` ×1
- **js**: `attribute-canonicalization-failed: a.href` ×8; `attribute-canonicalization-failed: img.src` ×1
- **go**: `attribute-canonicalization-failed: a.href: URL must be absolute` ×2080; `attribute-canonicalization-failed: img.src: URL must be absolute` ×637; `attribute-canonicalization-failed: span.href: URL must be absolute` ×17; `attribute-canonicalization-failed: amp-img.src: URL must be absolute` ×11; `attribute-canonicalization-failed: div.href: URL must be absolute` ×3; `attribute-canonicalization-failed: button.href: URL must be absolute` ×3
- **rust**: `attribute-canonicalization-failed` ×11
- **php**: `InvalidArgumentException: attribute-canonicalization-failed` ×2756

### Disagreement taxonomy (each implementation vs the `rust` reference)

Counts of disagreeing records bucketed by the first meaningful difference.

| category | python | js | go | php |
|---|---|---|---|---|
| attr-other | 2 | 70 | 20 | 31 |
| attr-presence | 0 | 5 | 0 | 0 |
| content-length | 5 | 101 | 13 | 12 |
| entity | 0 | 10 | 1 | 2 |
| identical | 486 | 3425 | 511 | 121 |
| ok-status-divergence | 2746 | 2 | 2758 | 2749 |
| structure | 73 | 288 | 113 | 116 |
| text-other | 154 | 429 | 141 | 315 |
| url-scheme | 46 | 33 | 39 | 30 |
| url-serialization | 1153 | 303 | 1070 | 1290 |

## E2 — Canonicalization stability under benign transformations

Measured on 2391 pages that canonicalize successfully. Preservation = fraction whose canonical hash is unchanged after the transform (1 − preservation is a false-negative source for signed content).

| transformation | preservation rate |
|---|---|
| reserialize_htmlparser | 94.9% |
| reserialize_lxml | 89.6% |
| whitespace_reflow | 25.9% |
| lowercase_tags | 100.0% |
