# HTMLTrust Study 1 results

Corpus: **4846** real news-article body regions (Common Crawl CC-NEWS). Implementations: python, js, go, rust, php.

E1 binding mode: **shared Rust core: all**. Canonicalization revision: `12bc7e839d5e2a858c29bba651e704e8ed036d95`. Corpus SHA-256: `8c6831bece6f45f25622cf011ac1fcf45d1fcda36f14b8e111566317c12c7f92`.

## E1: Cross-implementation canonicalization on real HTML

### Per-implementation success rate (fraction of pages that canonicalize without error)

| implementation | success rate |
|---|---|
| python | 3.6% |
| js | 3.6% |
| go | 3.6% |
| rust | 3.6% |
| php | 3.6% |

All 5 implementations accepted **174/4846** pages (3.6%). Of those accepted pages, **174/174** produced matching SHA-256 digests (100.0%). This is **3.6%** of the full corpus.

All 5 implementations agreed on accept-or-reject status for **4846/4846** pages (100.0%).

### Pairwise matching digests among pages both implementations accepted

| pair | both accepted | accepted coverage | matching digest | conditional agreement | corpus agreement |
|---|---:|---:|---:|---:|---:|
| python-js | 174 | 3.6% | 174 | 100.0% | 3.6% |
| python-go | 174 | 3.6% | 174 | 100.0% | 3.6% |
| python-rust | 174 | 3.6% | 174 | 100.0% | 3.6% |
| python-php | 174 | 3.6% | 174 | 100.0% | 3.6% |
| js-go | 174 | 3.6% | 174 | 100.0% | 3.6% |
| js-rust | 174 | 3.6% | 174 | 100.0% | 3.6% |
| js-php | 174 | 3.6% | 174 | 100.0% | 3.6% |
| go-rust | 174 | 3.6% | 174 | 100.0% | 3.6% |
| go-php | 174 | 3.6% | 174 | 100.0% | 3.6% |
| rust-php | 174 | 3.6% | 174 | 100.0% | 3.6% |

### Failure reasons

- **python**: `parser-profile-unsupported` ×4196; `url-policy-violation` ×474; `attribute-canonicalization-failed` ×2
- **js**: `parser-profile-unsupported` ×4196; `url-policy-violation` ×474; `attribute-canonicalization-failed` ×2
- **go**: `parser-profile-unsupported` ×4196; `url-policy-violation` ×474; `attribute-canonicalization-failed` ×2
- **rust**: `parser-profile-unsupported` ×4196; `url-policy-violation` ×474; `attribute-canonicalization-failed` ×2
- **php**: `parser-profile-unsupported` ×4196; `url-policy-violation` ×474; `attribute-canonicalization-failed` ×2

### Disagreement taxonomy (each implementation vs the `rust` reference)

No cross-implementation disagreements were observed.


## E2: Python-binding sensitivity to publishing transformations

Measured on 121 pages accepted by the Python binding. The measurements report byte-level signature stability. They do not establish that every transformation preserves rendered meaning.

| transformation | attempted | evaluated | transform failed | rejected after transform | hash changed | preserved | preservation rate |
|---|---:|---:|---:|---:|---:|---:|---:|
| reserialize_htmlparser | 121 | 121 | 0 | 0 | 0 | 121 | 100.0% |
| reserialize_lxml | 121 | 121 | 0 | 121 | 0 | 0 | 0.0% |
| intertag_whitespace_insertion | 121 | 121 | 0 | 0 | 32 | 89 | 73.6% |
| lowercase_tags | 121 | 121 | 0 | 0 | 0 | 121 | 100.0% |
| entity_reencoding | 121 | 121 | 0 | 0 | 0 | 121 | 100.0% |
