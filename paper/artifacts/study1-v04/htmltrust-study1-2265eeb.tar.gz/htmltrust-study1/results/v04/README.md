# HTMLTrust Study 1 v0.4 evidence

This directory records the v1 follow-up evidence generated on 2026-08-28.
All canonicalization runs use revision
`b0c8f305425de190a7f209ac117d34f88c2b1946`, source-tree SHA-256
`3b058dfbaa354b584e2e5aec33c3e7c1bd96c27548c4684f4051d9a5f5ef9a83`, and
container image
`sha256:579515b828ef6930af9fc52b92c79ed9bc91520577682b11de1aa14214be09f1`.

The 4,846-record corpus is the existing file at
`/mnt/bulk/htmltrust-study1/v03/corpus/corpus.jsonl`; it was mounted read-only
and was not copied into this repository. Its SHA-256 is
`8c6831bece6f45f25622cf011ac1fcf45d1fcda36f14b8e111566317c12c7f92`.

## Results

- Full corpus, five independent ports: 121/4,846 accepted by every port;
  119/121 jointly accepted regions had matching digests; accept/reject status
  agreed on 4,777/4,846 regions.
- Adversarial fixtures: 47/47 expected outcomes matched, including 19/19
  accepted normative digests and byte lengths.
- In-process Node Ed25519 benchmark: four deterministic HTML sizes, three
  warmups, and 20 measured iterations. Verification medians were 0.066 ms,
  0.066 ms, 0.081 ms, and 0.082 ms for 1 KiB, 10 KiB, 100 KiB, and 1 MiB
  inputs. Total canonicalize/sign/verify medians were 0.640 ms, 1.364 ms,
  8.540 ms, and 97.106 ms.
- Full-corpus process benchmark: one pass over all 4,846 records per port.
  The timing scope includes process startup, JSONL I/O, hashing, and
  canonicalization. The exact samples are in `benchmark/benchmark.jsonl`.
- Sybil analysis: the deterministic illustrative model reaches a raw identity
  majority at 21 identities, an open-directory majority at five directories
  with a cap of five endorsements per directory, and the configured quorum
  after three configured-directory compromises.

The Sybil numbers model explicit policy assumptions. They are not measurements
of attacker cost or prevalence. The signing benchmark excludes browser and
network latency. The corpus is a sample of observed news HTML, so its strict
profile acceptance rate does not estimate all web publishing systems.

## Files

- `full-corpus/` contains the run manifest, corpus identity, generated report,
  statistics, stability results, and disagreement taxonomy. Per-record output
  JSONL remains on the bulk disk at `/mnt/bulk/htmltrust-study1/v03/runs-v04-final/`.
- `adversarial/` contains every selected fixture result and its Markdown report.
- `signing/` contains every timing sample and the byte-overhead report.
- `benchmark/` contains the full-corpus process benchmark and a recomputed
  summary.
- `sybil/` contains the machine-readable model, CSV rows, and report.

## Verify the compact snapshot

From the repository root:

```sh
sha256sum -c results/v04/SHA256SUMS
```

The checksum list excludes itself.

## Reproduce the evidence

Set the disk-backed data directory containing the existing corpus, then build
the pinned image and capture its immutable ID:

```sh
export TMPDIR="$HOME/tmp"
export STUDY1_DATA=/mnt/bulk/htmltrust-study1/v03
CANON_REV=b0c8f305425de190a7f209ac117d34f88c2b1946 make image
make test
image_id="$(docker image inspect htmltrust-study1:latest --format '{{.Id}}')"
```

Run the full corpus analysis into its own output directory:

```sh
HTMLTRUST_STUDY_IMAGE="$image_id" docker compose run --rm \
  -e OUT=/data/runs-v04-final \
  -e HTMLTRUST_IMAGE_ID="$image_id" \
  study1-analyze analyze
```

Run the full-corpus process benchmark and both v1 evaluations:

```sh
HTMLTRUST_STUDY_IMAGE="$image_id" docker compose run --rm \
  -e OUT=/data/research-v04 -e WARMUPS=0 -e ITERATIONS=1 \
  -e CORPUS_LIMIT=4846 -e HTMLTRUST_IMAGE_ID="$image_id" \
  study1-analyze benchmark
HTMLTRUST_STUDY_IMAGE="$image_id" docker compose run --rm \
  -e OUT=/data/research-v04 -e SIGNING_BENCHMARK_WARMUPS=3 \
  -e SIGNING_BENCHMARK_ITERATIONS=20 -e HTMLTRUST_IMAGE_ID="$image_id" \
  study1-analyze signing-benchmark-v1
HTMLTRUST_STUDY_IMAGE="$image_id" docker compose run --rm \
  -e OUT=/data/research-v04 -e HTMLTRUST_IMAGE_ID="$image_id" \
  study1-analyze adversarial
```

Recompute the readable process summary and Sybil sensitivity model:

```sh
BENCHMARK_INPUT="$STUDY1_DATA/research-v04/benchmark.jsonl" \
  RESEARCH_OUT="$STUDY1_DATA/research-v04" make benchmark-summary
RESEARCH_OUT="$STUDY1_DATA/research-v04" make sybil
```

These commands write raw output to `runs-v04-final` and `research-v04`. The
compact files in this directory were copied after the summaries were recomputed
from those raw JSON files.
