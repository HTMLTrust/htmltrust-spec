# HTMLTrust Study 1 results

Corpus: **4846** real news-article body regions (Common Crawl CC-NEWS). Implementations: python, js, go, rust, php.

E1 binding mode: **independent language implementations**. Canonicalization revision: `b0c8f305425de190a7f209ac117d34f88c2b1946`. Corpus SHA-256: `8c6831bece6f45f25622cf011ac1fcf45d1fcda36f14b8e111566317c12c7f92`.

## E1: Cross-implementation canonicalization on real HTML

### Per-implementation success rate (fraction of pages that canonicalize without error)

| implementation | success rate |
|---|---|
| python | 2.5% |
| js | 2.7% |
| go | 2.8% |
| rust | 3.6% |
| php | 2.8% |

All 5 implementations accepted **121/4846** pages (2.5%). Of those accepted pages, **119/121** produced matching SHA-256 digests (98.3%). This is **2.5%** of the full corpus.

All 5 implementations agreed on accept-or-reject status for **4777/4846** pages (98.6%).

### Pairwise matching digests among pages both implementations accepted

| pair | both accepted | accepted coverage | matching digest | conditional agreement | corpus agreement |
|---|---:|---:|---:|---:|---:|
| python-js | 121 | 2.5% | 120 | 99.2% | 2.5% |
| python-go | 121 | 2.5% | 120 | 99.2% | 2.5% |
| python-rust | 121 | 2.5% | 120 | 99.2% | 2.5% |
| python-php | 121 | 2.5% | 119 | 98.3% | 2.5% |
| js-go | 133 | 2.7% | 133 | 100.0% | 2.7% |
| js-rust | 121 | 2.5% | 121 | 100.0% | 2.5% |
| js-php | 133 | 2.7% | 122 | 91.7% | 2.5% |
| go-rust | 122 | 2.5% | 122 | 100.0% | 2.5% |
| go-php | 137 | 2.8% | 126 | 92.0% | 2.6% |
| rust-php | 122 | 2.5% | 121 | 99.2% | 2.5% |

### Failure reasons

- **python**: `ValueError: parser-profile-unsupported` ×4651; `ValueError: url-policy-violation` ×74
- **js**: `parser-profile-unsupported` ×4627; `url-policy-violation` ×86
- **go**: `parser-profile-unsupported` ×4587; `url-policy-violation` ×115; `parser-profile-unsupported: unclosed [script]` ×2; `parser-profile-unsupported: unclosed [div div article div div div div body]` ×2; `parser-profile-unsupported: unclosed [div div div div div p html body]` ×1; `parser-profile-unsupported: unclosed [div main section div div div div div div div div]` ×1
- **rust**: `parser-profile-unsupported` ×4196; `url-policy-violation` ×474; `attribute-canonicalization-failed` ×2
- **php**: `InvalidArgumentException: parser-profile-unsupported` ×4634; `InvalidArgumentException: url-policy-violation` ×75

### Disagreement taxonomy (each implementation vs the `rust` reference)

Records from the all-port disagreement set, bucketed by each port's first difference from the reference.

| category | python | js | go | php |
|---|---|---|---|---|
| identical | 1 | 2 | 3 | 2 |
| ok-status-divergence | 53 | 65 | 68 | 67 |
| url-serialization | 1 | 0 | 0 | 1 |

## E2: Python-binding sensitivity to publishing transformations

Measured on 121 pages accepted by the Python binding. The measurements report byte-level signature stability. They do not establish that every transformation preserves rendered meaning.

| transformation | attempted | evaluated | transform failed | rejected after transform | hash changed | preserved | preservation rate |
|---|---:|---:|---:|---:|---:|---:|---:|
| reserialize_htmlparser | 121 | 121 | 0 | 0 | 0 | 121 | 100.0% |
| reserialize_lxml | 121 | 121 | 0 | 121 | 0 | 0 | 0.0% |
| intertag_whitespace_insertion | 121 | 121 | 0 | 0 | 32 | 89 | 73.6% |
| lowercase_tags | 121 | 121 | 0 | 0 | 0 | 121 | 100.0% |
| entity_reencoding | 121 | 121 | 0 | 0 | 0 | 121 | 100.0% |
