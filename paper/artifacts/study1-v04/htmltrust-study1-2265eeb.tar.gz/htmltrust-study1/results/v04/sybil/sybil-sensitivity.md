# HTMLTrust endorsement Sybil sensitivity analysis

This deterministic model starts with 20 honest endorsements across 5 user-configured directories. It compares raw signature count, an open directory score capped at 5 endorsements per directory, and a 3-of-5 configured-directory quorum.

| Attack | Sybil identities | Attacker directories | Compromised configured directories | Raw attacker share | Open-cap attacker share | Configured attacker share | Configured quorum |
|---|---:|---:|---:|---:|---:|---:|---|
| control | 0 | 0 | 0 | 0.0% | 0.0% | 0.0% | no |
| one-sybil | 1 | 1 | 0 | 4.8% | 4.8% | 0.0% | no |
| five-sybils-one-directory | 5 | 1 | 0 | 20.0% | 20.0% | 0.0% | no |
| twenty-sybils-one-directory | 20 | 1 | 0 | 50.0% | 20.0% | 0.0% | no |
| hundred-sybils-one-directory | 100 | 1 | 0 | 83.3% | 20.0% | 0.0% | no |
| hundred-sybils-twenty-directories | 100 | 20 | 0 | 83.3% | 83.3% | 0.0% | no |
| thousand-sybils-two-hundred-directories | 1000 | 200 | 0 | 98.0% | 98.0% | 0.0% | no |
| one-configured-directory-compromised | 100 | 1 | 1 | 83.3% | 20.0% | 20.0% | no |
| quorum-configured-directories-compromised | 300 | 3 | 3 | 93.8% | 42.9% | 60.0% | yes |

## What the model establishes

Raw counting reaches an attacker majority at 21 identities under these assumptions. A 5-per-directory cap raises that threshold to control of at least 5 open directories, but directory creation remains a Sybil surface. The configured policy ignores unconfigured directories and fails after compromise of 3 configured directories.

The protocol therefore cannot assign trust from endorsement volume alone. A client policy needs an explicit configured trust root or an external identity-cost mechanism. Per-directory caps are useful only when directory admission itself resists Sybil creation.

## Limits

- The model assigns no monetary or operational cost to an identity, directory, or compromise.
- The configured-directory policy inherits the user's directory selection and cannot protect a compromised quorum.
- Scores describe attacker weight in this model; they do not estimate real-world attack prevalence.
