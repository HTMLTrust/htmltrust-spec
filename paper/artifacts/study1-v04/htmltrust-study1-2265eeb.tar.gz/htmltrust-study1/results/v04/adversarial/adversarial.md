# HTMLTrust adversarial canonicalization evaluation

Canonicalization revision: `b0c8f305425de190a7f209ac117d34f88c2b1946`

The evaluation runs 47 selected normative parser, URL, Unicode, delimiter, signed-attribute, excluded-subtree, character-reference, and resource-ceiling fixtures through every independent language port.

## Result

- Expected outcomes matched in 47/47 cases.
- Accepted inputs matched the normative digest and byte length in every port for 19/19 cases.
- Overall status: **pass**.

| Category | Passed | Cases |
|---|---:|---:|
| character-reference | 2 | 2 |
| excluded-subtree | 2 | 2 |
| parser-differential | 18 | 18 |
| record-delimiter | 3 | 3 |
| resource-ceiling | 5 | 5 |
| signed-attribute | 1 | 1 |
| unicode-format-control | 3 | 3 |
| url-policy | 13 | 13 |

Each case records the source fixture path and SHA-256. Rejections pass only when every port returns the exact normative error code. Accepted cases pass only when every port returns the fixture's normative canonical digest and byte length.
