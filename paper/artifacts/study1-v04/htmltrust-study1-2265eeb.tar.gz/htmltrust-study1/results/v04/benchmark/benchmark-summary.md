# HTMLTrust canonicalization process benchmark

Canonicalization revision: `b0c8f305425de190a7f209ac117d34f88c2b1946`

Each measurement starts one language runner, reads JSONL, canonicalizes and hashes the input, then writes JSONL. Medians and p95 values use 1 measured iterations after 0 warmups. They include process startup and file I/O.

## One MiB synthetic region

| Port | Median (ms) | p95 (ms) | Throughput (MiB/s) |
|---|---:|---:|---:|
| go | 137.8 | 137.8 | 7.26 |
| javascript | 209.0 | 209.0 | 4.79 |
| php | 102.8 | 102.8 | 9.73 |
| python | 1262.2 | 1262.2 | 0.79 |
| rust | 46.7 | 46.7 | 21.42 |

All 25 matrix cells completed with 0 runner failures.

The corpus measurement contains 4846 records. Per-port acceptance and rejection counts are recorded in the JSON summary.
