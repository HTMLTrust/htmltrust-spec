#!/usr/bin/env python3
"""Study 1 corpus builder.

Streams Common Crawl News (CC-NEWS) WARC files, selects a deterministic
hash-sample of successful text/html responses, decodes each by its declared
charset, and writes a fixed corpus of raw HTML documents that every
canonicalization implementation consumes byte-for-byte.

Design choices that matter for the study:
  * The default corpus stores the decoded source substring inside an explicit
    body element. It does not serialize a parsed tree. Feeding the same source
    substring to every implementation isolates the canonicalization step and
    avoids choosing one implementation's parser as a preprocessing stage.
  * Sampling is deterministic: a record is selected iff
    int(sha1(url)[:12], 16) % stride == residue. Given (warc list, stride,
    residue, target), the same compressed WARC bytes, and the pinned image, the
    corpus is byte-identical on every run.

Output: corpus.jsonl  ({id,url,base_url,charset,declared_charset,n_bytes,html})
and manifest.json. Unknown declared charsets are decoded as UTF-8 and counted
as ``charset_fallback`` in the manifest.
"""

from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
import datetime
from pathlib import Path
from urllib.parse import urlsplit

_TAG_NAME = re.compile(r"[A-Za-z][^\t\n\f\r />]*")
_RAWTEXT_ELEMENTS = {
    "script",
    "style",
    "title",
    "textarea",
    "xmp",
    "iframe",
    "noembed",
    "noframes",
    "plaintext",
}
_OPAQUE_BODY_CONTEXTS = {"template", "noscript", "svg", "math"}


def _tag_token(html: str, start: int) -> tuple[str, str, int] | None:
    """Return (kind, lower-name, end-offset) for a tag-like token."""
    if not html.startswith("<", start):
        return None
    if html.startswith("<!--", start):
        end = html.find("-->", start + 4)
        return "comment", "", len(html) if end < 0 else end + 3
    if start + 1 >= len(html):
        return None
    if html[start + 1] in "!?:":
        quote = None
        offset = start + 2
        while offset < len(html):
            char = html[offset]
            if quote is not None:
                if char == quote:
                    quote = None
            elif char in "\"'":
                quote = char
            elif char == ">":
                return "declaration", "", offset + 1
            offset += 1
        return "declaration", "", len(html)

    offset = start + 1
    kind = "start"
    if html[offset] == "/":
        kind = "end"
        offset += 1
    while offset < len(html) and html[offset] in "\t\n\f\r ":
        offset += 1
    match = _TAG_NAME.match(html, offset)
    if match is None:
        return None
    name = match.group(0).lower()
    offset = match.end()
    quote = None
    while offset < len(html):
        char = html[offset]
        if quote is not None:
            if char == quote:
                quote = None
        elif char in "\"'":
            quote = char
        elif char == ">":
            return kind, name, offset + 1
        offset += 1
    return kind, name, len(html)


def _next_tag(html: str, offset: int) -> tuple[int, str, str, int] | None:
    while True:
        start = html.find("<", offset)
        if start < 0:
            return None
        token = _tag_token(html, start)
        if token is not None:
            kind, name, end = token
            return start, kind, name, end
        offset = start + 1


def _after_rawtext(html: str, offset: int, name: str) -> int:
    closing = re.search(
        rf"</\s*{re.escape(name)}(?=[\t\n\f\r />])", html[offset:], re.I
    )
    if closing is None:
        return len(html)
    closing_start = offset + closing.start()
    closing_token = _tag_token(html, closing_start)
    return closing_token[2] if closing_token is not None else closing_start + 2


def _after_opaque_element(html: str, offset: int, name: str) -> int:
    """Skip source whose tokens cannot contain the document body element."""
    depth = 1
    while depth:
        token = _next_tag(html, offset)
        if token is None:
            return len(html)
        _, kind, token_name, end = token
        offset = end
        if kind == "start" and token_name in _RAWTEXT_ELEMENTS:
            offset = _after_rawtext(html, offset, token_name)
        elif kind == "start" and token_name == name:
            depth += 1
        elif kind == "end" and token_name == name:
            depth -= 1
    return offset


def body_slice(html: str) -> str | None:
    """Return raw source inside the first eligible body token.

    The scanner skips comments, quoted attributes, raw-text elements, template
    content, noscript content, and foreign SVG or MathML content. It returns a
    source substring and never serializes a parser-produced tree.
    """
    offset = 0
    body_start = None
    while True:
        token = _next_tag(html, offset)
        if token is None:
            return None
        start, kind, name, end = token
        offset = end
        if kind == "start" and name in _RAWTEXT_ELEMENTS:
            offset = _after_rawtext(html, offset, name)
            if offset == len(html):
                return None
            continue
        if kind == "start" and name in _OPAQUE_BODY_CONTEXTS:
            offset = _after_opaque_element(html, offset, name)
            continue
        if kind == "start" and name == "body":
            body_start = end
            break

    offset = body_start
    while True:
        token = _next_tag(html, offset)
        if token is None:
            return html[body_start:]
        start, kind, name, end = token
        offset = end
        if kind == "start" and name in _RAWTEXT_ELEMENTS:
            offset = _after_rawtext(html, offset, name)
            if offset == len(html):
                return html[body_start:]
            continue
        if kind == "start" and name in _OPAQUE_BODY_CONTEXTS:
            offset = _after_opaque_element(html, offset, name)
            continue
        if kind == "end" and name == "body":
            return html[body_start:start]


def charset_of(record) -> str:
    ct = (
        record.http_headers.get_header("Content-Type") if record.http_headers else ""
    ) or ""
    for part in ct.split(";"):
        part = part.strip().lower()
        if part.startswith("charset="):
            cs = part.split("=", 1)[1].strip().strip('"').strip("'")
            return cs or "utf-8"
    return "utf-8"


def decode_html(raw: bytes, declared_charset: str) -> tuple[str, str, bool]:
    """Decode a response, preserving the historical UTF-8 fallback.

    The boolean reports whether the declared charset was unknown and the
    fallback was used. A malformed response still raises UnicodeDecodeError,
    just as the strict decode path did before fallback accounting was added.
    """

    try:
        return raw.decode(declared_charset, errors="strict"), declared_charset, False
    except LookupError:
        return raw.decode("utf-8", errors="strict"), "utf-8", True


def url_allowed(url: str, base_url_policy: str) -> bool:
    """Return whether *url* satisfies the configured corpus URL policy."""

    try:
        parsed_url = urlsplit(url)
        allowed_schemes = (
            {"https"} if base_url_policy == "https" else {"http", "https"}
        )
        return (
            parsed_url.scheme.lower() in allowed_schemes
            and parsed_url.hostname is not None
            and parsed_url.username is None
            and parsed_url.password is None
            and not any(ord(char) <= 0x20 or ord(char) == 0x7F for char in url)
        )
    except (TypeError, ValueError):
        return False


def read_response(record, max_response_bytes: int) -> tuple[bytes, bool]:
    """Read at most one byte beyond the limit and report boundary validity."""

    raw = record.content_stream().read(max_response_bytes + 1)
    return raw, len(raw) <= max_response_bytes


def sha1_id(url: str) -> str:
    """Return the corpus identifier derived from the first 16 SHA-1 hex chars."""

    return hashlib.sha1(url.encode("utf-8")).hexdigest()[:16]


def ensure_unique_id(written_ids: dict[str, str], record_id: str, url: str) -> None:
    """Reject a truncated-SHA-1 collision between distinct corpus URLs."""

    previous_url = written_ids.get(record_id)
    if previous_url is not None and previous_url != url:
        raise RuntimeError(
            "SHA-1 ID collision: "
            f"{record_id} maps both {previous_url!r} and {url!r}"
        )


def is_html_200(record) -> bool:
    if record.rec_type != "response":
        return False
    h = record.http_headers
    if h is None:
        return False
    status = (h.get_statuscode() or "").strip()
    if status != "200":
        return False
    ct = (h.get_header("Content-Type") or "").lower()
    return "text/html" in ct or "application/xhtml" in ct


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main(argv: list[str] | None = None) -> int:
    try:
        from warcio.archiveiterator import ArchiveIterator
    except ImportError:
        print(
            "warcio is required to build a corpus; install requirements.txt",
            file=sys.stderr,
        )
        return 2

    ap = argparse.ArgumentParser()
    ap.add_argument("--warc-dir", required=True)
    ap.add_argument(
        "--warc-limit",
        type=int,
        default=5,
        help="number of WARC files (sorted) to scan",
    )
    ap.add_argument("--target", type=int, default=10000, help="target sample size")
    ap.add_argument("--stride", type=int, default=17, help="1/stride sampling density")
    ap.add_argument("--residue", type=int, default=0)
    ap.add_argument("--min-bytes", type=int, default=1024)
    ap.add_argument(
        "--max-bytes",
        type=int,
        default=1_048_576,
        help="maximum decoded source bytes (default: the v1 canonicalization limit)",
    )
    ap.add_argument(
        "--max-response-bytes",
        type=int,
        default=8_388_608,
        help="maximum response bytes read before region extraction",
    )
    ap.add_argument(
        "--base-url-policy",
        choices=["https", "http-https"],
        default="https",
        help="accepted corpus URL schemes (default: v1-compatible HTTPS)",
    )
    ap.add_argument(
        "--region",
        choices=["body", "full"],
        default="body",
        help="canonicalization input: raw <body> inner HTML (default) or whole document",
    )
    ap.add_argument("--out", required=True)
    args = ap.parse_args(argv)

    if args.warc_limit < 1 or args.target < 1:
        ap.error("--warc-limit and --target must be positive")
    if args.stride < 1 or not 0 <= args.residue < args.stride:
        ap.error("--stride must be positive and --residue must be in [0, stride)")
    if not 0 <= args.min_bytes <= args.max_bytes <= args.max_response_bytes:
        ap.error("size limits must satisfy 0 <= min <= max <= max-response")

    warc_dir = Path(args.warc_dir)
    warcs = sorted(warc_dir.glob("*.warc.gz"))[: args.warc_limit]
    if not warcs:
        print(f"no WARCs under {warc_dir}", file=sys.stderr)
        return 2

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    n_written = 0
    n_html_200 = n_url_eligible = n_hash_selected = 0
    n_skip_size = n_skip_response_size = n_skip_decode = n_skip_url_policy = 0
    n_charset_fallback = 0
    n_skip_duplicate = n_skip_read_error = 0
    written_urls: set[str] = set()
    written_ids: dict[str, str] = {}
    scanned_warcs = []

    partial = out.with_name(out.name + ".partial")
    with open(partial, "w", encoding="utf-8") as fh:
        for wp in warcs:
            if n_written >= args.target:
                break
            warc_record = {"name": wp.name, "size": wp.stat().st_size}
            scanned_warcs.append(warc_record)
            with open(wp, "rb") as stream:
                for record in ArchiveIterator(stream):
                    if n_written >= args.target:
                        break
                    if not is_html_200(record):
                        continue
                    n_html_200 += 1
                    url = record.rec_headers.get_header("WARC-Target-URI") or ""
                    if not url_allowed(url, args.base_url_policy):
                        n_skip_url_policy += 1
                        continue
                    n_url_eligible += 1
                    sel = int(hashlib.sha1(url.encode("utf-8")).hexdigest()[:12], 16)
                    if sel % args.stride != args.residue:
                        continue
                    n_hash_selected += 1
                    try:
                        raw, response_size_allowed = read_response(
                            record, args.max_response_bytes
                        )
                    except Exception:
                        n_skip_read_error += 1
                        continue
                    if not response_size_allowed:
                        n_skip_response_size += 1
                        continue
                    cs = charset_of(record)
                    try:
                        html, decoded_charset, used_charset_fallback = decode_html(
                            raw, cs
                        )
                    except UnicodeDecodeError:
                        n_skip_decode += 1
                        continue
                    if used_charset_fallback:
                        n_charset_fallback += 1
                    if args.region == "body":
                        body = body_slice(html)
                        if body is None:
                            n_skip_size += 1
                            continue
                        html = body
                    source_size = len(html.encode("utf-8"))
                    if source_size < args.min_bytes or source_size > args.max_bytes:
                        n_skip_size += 1
                        continue
                    if url in written_urls:
                        n_skip_duplicate += 1
                        continue
                    rec_id = sha1_id(url)
                    ensure_unique_id(written_ids, rec_id, url)
                    fh.write(
                        json.dumps(
                            {
                                "id": rec_id,
                                "url": url,
                                "base_url": url,
                                "declared_charset": cs,
                                "charset": decoded_charset,
                                "n_bytes": source_size,
                                "response_bytes": len(raw),
                                "html": html,
                            },
                            ensure_ascii=False,
                        )
                        + "\n"
                    )
                    written_urls.add(url)
                    written_ids[rec_id] = url
                    n_written += 1
            # A name and byte count identify the normal Common Crawl object;
            # the digest also detects a substituted or truncated local copy.
            warc_record["sha256"] = sha256_file(wp)

    partial.replace(out)

    manifest = {
        "schema": "htmltrust-study1-corpus-manifest/v1",
        "built_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "warc_dir": str(warc_dir),
        "warcs_scanned": scanned_warcs,
        "params": {
            "warc_limit": args.warc_limit,
            "target": args.target,
            "stride": args.stride,
            "residue": args.residue,
            "min_bytes": args.min_bytes,
            "max_bytes": args.max_bytes,
            "max_response_bytes": args.max_response_bytes,
            "region": args.region,
            "base_url_policy": args.base_url_policy,
        },
        "counts": {
            "written": n_written,
            "html_200_seen": n_html_200,
            "url_eligible": n_url_eligible,
            "hash_selected": n_hash_selected,
            "skipped_size": n_skip_size,
            "skipped_response_size": n_skip_response_size,
            "skipped_decode": n_skip_decode,
            "charset_fallback": n_charset_fallback,
            "skipped_url_policy": n_skip_url_policy,
            "skipped_duplicate_url": n_skip_duplicate,
            "skipped_read_error": n_skip_read_error,
        },
    }
    corpus_hasher = hashlib.sha256()
    with open(out, "rb") as corpus_source:
        for chunk in iter(lambda: corpus_source.read(1 << 20), b""):
            corpus_hasher.update(chunk)
    manifest["corpus_sha256"] = corpus_hasher.hexdigest()
    out.with_name(out.stem + ".manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(manifest["counts"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
