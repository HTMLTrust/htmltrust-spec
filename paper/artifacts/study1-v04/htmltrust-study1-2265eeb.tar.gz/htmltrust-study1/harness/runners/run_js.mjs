#!/usr/bin/env node
// JavaScript canonicalization runner for Study 1.
// Reads corpus.jsonl, runs extractCanonicalText(html, {baseUrl}) per record,
// emits {id, ok, hash, len} (or {id, ok:false, err}) to the output JSONL.
import { readFileSync, createWriteStream } from "node:fs";
import { createHash } from "node:crypto";
import { createInterface } from "node:readline";
import { createReadStream } from "node:fs";

const CANON_ROOT =
  process.env.CANON_ROOT ||
  new URL("../../../htmltrust-canonicalization", import.meta.url).pathname;
const { extractCanonicalText } = await import(
  `${CANON_ROOT}/javascript/index.js`
);

const [corpus, out] = process.argv.slice(2);
const dump = process.argv.slice(4).includes("--dump");
const w = createWriteStream(out, { encoding: "utf8" });
const rl = createInterface({ input: createReadStream(corpus, "utf8"), crlfDelay: Infinity });
let n = 0;
for await (const line of rl) {
  if (!line.trim()) continue;
  const r = JSON.parse(line);
  let rec;
  try {
    const canon = extractCanonicalText(r.html, { baseUrl: r.base_url || undefined });
    if (dump) {
      rec = { id: r.id, ok: true, canon };
    } else {
      const b = Buffer.from(canon, "utf8");
      rec = { id: r.id, ok: true, hash: createHash("sha256").update(b).digest("hex"), len: b.length };
    }
  } catch (e) {
    rec = { id: r.id, ok: false, err: String((e && e.message) || e).slice(0, 160) };
  }
  w.write(JSON.stringify(rec) + "\n");
  n++;
}
w.end();
process.stderr.write(`js: ${n} records -> ${out}\n`);
