#!/usr/bin/env python3
"""Python runner backed by the Rust canonicalization CORE via the C ABI
(ctypes), instead of the pure-Python port. Because it calls the same Rust code
as the Rust binding, its output is byte-identical to Rust by construction.

  run_python_core.py <corpus.jsonl> <out.jsonl> [--dump]
Requires the shared library path in HTMLTRUST_CANON_SO.
"""
import ctypes, os, sys, json, hashlib

SO = os.environ["HTMLTRUST_CANON_SO"]
_lib = ctypes.CDLL(SO)
_lib.htmltrust_extract_canonical_text.argtypes = [
    ctypes.c_char_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
_lib.htmltrust_extract_canonical_text.restype = ctypes.c_int
_lib.htmltrust_string_free.argtypes = [ctypes.c_void_p]


def extract(html: str, base):
    out = ctypes.c_void_p()
    rc = _lib.htmltrust_extract_canonical_text(
        html.encode("utf-8"),
        base.encode("utf-8") if base else None,
        ctypes.byref(out),
    )
    val = ctypes.cast(out, ctypes.c_char_p).value
    s = val.decode("utf-8") if val is not None else ""
    _lib.htmltrust_string_free(out)
    if rc == 0:
        return s
    raise ValueError(s or "canonicalization failed")


def main() -> int:
    corpus, out = sys.argv[1], sys.argv[2]
    dump = "--dump" in sys.argv[3:]
    n = 0
    with open(corpus, encoding="utf-8") as fin, open(out, "w", encoding="utf-8") as fout:
        for line in fin:
            if not line.strip():
                continue
            r = json.loads(line)
            try:
                canon = extract(r["html"], r.get("base_url"))
                if dump:
                    rec = {"id": r["id"], "ok": True, "canon": canon}
                else:
                    b = canon.encode("utf-8")
                    rec = {"id": r["id"], "ok": True,
                           "hash": hashlib.sha256(b).hexdigest(), "len": len(b)}
            except Exception as e:  # noqa: BLE001
                rec = {"id": r["id"], "ok": False, "err": str(e)[:160]}
            fout.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n += 1
    print(f"python-core: {n} records -> {out}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
