#!/usr/bin/env php
<?php
/**
 * PHP canonicalization runner for Study 1.
 *   run_php.php <corpus.jsonl> <out.jsonl> [--dump]
 * Default: {id, ok, hash, len} (or {id, ok:false, err}); --dump: {id, ok, canon}.
 */
declare(strict_types=1);

$canonRoot = getenv('CANON_ROOT') ?: (__DIR__ . '/../../../htmltrust-canonicalization');
$autoload = $canonRoot . '/php/vendor/autoload.php';
if (!is_file($autoload)) {
    fwrite(STDERR, "Composer dependencies are not installed: {$autoload}\n");
    exit(2);
}
require_once $autoload;
require_once $canonRoot . '/php/src/Canonicalize.php';
use HTMLTrust\Canonicalization\Canonicalize;

if ($argc < 3) {
    fwrite(STDERR, "usage: run_php.php <corpus> <out> [--dump]\n");
    exit(2);
}
$corpus = $argv[1];
$out = $argv[2];
$dump = in_array('--dump', array_slice($argv, 3), true);

$fin = fopen($corpus, 'r');
$fout = fopen($out, 'w');
$n = 0;
while (($line = fgets($fin)) !== false) {
    $line = trim($line);
    if ($line === '') {
        continue;
    }
    $r = json_decode($line, true);
    $id = $r['id'] ?? '';
    try {
        $canon = Canonicalize::extractCanonicalText($r['html'], false, $r['base_url'] ?? null);
        if ($dump) {
            $rec = ['id' => $id, 'ok' => true, 'canon' => $canon];
        } else {
            $rec = ['id' => $id, 'ok' => true, 'hash' => hash('sha256', $canon), 'len' => strlen($canon)];
        }
    } catch (\Throwable $e) {
        $rec = ['id' => $id, 'ok' => false, 'err' => substr(get_class($e) . ': ' . $e->getMessage(), 0, 160)];
    }
    fwrite($fout, json_encode($rec, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n");
    $n++;
}
fclose($fin);
fclose($fout);
fwrite(STDERR, "php: $n records -> $out\n");
