#!/usr/bin/env node
// JS runner backed by the Rust canonicalization CORE via WebAssembly, instead
// of the pure-JS port. Byte-identical to the Rust binding by construction.
//   run_js_core.mjs <corpus.jsonl> <out.jsonl> [--dump]
// Requires HTMLTRUST_WASM_PKG = path to the wasm-pack pkg entry .js.
//
// One wasm instance per process. Processing thousands of large pages in a single
// long-lived process accumulates V8 wasm code-space / native memory that GC does
// not reclaim, so BATCH callers should run this over small chunks in fresh
// processes (see run_js_core_batch.sh). The real target — a browser verifier —
// re-initialises the wasm module per page it lands on, so it processes exactly
// one page per instance and never accumulates.
import { createReadStream, appendFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { createInterface } from "node:readline";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const wasm = require(process.env.HTMLTRUST_WASM_PKG);

const [corpus, out] = process.argv.slice(2).filter((a) => !a.startsWith("--"));
const dump = process.argv.includes("--dump");

const rl = createInterface({ input: createReadStream(corpus, "utf8"), crlfDelay: Infinity });
let n = 0;
for await (const line of rl) {
  if (!line.trim()) continue;
  const r = JSON.parse(line);
  let rec;
  try {
    const canon = wasm.extractCanonicalText(r.html, r.base_url || undefined);
    if (dump) {
      rec = { id: r.id, ok: true, canon };
    } else {
      const b = Buffer.from(canon, "utf8");
      rec = { id: r.id, ok: true, hash: createHash("sha256").update(b).digest("hex"), len: b.length };
    }
  } catch (e) {
    rec = { id: r.id, ok: false, err: String((e && e.message) || e).slice(0, 160) };
  }
  appendFileSync(out, JSON.stringify(rec) + "\n");
  n++;
}
process.stderr.write(`js-core: ${n} records -> ${out}\n`);
