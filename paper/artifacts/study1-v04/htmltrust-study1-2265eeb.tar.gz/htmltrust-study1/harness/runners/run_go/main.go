// Go canonicalization runner for Study 1.
//   run-go <corpus.jsonl> <out.jsonl> [--dump]
package main

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"

	canon "github.com/HTMLTrust/htmltrust-canonicalization/go"
)

type inRec struct {
	ID      string `json:"id"`
	HTML    string `json:"html"`
	BaseURL string `json:"base_url"`
}

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: run-go <corpus> <out> [--dump]")
		os.Exit(2)
	}
	dump := false
	for _, a := range os.Args[3:] {
		if a == "--dump" {
			dump = true
		}
	}
	fin, err := os.Open(os.Args[1])
	if err != nil {
		panic(err)
	}
	defer fin.Close()
	fout, err := os.Create(os.Args[2])
	if err != nil {
		panic(err)
	}
	defer fout.Close()

	dec := json.NewDecoder(bufio.NewReaderSize(fin, 1<<20))
	w := bufio.NewWriterSize(fout, 1<<20)
	defer w.Flush()
	enc := json.NewEncoder(w)

	n := 0
	for {
		var r inRec
		if err := dec.Decode(&r); err != nil {
			break
		}
		canonStr, cerr := canon.ExtractCanonicalText(r.HTML, canon.Options{BaseURL: r.BaseURL})
		var out map[string]interface{}
		if cerr != nil {
			out = map[string]interface{}{"id": r.ID, "ok": false, "err": truncate(cerr.Error(), 160)}
		} else if dump {
			out = map[string]interface{}{"id": r.ID, "ok": true, "canon": canonStr}
		} else {
			sum := sha256.Sum256([]byte(canonStr))
			out = map[string]interface{}{"id": r.ID, "ok": true, "hash": hex.EncodeToString(sum[:]), "len": len([]byte(canonStr))}
		}
		_ = enc.Encode(out)
		n++
	}
	fmt.Fprintf(os.Stderr, "go: %d records -> %s\n", n, os.Args[2])
}

func truncate(s string, n int) string {
	if len(s) > n {
		return s[:n]
	}
	return s
}
