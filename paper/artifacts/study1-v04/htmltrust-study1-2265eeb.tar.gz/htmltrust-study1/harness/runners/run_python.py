#!/usr/bin/env python3
"""Python canonicalization runner for Study 1.
  run_python.py <corpus.jsonl> <out.jsonl> [--dump]
Default: emit {id, ok, hash, len} (or {id, ok:false, err}).
--dump:  emit {id, ok, canon} full canonical text (for disagreement taxonomy).
"""
import sys, os, json, hashlib

CANON_ROOT = os.environ.get("CANON_ROOT", os.path.join(os.path.dirname(__file__), "..", "..", "..", "htmltrust-canonicalization"))
sys.path.insert(0, os.path.join(CANON_ROOT, "python"))
from htmltrust_canonicalization import extract_canonical_text  # noqa: E402


def main() -> int:
    corpus, out = sys.argv[1], sys.argv[2]
    dump = "--dump" in sys.argv[3:]
    n = 0
    with open(corpus, encoding="utf-8") as fin, open(out, "w", encoding="utf-8") as fout:
        for line in fin:
            if not line.strip():
                continue
            r = json.loads(line)
            try:
                canon = extract_canonical_text(r["html"], base_url=r.get("base_url"))
                if dump:
                    rec = {"id": r["id"], "ok": True, "canon": canon}
                else:
                    b = canon.encode("utf-8")
                    rec = {"id": r["id"], "ok": True, "hash": hashlib.sha256(b).hexdigest(), "len": len(b)}
            except Exception as e:  # noqa: BLE001
                rec = {"id": r["id"], "ok": False, "err": (type(e).__name__ + ": " + str(e))[:160]}
            fout.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n += 1
    print(f"python: {n} records -> {out}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
