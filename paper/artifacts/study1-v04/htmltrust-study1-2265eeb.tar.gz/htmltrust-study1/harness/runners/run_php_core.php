#!/usr/bin/env php
<?php
/**
 * PHP runner backed by the Rust canonicalization CORE via the PHP FFI extension
 * and the C ABI, instead of the pure-PHP port. Byte-identical to the Rust
 * binding by construction.
 *   run_php_core.php <corpus.jsonl> <out.jsonl> [--dump]
 * Requires HTMLTRUST_CANON_SO = path to the shared library and ext-ffi.
 */
declare(strict_types=1);

$so = getenv('HTMLTRUST_CANON_SO');
if ($so === false || $so === '') {
    fwrite(STDERR, "set HTMLTRUST_CANON_SO\n");
    exit(2);
}
$ffi = FFI::cdef(
    "int htmltrust_extract_canonical_text(char *html, char *base, char **out);\n"
    . "void htmltrust_string_free(char *s);\n",
    $so
);

/** @return array{0:int,1:string} [rc, text-or-error] */
function canon_extract(FFI $ffi, string $html, ?string $base): array
{
    $out = $ffi->new("char*");
    $rc = $ffi->htmltrust_extract_canonical_text($html, $base, FFI::addr($out));
    $s = FFI::isNull($out) ? '' : FFI::string($out);
    $ffi->htmltrust_string_free($out);
    return [$rc, $s];
}

if ($argc < 3) {
    fwrite(STDERR, "usage: run_php_core.php <corpus> <out> [--dump]\n");
    exit(2);
}
$corpus = $argv[1];
$out = $argv[2];
$dump = in_array('--dump', array_slice($argv, 3), true);

$fin = fopen($corpus, 'r');
$fout = fopen($out, 'w');
$n = 0;
while (($line = fgets($fin)) !== false) {
    $line = trim($line);
    if ($line === '') {
        continue;
    }
    $r = json_decode($line, true);
    $id = $r['id'] ?? '';
    $base = (isset($r['base_url']) && $r['base_url'] !== '') ? $r['base_url'] : null;
    [$rc, $s] = canon_extract($ffi, $r['html'], $base);
    if ($rc === 0) {
        $rec = $dump
            ? ['id' => $id, 'ok' => true, 'canon' => $s]
            : ['id' => $id, 'ok' => true, 'hash' => hash('sha256', $s), 'len' => strlen($s)];
    } else {
        $rec = ['id' => $id, 'ok' => false, 'err' => substr($s, 0, 160)];
    }
    fwrite($fout, json_encode($rec, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n");
    $n++;
}
fclose($fin);
fclose($fout);
fwrite(STDERR, "php-core: $n records -> $out\n");
