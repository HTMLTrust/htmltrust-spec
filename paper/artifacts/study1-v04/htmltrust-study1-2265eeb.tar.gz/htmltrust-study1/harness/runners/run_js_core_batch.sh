#!/usr/bin/env bash
# Batch driver for the WASM js-core runner: processes the corpus in small chunks,
# each in a FRESH node process, so per-process wasm code-space / native memory
# never accumulates (a fresh OS process fully reclaims it). The browser verifier
# does not need this — it re-initialises the wasm module per page.
#   run_js_core_batch.sh <corpus.jsonl> <out.jsonl> [chunk_size]
set -euo pipefail
CORPUS="$1"; OUT="$2"
CHUNK=20
DUMP_ARG="${3:-}"
if [[ "${3:-}" =~ ^[0-9]+$ ]]; then
  CHUNK="$3"
  DUMP_ARG="${4:-}"
fi
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ARGS=()
[[ "$DUMP_ARG" == "--dump" ]] && ARGS+=(--dump)
SCRATCH_ROOT="${TMPDIR:-/var/tmp}"
case "$SCRATCH_ROOT" in /tmp|/tmp/*) SCRATCH_ROOT=/var/tmp ;; esac
TMP="$(mktemp -d "$SCRATCH_ROOT/htmltrust-study1-js-core.XXXXXX")"; trap 'rm -rf "$TMP"' EXIT
: > "$OUT"
if [[ ! -s "$CORPUS" ]]; then
  echo "js-core-batch: 0 records -> $OUT" >&2
  exit 0
fi
split -l "$CHUNK" -d -a 4 "$CORPUS" "$TMP/c"
for ch in "$TMP"/c*; do
  node "$HERE/run_js_core.mjs" "$ch" "$OUT" "${ARGS[@]}"
done
echo "js-core-batch: $(wc -l < "$OUT") records -> $OUT" >&2
