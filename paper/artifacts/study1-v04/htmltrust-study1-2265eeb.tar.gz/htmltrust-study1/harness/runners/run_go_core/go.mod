module study1/run-go-core

go 1.25.0
