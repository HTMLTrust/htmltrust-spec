// Go runner backed by the Rust canonicalization CORE via cgo + the C ABI,
// instead of the pure-Go port. Byte-identical to the Rust binding by
// construction (same code).
//
//	run-go-core <corpus.jsonl> <out.jsonl> [--dump]
package main

/*
#cgo LDFLAGS: -L${SRCDIR}/lib -Wl,-rpath,${SRCDIR}/lib -lhtmltrust_canonicalization_ffi
#include <stdlib.h>
extern int  htmltrust_extract_canonical_text(char* html, char* base, char** out);
extern void htmltrust_string_free(char* s);
*/
import "C"

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"unsafe"
)

type inRec struct {
	ID      string `json:"id"`
	HTML    string `json:"html"`
	BaseURL string `json:"base_url"`
}

// extract returns (canonicalText, ok). When ok is false the string is the
// canonicalization error code.
func extract(html, base string) (string, bool) {
	cHTML := C.CString(html)
	defer C.free(unsafe.Pointer(cHTML))
	var cBase *C.char
	if base != "" {
		cBase = C.CString(base)
		defer C.free(unsafe.Pointer(cBase))
	}
	var out *C.char
	rc := C.htmltrust_extract_canonical_text(cHTML, cBase, &out)
	s := C.GoString(out)
	C.htmltrust_string_free(out)
	return s, rc == 0
}

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: run-go-core <corpus> <out> [--dump]")
		os.Exit(2)
	}
	dump := false
	for _, a := range os.Args[3:] {
		if a == "--dump" {
			dump = true
		}
	}
	fin, err := os.Open(os.Args[1])
	if err != nil {
		panic(err)
	}
	defer fin.Close()
	fout, err := os.Create(os.Args[2])
	if err != nil {
		panic(err)
	}
	defer fout.Close()

	dec := json.NewDecoder(bufio.NewReaderSize(fin, 1<<20))
	w := bufio.NewWriterSize(fout, 1<<20)
	defer w.Flush()
	enc := json.NewEncoder(w)

	n := 0
	for {
		var r inRec
		if err := dec.Decode(&r); err != nil {
			break
		}
		s, ok := extract(r.HTML, r.BaseURL)
		var o map[string]interface{}
		if !ok {
			o = map[string]interface{}{"id": r.ID, "ok": false, "err": s}
		} else if dump {
			o = map[string]interface{}{"id": r.ID, "ok": true, "canon": s}
		} else {
			sum := sha256.Sum256([]byte(s))
			o = map[string]interface{}{"id": r.ID, "ok": true, "hash": hex.EncodeToString(sum[:]), "len": len(s)}
		}
		_ = enc.Encode(o)
		n++
	}
	fmt.Fprintf(os.Stderr, "go-core: %d records -> %s\n", n, os.Args[2])
}
