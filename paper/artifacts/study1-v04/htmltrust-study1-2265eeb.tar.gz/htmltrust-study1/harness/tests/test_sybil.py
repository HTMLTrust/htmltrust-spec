import importlib
import unittest


sybil = importlib.import_module("harness.sybil.analyze")


class SybilModelTests(unittest.TestCase):
    def test_raw_count_is_identity_sybillable(self):
        document = sybil.analyze()
        capability = document["minimum_attack_capability"]
        self.assertEqual(capability["raw_count_majority_identities"], 21)
        hundred = next(
            row
            for row in document["scenarios"]
            if row["name"] == "hundred-sybils-one-directory"
        )
        self.assertTrue(hundred["raw_count_majority"])

    def test_open_cap_limits_one_directory_but_not_many(self):
        document = sybil.analyze()
        one = next(
            row
            for row in document["scenarios"]
            if row["name"] == "hundred-sybils-one-directory"
        )
        many = next(
            row
            for row in document["scenarios"]
            if row["name"] == "hundred-sybils-twenty-directories"
        )
        self.assertFalse(one["open_cap_majority"])
        self.assertTrue(many["open_cap_majority"])
        self.assertEqual(
            document["minimum_attack_capability"]["open_cap_majority_directories"],
            5,
        )

    def test_configured_quorum_requires_directory_compromise(self):
        document = sybil.analyze()
        unconfigured = next(
            row
            for row in document["scenarios"]
            if row["name"] == "thousand-sybils-two-hundred-directories"
        )
        compromised = next(
            row
            for row in document["scenarios"]
            if row["name"] == "quorum-configured-directories-compromised"
        )
        self.assertEqual(unconfigured["configured_attacker_fraction"], 0)
        self.assertFalse(unconfigured["configured_quorum_reached"])
        self.assertTrue(compromised["configured_quorum_reached"])

    def test_quorum_validation(self):
        model = dict(sybil.DEFAULT_MODEL)
        model["configured_directory_quorum"] = 6
        with self.assertRaisesRegex(ValueError, "quorum"):
            sybil.analyze(model)

    def test_render_uses_custom_model_and_model_is_byte_deterministic(self):
        model = dict(sybil.DEFAULT_MODEL)
        model.update(
            {
                "honest_endorsements": 12,
                "configured_directories": 7,
                "open_directory_cap": 2,
                "configured_directory_quorum": 4,
            }
        )
        first = sybil.analyze(model)
        second = sybil.analyze(model)
        self.assertEqual(first, second)
        rendered = sybil.render_markdown(first)
        self.assertIn("12 honest endorsements", rendered)
        self.assertIn("4-of-7", rendered)
        self.assertIn("2-per-directory", rendered)


if __name__ == "__main__":
    unittest.main()
