import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


STUDY_ROOT = Path(__file__).resolve().parents[3]
SCRIPT = STUDY_ROOT / "harness" / "benchmarks" / "signing_v1.mjs"


class SigningBenchmarkTests(unittest.TestCase):
    def test_script_passes_node_syntax_check(self):
        node = shutil.which("node")
        if node is None:
            self.skipTest("Node.js is unavailable")
        result = subprocess.run(
            [node, "--check", str(SCRIPT)],
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_small_run_retains_provenance_timings_and_overhead(self):
        node = shutil.which("node")
        manifest = STUDY_ROOT / "vendor" / "CANON_SOURCE_TREE.json"
        if node is None or not manifest.is_file():
            self.skipTest("requires Node.js and the prepared canonicalization manifest")
        scratch = os.environ.get("TMPDIR") or str(Path.home() / "tmp")
        if (
            Path(scratch).resolve() == Path("/tmp")
            or Path("/tmp") in Path(scratch).resolve().parents
        ):
            self.skipTest("TMPDIR points at RAM-backed /tmp")
        with tempfile.TemporaryDirectory(dir=scratch) as directory:
            output = Path(directory) / "signing.json"
            markdown = Path(directory) / "signing.md"
            result = subprocess.run(
                [
                    node,
                    str(SCRIPT),
                    "--output",
                    str(output),
                    "--markdown",
                    str(markdown),
                    "--warmups",
                    "1",
                    "--iterations",
                    "2",
                ],
                check=False,
                capture_output=True,
                text=True,
                env={
                    **os.environ,
                    "HTMLTRUST_IMAGE_ID": "sha256:" + "a" * 64,
                },
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            document = json.loads(output.read_text(encoding="utf-8"))
        self.assertEqual(document["schema"], "htmltrust-study1-signing-benchmark-v1")
        self.assertEqual(
            document["benchmark_scope"],
            "node_in_process_canonicalization_ed25519_sign_verify",
        )
        self.assertEqual(document["iterations"], 2)
        self.assertEqual(document["image_id"], "sha256:" + "a" * 64)
        self.assertEqual(
            document["canonicalization_revision"],
            json.loads(manifest.read_text(encoding="utf-8"))["revision"],
        )
        self.assertEqual(len(document["results"]), 4)
        for row in document["results"]:
            self.assertEqual(len(row["timings_ns"]), 2)
            self.assertEqual(row["signature_bytes"], 64)
            self.assertRegex(row["content_hash"], r"^sha256:[A-Za-z0-9+/]{43}$")
            self.assertRegex(row["claims_hash"], r"^sha256:[A-Za-z0-9+/]{43}$")
            self.assertGreater(
                row["signed_section_markup_bytes"], row["input_html_bytes"]
            )
            self.assertGreater(row["markup_overhead_bytes"], 0)
            self.assertTrue(
                all(sample["verify_ns"] > 0 for sample in row["timings_ns"])
            )
        self.assertIn(
            "HTMLTrust v1 signing benchmark", markdown.read_text(encoding="utf-8")
        )


if __name__ == "__main__":
    unittest.main()
