"""Tests for the isolated benchmark harness."""
