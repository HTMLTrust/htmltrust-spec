import importlib
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock


benchmark = importlib.import_module("harness.benchmarks.benchmark")
summarize = importlib.import_module("harness.benchmarks.summarize")


class BenchmarkInputTests(unittest.TestCase):
    def test_standard_sizes_are_exact_and_repeatable(self):
        for size in benchmark.SIZES:
            first = benchmark.synthetic_html(size)
            second = benchmark.synthetic_html(size)
            self.assertEqual(first, second)
            self.assertEqual(len(first.encode("utf-8")), size)
            self.assertIn('data-bench="htmltrust-study1"', first)

    def test_jsonl_record_has_stable_base_url(self):
        record = benchmark.synthetic_record(1024)
        encoded = json.dumps(record, separators=(",", ":"))
        self.assertEqual(
            record["base_url"], "https://bench.example.test/articles/deterministic"
        )
        self.assertEqual(json.loads(encoded), record)


class AggregationTests(unittest.TestCase):
    def test_nearest_rank_percentile(self):
        self.assertEqual(benchmark.percentile([4, 1, 3, 2], 0.5), 2.0)
        self.assertEqual(benchmark.percentile([1, 2, 3, 4, 5], 0.95), 5.0)

    def test_complete_matrix_is_validated_and_summarized(self):
        environment = {
            "canonicalization_revision": "a" * 40,
            "iterations": 2,
            "warmups": 1,
            "synthetic_sizes_bytes": list(benchmark.SIZES),
        }
        metadata = {
            "record_type": "metadata",
            "schema": "htmltrust-study1-canonicalization-benchmark/v1",
            "environment": environment,
        }
        fixtures = [f"synthetic-{size}" for size in benchmark.SIZES] + [
            "corpus-sample-8"
        ]
        rows = []
        for language in benchmark.LANGUAGES:
            for fixture in fixtures:
                rows.append(
                    {
                        "schema": "htmltrust-study1-canonicalization-benchmark/v1",
                        "language": language,
                        "fixture": fixture,
                        "input_size_bytes": 1024,
                        "input_records": 1,
                        "warmup_iterations": 1,
                        "iterations": 2,
                        "timing_scope": "runner_process_including_jsonl_io_and_canonicalization",
                        "timeout_seconds": 120,
                        "times_ns": [1_000_000, 2_000_000],
                        "median_ns": 1_500_000,
                        "p95_ns": 2_000_000,
                        "throughput_bytes_per_second": 1024 * 1_000_000_000 / 1_500_000,
                        "success_count": 2,
                        "rejection_count": 0,
                        "runner_failure_count": 0,
                        "success_count_per_iteration": 1,
                        "rejection_count_per_iteration": 0,
                        "runner_failure_count_per_iteration": 0,
                        "output_length_bytes": 10,
                        "output_length_mean_bytes": 10,
                        "output_length_min_bytes": 10,
                        "output_length_max_bytes": 10,
                        "status": "ok",
                    }
                )
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "benchmark.jsonl"
            path.write_text(
                "\n".join(json.dumps(record) for record in [metadata, *rows]) + "\n",
                encoding="utf-8",
            )
            loaded_metadata, loaded_rows = summarize.read_benchmark(path)
        document = summarize.summarize(loaded_metadata, loaded_rows)
        self.assertTrue(document["matrix_complete"])
        self.assertTrue(document["all_runs_valid"])
        self.assertEqual(document["runner_failures"], 0)
        rows[0]["median_ns"] = -1
        with self.assertRaisesRegex(ValueError, "median_ns"):
            summarize.summarize(metadata, rows)

    def test_corpus_selection_is_digest_sorted_and_limited(self):
        records = [
            {"id": f"id-{i}", "html": f"<p>{i}</p>", "base_url": "https://example.test"}
            for i in range(5)
        ]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "corpus.jsonl"
            path.write_text(
                "".join(json.dumps(record) + "\n" for record in reversed(records)),
                encoding="utf-8",
            )
            selected = benchmark.read_corpus_sample(path, 3)
        expected = sorted(
            records,
            key=lambda record: hashlib.sha256(record["id"].encode()).hexdigest(),
        )[:3]
        self.assertEqual(selected, expected)

    def test_corpus_selection_uses_base_url_and_content_as_stable_tiebreakers(self):
        records = [
            {
                "id": "duplicate",
                "html": "<p>same</p>",
                "base_url": "https://b.example/",
            },
            {
                "id": "duplicate",
                "html": "<p>same</p>",
                "base_url": "https://a.example/",
            },
            {"html": "<p>anonymous</p>", "base_url": "https://c.example/"},
        ]
        with tempfile.TemporaryDirectory() as directory:
            first_path = Path(directory) / "first.jsonl"
            second_path = Path(directory) / "second.jsonl"
            first_path.write_text(
                "".join(json.dumps(record) + "\n" for record in records),
                encoding="utf-8",
            )
            second_path.write_text(
                "".join(json.dumps(record) + "\n" for record in reversed(records)),
                encoding="utf-8",
            )
            first = benchmark.read_corpus_sample(first_path, len(records))
            second = benchmark.read_corpus_sample(second_path, len(records))
        self.assertEqual(first, second)
        self.assertTrue(any(record["id"].startswith("content:") for record in first))

    def test_benchmark_case_aggregates_successes_and_lengths(self):
        # A tiny deterministic stand-in lets this test exercise the timing and
        # aggregation path without requiring the study image's language deps.
        code = (
            "import json,sys; "
            "rows=[json.loads(x) for x in open(sys.argv[1]) if x.strip()]; "
            "open(sys.argv[2],'w').write(''.join(json.dumps({'id':r['id'],'ok':True,'hash':'0'*64,'len':7})+'\\n' for r in rows))"
        )
        records = [benchmark.synthetic_record(1024)]
        with tempfile.TemporaryDirectory() as directory:
            result = benchmark.benchmark_case(
                "fake",
                "synthetic-1024",
                records,
                [sys.executable, "-c", code],
                1,
                3,
                Path(directory),
                dict(os.environ),
            )
        self.assertEqual(result["iterations"], 3)
        self.assertEqual(len(result["times_ns"]), 3)
        self.assertEqual(result["success_count"], 3)
        self.assertEqual(result["rejection_count"], 0)
        self.assertEqual(result["runner_failure_count"], 0)
        self.assertEqual(result["output_length_bytes"], 7)
        self.assertEqual(result["status"], "ok")

    def test_benchmark_case_rejects_extra_records(self):
        code = (
            "import json,sys; "
            "r=json.loads(open(sys.argv[1]).readline()); "
            "row=json.dumps({'id':r['id'],'ok':True,'len':7})+'\\n'; "
            "open(sys.argv[2],'w').write(row+row)"
        )
        with tempfile.TemporaryDirectory() as directory:
            result = benchmark.benchmark_case(
                "fake",
                "extra-output",
                [benchmark.synthetic_record(1024)],
                [sys.executable, "-c", code],
                0,
                1,
                Path(directory),
                dict(os.environ),
            )
        self.assertEqual(result["success_count"], 0)
        self.assertEqual(result["runner_failure_count"], 1)
        self.assertEqual(result["status"], "error")

    def test_benchmark_case_records_missing_output_and_invalid_length(self):
        records = [benchmark.synthetic_record(1024)]
        with tempfile.TemporaryDirectory() as directory:
            missing = benchmark.benchmark_case(
                "fake",
                "missing-output",
                records,
                [sys.executable, "-c", "pass"],
                0,
                1,
                Path(directory),
                dict(os.environ),
            )
            bad_length_code = (
                "import json,sys; "
                "r=json.loads(open(sys.argv[1]).readline()); "
                "open(sys.argv[2],'w').write(json.dumps({'id':r['id'],'ok':True,'len':'bad'})+'\\n')"
            )
            bad_length = benchmark.benchmark_case(
                "fake",
                "bad-length",
                records,
                [sys.executable, "-c", bad_length_code],
                0,
                1,
                Path(directory),
                dict(os.environ),
            )
        self.assertEqual(missing["runner_failure_count"], 1)
        self.assertEqual(missing["status"], "error")
        self.assertEqual(bad_length["runner_failure_count"], 1)
        self.assertEqual(bad_length["status"], "error")

    def test_benchmark_case_rejects_invalid_success_digest(self):
        records = [benchmark.synthetic_record(1024)]
        for digest in (None, "0" * 63, "0" * 65, "A" * 64, "g" * 64):
            with self.subTest(digest=digest):
                digest_literal = repr(digest)
                code = (
                    "import json,sys; "
                    "r=json.loads(open(sys.argv[1]).readline()); "
                    f"row=json.dumps({{'id':r['id'],'ok':True,'hash':{digest_literal},'len':7}})+'\\n'; "
                    "open(sys.argv[2],'w').write(row)"
                )
                with tempfile.TemporaryDirectory() as directory:
                    result = benchmark.benchmark_case(
                        "fake",
                        "bad-digest",
                        records,
                        [sys.executable, "-c", code],
                        0,
                        1,
                        Path(directory),
                        dict(os.environ),
                    )
                self.assertEqual(result["success_count"], 0)
                self.assertEqual(result["runner_failure_count"], 1)
                self.assertEqual(result["status"], "error")
                self.assertIn("digest", result["runner_errors"][0])

    def test_benchmark_case_accepts_profile_rejections_as_valid_output(self):
        code = (
            "import json,sys; "
            "rows=[json.loads(x) for x in open(sys.argv[1]) if x.strip()]; "
            "open(sys.argv[2],'w').write(''.join(json.dumps({'id':r['id'],'ok':False,'err':'parser-profile-unsupported'})+'\\n' for r in rows))"
        )
        records = [benchmark.synthetic_record(1024)]
        with tempfile.TemporaryDirectory() as directory:
            result = benchmark.benchmark_case(
                "fake",
                "profile-rejection",
                records,
                [sys.executable, "-c", code],
                0,
                2,
                Path(directory),
                dict(os.environ),
            )
        self.assertEqual(result["success_count"], 0)
        self.assertEqual(result["rejection_count"], 2)
        self.assertEqual(result["runner_failure_count"], 0)
        self.assertEqual(result["status"], "ok")
        self.assertIn("parser-profile-unsupported", result["rejections"])

    def test_benchmark_case_times_out_a_stuck_runner(self):
        with tempfile.TemporaryDirectory() as directory:
            result = benchmark.benchmark_case(
                "fake",
                "timeout",
                [benchmark.synthetic_record(1024)],
                [sys.executable, "-c", "import time; time.sleep(1)"],
                0,
                1,
                Path(directory),
                dict(os.environ),
                timeout_seconds=0.01,
            )
        self.assertEqual(result["runner_failure_count"], 1)
        self.assertEqual(result["status"], "error")
        self.assertIn("timed out", result["runner_errors"][0])

    def test_main_fails_when_a_runner_fails(self):
        safe_tmp = Path(os.environ.get("TMPDIR") or "/var/tmp")
        with tempfile.TemporaryDirectory(dir=safe_tmp) as directory:
            output = Path(directory) / "benchmark.jsonl"
            commands = {"go": [sys.executable, "-c", "raise SystemExit(7)"]}
            with mock.patch.object(benchmark, "runner_commands", return_value=commands):
                result = benchmark.main(
                    [
                        "--output",
                        str(output),
                        "--language",
                        "go",
                        "--warmups",
                        "0",
                        "--iterations",
                        "1",
                    ]
                )
        self.assertEqual(result, 1)


if __name__ == "__main__":
    unittest.main()
