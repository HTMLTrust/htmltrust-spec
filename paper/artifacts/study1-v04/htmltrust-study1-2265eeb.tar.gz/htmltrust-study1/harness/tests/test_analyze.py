#!/usr/bin/env python3
"""Focused tests for Study 1 statistics and denominator reporting."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


MODULE_PATH = Path(__file__).resolve().parents[1] / "analyze.py"
SPEC = importlib.util.spec_from_file_location("study_analyze", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
ANALYZE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ANALYZE)


class StatsTests(unittest.TestCase):
    def test_reports_acceptance_and_both_agreement_denominators(self) -> None:
        with tempfile.TemporaryDirectory() as raw_dir:
            run_dir = Path(raw_dir)
            left = [
                {"id": "z", "ok": True, "hash": "0" * 64, "len": 1},
                {"id": "a", "ok": True, "hash": "1" * 64, "len": 1},
                {"id": "m", "ok": False, "err": "left-rejected"},
            ]
            right = [
                {"id": "m", "ok": True, "hash": "2" * 64, "len": 1},
                {"id": "a", "ok": True, "hash": "3" * 64, "len": 1},
                {"id": "z", "ok": True, "hash": "0" * 64, "len": 1},
            ]
            for name, rows in (("left", left), ("right", right)):
                (run_dir / f"{name}.jsonl").write_text(
                    "".join(json.dumps(row) + "\n" for row in rows),
                    encoding="utf-8",
                )

            corpus = run_dir / "corpus.jsonl"
            corpus.write_text(
                "".join(
                    json.dumps({"id": record_id, "html": "<p>x</p>"}) + "\n"
                    for record_id in ("a", "m", "z")
                ),
                encoding="utf-8",
            )

            ANALYZE.cmd_stats(run_dir, ["left", "right"], corpus)
            stats = json.loads((run_dir / "stats.json").read_text(encoding="utf-8"))

            self.assertEqual(stats["n"], 3)
            self.assertEqual(stats["all_ok"], 2)
            self.assertAlmostEqual(stats["all_ok_rate"], 2 / 3)
            self.assertEqual(stats["all_agree"], 1)
            self.assertAlmostEqual(stats["all_agree_rate"], 1 / 2)
            self.assertAlmostEqual(stats["all_agree_corpus_rate"], 1 / 3)
            self.assertEqual(stats["status_agree"], 2)
            self.assertAlmostEqual(stats["status_agree_rate"], 2 / 3)
            self.assertEqual(
                (run_dir / "disagree.ids").read_text(encoding="utf-8"),
                "a\nm\n",
            )

    def test_rejects_missing_extra_and_duplicate_ids(self) -> None:
        with tempfile.TemporaryDirectory() as raw_dir:
            run_dir = Path(raw_dir)
            (run_dir / "corpus.jsonl").write_text(
                json.dumps({"id": "expected", "html": "<p>x</p>"}) + "\n",
                encoding="utf-8",
            )
            (run_dir / "left.jsonl").write_text(
                json.dumps({"id": "other", "ok": True, "hash": "0" * 64, "len": 1})
                + "\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "1 missing, 1 extra"):
                ANALYZE.cmd_stats(run_dir, ["left"], run_dir / "corpus.jsonl")

            (run_dir / "left.jsonl").write_text(
                json.dumps({"id": "expected", "ok": True, "hash": "0" * 64, "len": 1})
                + "\n"
                + json.dumps({"id": "expected", "ok": True, "hash": "0" * 64, "len": 1})
                + "\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "duplicate id"):
                ANALYZE.cmd_stats(run_dir, ["left"], run_dir / "corpus.jsonl")

    def test_taxonomy_requires_every_disagreement_dump(self) -> None:
        with tempfile.TemporaryDirectory() as raw_dir:
            run_dir = Path(raw_dir)
            (run_dir / "dump").mkdir()
            (run_dir / "disagree.ids").write_text("expected\n", encoding="utf-8")
            (run_dir / "dump" / "rust.jsonl").write_text(
                json.dumps({"id": "expected", "ok": True, "canon": "x"}) + "\n",
                encoding="utf-8",
            )
            (run_dir / "dump" / "python.jsonl").write_text("", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "1 missing, 0 extra"):
                ANALYZE.cmd_taxonomy(run_dir, "rust", ["python"])

    def test_rejects_malformed_runner_result_schema(self) -> None:
        with tempfile.TemporaryDirectory() as raw_dir:
            path = Path(raw_dir) / "bad.jsonl"
            malformed = [
                {"id": "truthy", "ok": "yes", "hash": "0" * 64, "len": 1},
                {"id": "hash", "ok": True, "hash": "short", "len": 1},
                {"id": "length", "ok": True, "hash": "0" * 64, "len": -1},
                {"id": "error", "ok": False, "err": ""},
            ]
            patterns = (
                "ok must be boolean",
                "invalid SHA-256",
                "invalid output length",
                "missing error string",
            )
            for row, pattern in zip(malformed, patterns, strict=True):
                with self.subTest(record=row["id"]):
                    path.write_text(json.dumps(row) + "\n", encoding="utf-8")
                    with self.assertRaisesRegex(ValueError, pattern):
                        ANALYZE.load(path)


if __name__ == "__main__":
    unittest.main()
