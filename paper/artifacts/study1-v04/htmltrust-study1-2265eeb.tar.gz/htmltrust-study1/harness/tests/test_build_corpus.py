#!/usr/bin/env python3
"""Tests for exact, parser-independent body-source slicing."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock

from harness import build_corpus
from harness.build_corpus import (
    body_slice,
    decode_html,
    ensure_unique_id,
    read_response,
    sha1_id,
    sha256_file,
    url_allowed,
)


class _ContentRecord:
    def __init__(self, raw: bytes) -> None:
        self.raw = raw

    def content_stream(self):
        from io import BytesIO

        return BytesIO(self.raw)


class _Headers:
    def __init__(
        self, *, content_type: str, status: str = "200", target_uri: str = ""
    ) -> None:
        self.content_type = content_type
        self.status = status
        self.target_uri = target_uri

    def get_header(self, name: str) -> str:
        if name.lower() == "content-type":
            return self.content_type
        if name.lower() == "warc-target-uri":
            return self.target_uri
        return ""

    def get_statuscode(self) -> str:
        return self.status


class _WarcRecord(_ContentRecord):
    rec_type = "response"

    def __init__(self, url: str, raw: bytes, content_type: str) -> None:
        super().__init__(raw)
        self.http_headers = _Headers(content_type=content_type)
        self.rec_headers = _Headers(content_type="", target_uri=url)
        self.url = url

    def get_target_uri(self) -> str:
        return self.url


def _fake_warcio(records: list[_WarcRecord]) -> dict[str, types.ModuleType]:
    archiveiterator = types.ModuleType("warcio.archiveiterator")
    archiveiterator.ArchiveIterator = lambda stream: records
    warcio = types.ModuleType("warcio")
    warcio.archiveiterator = archiveiterator
    return {"warcio": warcio, "warcio.archiveiterator": archiveiterator}


class BodySliceTests(unittest.TestCase):
    def test_accepts_case_insensitive_closing_tag(self) -> None:
        self.assertEqual(body_slice("<html><BODY><p>x</p></BODY></html>"), "<p>x</p>")

    def test_ignores_body_text_inside_script_and_quoted_attributes(self) -> None:
        source = '<script>"<body>fake</body>"</script><div data-x="<body>"></div><body>x</body>'
        self.assertEqual(body_slice(source), "x")

    def test_uses_first_real_body_end_outside_raw_text(self) -> None:
        source = '<body><script>const x = "</body>";</script><p>kept</p></body><p>outside</p>'
        self.assertEqual(
            body_slice(source), '<script>const x = "</body>";</script><p>kept</p>'
        )

    def test_unclosed_body_returns_remaining_source(self) -> None:
        self.assertEqual(body_slice("<body><p>x"), "<p>x")

    def test_ignores_body_tokens_in_opaque_contexts(self) -> None:
        for wrapper in ("noscript", "template", "svg", "math"):
            with self.subTest(wrapper=wrapper):
                source = (
                    f"<{wrapper}><body>fake</body></{wrapper}><body><p>real</p></body>"
                )
                self.assertEqual(body_slice(source), "<p>real</p>")


class CorpusPolicyTests(unittest.TestCase):
    def test_manifest_records_charset_fallback_and_corpus_hash(self) -> None:
        raw = "<body>café</body>".encode("utf-8")
        record = _WarcRecord(
            "https://example.test/story",
            raw,
            "text/html; charset=declared-but-unknown",
        )
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            warc = root / "001.warc.gz"
            warc.write_bytes(b"fake WARC bytes")
            output = root / "corpus.jsonl"
            with mock.patch.dict(sys.modules, _fake_warcio([record])):
                result = build_corpus.main(
                    [
                        "--warc-dir",
                        str(root),
                        "--warc-limit",
                        "1",
                        "--target",
                        "1",
                        "--stride",
                        "1",
                        "--min-bytes",
                        "0",
                        "--max-bytes",
                        str(len(raw)),
                        "--max-response-bytes",
                        str(len(raw)),
                        "--out",
                        str(output),
                    ]
                )
            self.assertEqual(result, 0)
            corpus_record = json.loads(output.read_text(encoding="utf-8"))
            manifest = json.loads(
                (root / "corpus.manifest.json").read_text(encoding="utf-8")
            )
            self.assertEqual(corpus_record["declared_charset"], "declared-but-unknown")
            self.assertEqual(corpus_record["charset"], "utf-8")
            self.assertEqual(manifest["counts"]["charset_fallback"], 1)
            self.assertEqual(manifest["corpus_sha256"], sha256_file(output))
            self.assertEqual(manifest["warcs_scanned"][0]["sha256"], sha256_file(warc))

    def test_provenance_hash_helpers_match_standard_digests(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "warc.gz"
            path.write_bytes(b"source bytes")
            self.assertEqual(
                sha256_file(path), hashlib.sha256(b"source bytes").hexdigest()
            )
        url = "https://example.test/story"
        self.assertEqual(sha1_id(url), hashlib.sha1(url.encode()).hexdigest()[:16])

    def test_unknown_charset_falls_back_to_utf8_and_reports_it(self) -> None:
        html, used_charset, fallback = decode_html(
            "<body>café</body>".encode("utf-8"), "x-unknown-charset"
        )
        self.assertEqual(html, "<body>café</body>")
        self.assertEqual(used_charset, "utf-8")
        self.assertTrue(fallback)

    def test_response_size_accepts_limit_and_rejects_one_byte_over(self) -> None:
        at_limit, allowed = read_response(_ContentRecord(b"1234"), 4)
        over_limit, over_allowed = read_response(_ContentRecord(b"12345"), 4)
        self.assertEqual(at_limit, b"1234")
        self.assertTrue(allowed)
        self.assertEqual(over_limit, b"12345")
        self.assertFalse(over_allowed)

    def test_url_policy_enforces_scheme_credentials_and_controls(self) -> None:
        self.assertTrue(url_allowed("https://example.test/a", "https"))
        self.assertFalse(url_allowed("http://example.test/a", "https"))
        self.assertTrue(url_allowed("http://example.test/a", "http-https"))
        self.assertFalse(url_allowed("https://user@example.test/a", "https"))
        self.assertFalse(url_allowed("https://example.test/a\n", "https"))
        self.assertFalse(url_allowed("mailto:a@example.test", "http-https"))

    def test_truncated_sha1_id_collision_is_rejected(self) -> None:
        written = {"deadbeefdeadbeef": "https://one.example/"}
        with self.assertRaisesRegex(RuntimeError, "SHA-1 ID collision"):
            ensure_unique_id(written, "deadbeefdeadbeef", "https://two.example/")
        ensure_unique_id(written, "deadbeefdeadbeef", "https://one.example/")

    def test_main_rejects_collision_between_distinct_urls(self) -> None:
        raw = b"<body>content</body>"
        records = [
            _WarcRecord(f"https://example.test/{name}", raw, "text/html")
            for name in ("one", "two")
        ]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "001.warc.gz").write_bytes(b"fake WARC bytes")
            with mock.patch.dict(sys.modules, _fake_warcio(records)):
                with mock.patch.object(build_corpus, "sha1_id", return_value="0" * 16):
                    with self.assertRaisesRegex(RuntimeError, "SHA-1 ID collision"):
                        build_corpus.main(
                            [
                                "--warc-dir",
                                str(root),
                                "--warc-limit",
                                "1",
                                "--target",
                                "2",
                                "--stride",
                                "1",
                                "--min-bytes",
                                "0",
                                "--max-bytes",
                                "100",
                                "--out",
                                str(root / "corpus.jsonl"),
                            ]
                        )


if __name__ == "__main__":
    unittest.main()
