import importlib
import json
from pathlib import Path
import tempfile
import unittest


evaluate = importlib.import_module("harness.adversarial.evaluate")


class LoadCasesTests(unittest.TestCase):
    def _fixture(self, root: Path, relative: str, document: dict) -> None:
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(document), encoding="utf-8")

    def test_fixture_repeat_base_url_and_normalize_wrapping(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self._fixture(
                root,
                "extract/a.json",
                {
                    "name": "repeat",
                    "input": "@",
                    "repeat": 2,
                    "error": "limit",
                    "baseURL": "https://e.test/",
                },
            )
            self._fixture(
                root,
                "normalize/b.json",
                {"name": "bidi", "input": "a\u202ab", "expected": "ab"},
            )
            original = evaluate.SELECTIONS
            evaluate.SELECTIONS = (
                ("resource", "extract/*.json", False),
                ("unicode", "normalize/*.json", True),
            )
            try:
                cases = evaluate.load_cases(root)
            finally:
                evaluate.SELECTIONS = original
        by_id = {case["id"]: case for case in cases}
        self.assertEqual(by_id["repeat"]["html"], "@@")
        self.assertEqual(by_id["repeat"]["base_url"], "https://e.test/")
        self.assertEqual(by_id["repeat"]["expected"], "reject")
        self.assertEqual(by_id["bidi"]["html"], "<p>a\u202ab</p>")
        self.assertEqual(
            by_id["bidi"]["expected_canonical_sha256"],
            evaluate.hashlib.sha256(b"ab").hexdigest(),
        )


class AssessmentTests(unittest.TestCase):
    def test_acceptance_requires_digest_consensus(self):
        cases = [
            {
                "id": "accepted",
                "category": "parser",
                "description": "",
                "source_fixture": "accepted.json",
                "source_fixture_sha256": "0" * 64,
                "expected": "accept",
                "expected_error": None,
                "expected_canonical_sha256": "a" * 64,
                "expected_canonical_bytes": 1,
            }
        ]
        outputs = {
            language: {
                "accepted": {"id": "accepted", "ok": True, "hash": "a" * 64, "len": 1}
            }
            for language in evaluate.LANGUAGES
        }
        results, summary = evaluate.assess(cases, outputs)
        self.assertTrue(results[0]["passed"])
        self.assertTrue(summary["all_passed"])
        outputs["python"]["accepted"]["hash"] = "b" * 64
        results, summary = evaluate.assess(cases, outputs)
        self.assertFalse(results[0]["digest_consensus"])
        self.assertFalse(summary["all_passed"])

    def test_rejection_requires_normative_error(self):
        case = {
            "id": "rejected",
            "category": "url",
            "description": "",
            "source_fixture": "rejected.json",
            "source_fixture_sha256": "0" * 64,
            "expected": "reject",
            "expected_error": "url-policy-violation",
            "expected_canonical_sha256": None,
            "expected_canonical_bytes": None,
        }
        outputs = {
            language: {
                "rejected": {
                    "id": "rejected",
                    "ok": False,
                    "err": "url-policy-violation",
                }
            }
            for language in evaluate.LANGUAGES
        }
        self.assertTrue(evaluate.assess([case], outputs)[1]["all_passed"])
        outputs["go"]["rejected"]["err"] = "parser-profile-unsupported"
        self.assertFalse(evaluate.assess([case], outputs)[1]["all_passed"])

    def test_protocol_error_code_is_exact_after_language_prefix(self):
        self.assertEqual(
            evaluate.normalized_error_code(
                "ValueError: parser-profile-unsupported: details"
            ),
            "parser-profile-unsupported",
        )
        self.assertIsNone(
            evaluate.normalized_error_code("bad parser-profile-unsupported suffix")
        )

    def test_output_digest_must_be_lowercase_sha256(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "output.jsonl"
            path.write_text(
                json.dumps({"id": "x", "ok": True, "hash": "z" * 64, "len": 1}) + "\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "invalid digest"):
                evaluate._read_output(path, {"x"})


if __name__ == "__main__":
    unittest.main()
