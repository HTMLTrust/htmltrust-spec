#!/usr/bin/env python3
"""Study 1 / Experiment E2: stability under publishing transformations.

For each corpus record we compute the canonical hash of the original HTML, then
of the HTML after each representative transformation a publishing pipeline
might apply, and report how often the canonical hash is preserved. This is a
byte-level stability measurement. It does not establish that each transform
preserves rendered meaning.

Uses the Python canonicalization binding as the reference verifier.
  stability.py <corpus.jsonl> <out.json>
"""

from __future__ import annotations
import json
import sys
import os
import hashlib
import re
from collections import Counter
from pathlib import Path

STUDY_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CANON_ROOT = os.environ.get(
    "CANON_ROOT",
    os.path.join(STUDY_ROOT, "vendor", "htmltrust-canonicalization"),
)
sys.path.insert(0, os.path.join(CANON_ROOT, "python"))
from htmltrust_canonicalization import extract_canonical_text  # noqa: E402
from bs4 import BeautifulSoup  # noqa: E402


def canon_result(html: str, base: str):
    try:
        c = extract_canonical_text(html, base_url=base)
        return hashlib.sha256(c.encode("utf-8")).hexdigest(), None
    except Exception as e:  # noqa: BLE001
        return None, type(e).__name__


# --- benign transformations ---------------------------------------------------
def t_reserialize_htmlparser(html: str) -> str:
    return str(BeautifulSoup(html, "html.parser"))


def t_reserialize_lxml(html: str) -> str:
    return str(BeautifulSoup(html, "lxml"))


_BETWEEN_TAGS = re.compile(r">(\s*)<")


def t_whitespace_reflow(html: str) -> str:
    # This raw-markup perturbation can affect inline rendering. It measures
    # byte sensitivity and is not classified as semantics-preserving.
    return _BETWEEN_TAGS.sub(">\n  <", html)


def t_lowercase_tags(html: str) -> str:
    return re.sub(
        r"(</?)([A-Za-z][A-Za-z0-9]*)", lambda m: m.group(1) + m.group(2).lower(), html
    )


def t_entity_reencoding(html: str) -> str:
    equivalents = {
        "&amp;": "&#38;",
        "&lt;": "&#60;",
        "&gt;": "&#62;",
        "&quot;": "&#34;",
        "&apos;": "&#39;",
    }
    for named, numeric in equivalents.items():
        html = html.replace(named, numeric)
    return html


TRANSFORMS = {
    "reserialize_htmlparser": t_reserialize_htmlparser,
    "reserialize_lxml": t_reserialize_lxml,
    "intertag_whitespace_insertion": t_whitespace_reflow,
    "lowercase_tags": t_lowercase_tags,
    "entity_reencoding": t_entity_reencoding,
}


def main() -> int:
    corpus, out = sys.argv[1], sys.argv[2]
    attempted = Counter()
    totals = Counter()
    preserved = Counter()
    rejected = Counter()
    changed = Counter()
    transform_errors = Counter()
    transformed_error_types = {name: Counter() for name in TRANSFORMS}
    original_error_types = Counter()
    err_orig = 0
    n = 0
    examples = {k: [] for k in TRANSFORMS}
    with open(corpus, encoding="utf-8") as source:
        for line in source:
            if not line.strip():
                continue
            r = json.loads(line)
            base = r.get("base_url")
            h0, original_error = canon_result(r["html"], base)
            if original_error is not None:
                err_orig += 1
                original_error_types[original_error] += 1
                continue  # only measure stability where the original itself canonicalizes
            n += 1
            for name, fn in TRANSFORMS.items():
                attempted[name] += 1
                try:
                    ht = fn(r["html"])
                except Exception as e:  # noqa: BLE001
                    transform_errors[f"{name}:{type(e).__name__}"] += 1
                    continue
                h1, transformed_error = canon_result(ht, base)
                totals[name] += 1
                if transformed_error is not None:
                    rejected[name] += 1
                    transformed_error_types[name][transformed_error] += 1
                elif h1 == h0:
                    preserved[name] += 1
                else:
                    changed[name] += 1
                if h1 != h0 and len(examples[name]) < 5:
                    examples[name].append(r["id"])

    version_path = Path(STUDY_ROOT) / "vendor" / "CANON_VERSION.txt"
    canonicalization_revision = None
    if version_path.is_file():
        canonicalization_revision = version_path.read_text(
            encoding="utf-8"
        ).splitlines()[0]
    result = {
        "binding": "python",
        "canonicalization_revision": canonicalization_revision,
        "n_canonicalizable": n,
        "n_original_errored": err_orig,
        "original_error_types": dict(original_error_types.most_common()),
        "transform_errors": dict(transform_errors.most_common()),
        "transformed_error_types": {
            name: dict(counts.most_common())
            for name, counts in transformed_error_types.items()
        },
        "transforms": {
            k: {
                "attempted": attempted[k],
                "tested": totals[k],
                "transform_failed": attempted[k] - totals[k],
                "preserved": preserved[k],
                "rejected": rejected[k],
                "hash_changed": changed[k],
                "preservation_rate": preserved[k] / totals[k] if totals[k] else None,
                "example_breaks": examples[k],
            }
            for k in TRANSFORMS
        },
    }
    Path(out).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {k: result["transforms"][k]["preservation_rate"] for k in TRANSFORMS},
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
