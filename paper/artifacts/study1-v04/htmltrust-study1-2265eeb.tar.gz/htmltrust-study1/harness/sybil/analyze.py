#!/usr/bin/env python3
"""Compare endorsement policies under explicit Sybil attack capabilities.

This is a policy sensitivity model, not a measurement of real attacker cost.
It makes the trust assumptions visible by comparing raw identity counts, an
open per-directory cap, and a configured-directory quorum.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
import sys
from typing import Any


DEFAULT_MODEL = {
    "honest_endorsements": 20,
    "configured_directories": 5,
    "open_directory_cap": 5,
    "configured_directory_quorum": 3,
}

SCENARIOS: tuple[dict[str, Any], ...] = (
    {
        "name": "control",
        "sybil_identities": 0,
        "attacker_directories": 0,
        "compromised_configured_directories": 0,
    },
    {
        "name": "one-sybil",
        "sybil_identities": 1,
        "attacker_directories": 1,
        "compromised_configured_directories": 0,
    },
    {
        "name": "five-sybils-one-directory",
        "sybil_identities": 5,
        "attacker_directories": 1,
        "compromised_configured_directories": 0,
    },
    {
        "name": "twenty-sybils-one-directory",
        "sybil_identities": 20,
        "attacker_directories": 1,
        "compromised_configured_directories": 0,
    },
    {
        "name": "hundred-sybils-one-directory",
        "sybil_identities": 100,
        "attacker_directories": 1,
        "compromised_configured_directories": 0,
    },
    {
        "name": "hundred-sybils-twenty-directories",
        "sybil_identities": 100,
        "attacker_directories": 20,
        "compromised_configured_directories": 0,
    },
    {
        "name": "thousand-sybils-two-hundred-directories",
        "sybil_identities": 1000,
        "attacker_directories": 200,
        "compromised_configured_directories": 0,
    },
    {
        "name": "one-configured-directory-compromised",
        "sybil_identities": 100,
        "attacker_directories": 1,
        "compromised_configured_directories": 1,
    },
    {
        "name": "quorum-configured-directories-compromised",
        "sybil_identities": 300,
        "attacker_directories": 3,
        "compromised_configured_directories": 3,
    },
)


def fraction(attacker: int, honest: int) -> float:
    total = attacker + honest
    return attacker / total if total else 0.0


def evaluate_scenario(
    scenario: dict[str, Any], model: dict[str, int]
) -> dict[str, Any]:
    sybils = int(scenario["sybil_identities"])
    attacker_directories = int(scenario["attacker_directories"])
    compromised = int(scenario["compromised_configured_directories"])
    honest = model["honest_endorsements"]
    open_weight = min(sybils, attacker_directories * model["open_directory_cap"])
    configured_total = model["configured_directories"]
    configured_attack_weight = min(compromised, configured_total)
    configured_honest_weight = configured_total - configured_attack_weight
    return {
        **scenario,
        "raw_count_attacker_fraction": fraction(sybils, honest),
        "raw_count_majority": sybils > honest,
        "open_cap_attack_weight": open_weight,
        "open_cap_attacker_fraction": fraction(open_weight, honest),
        "open_cap_majority": open_weight > honest,
        "configured_attack_weight": configured_attack_weight,
        "configured_attacker_fraction": fraction(
            configured_attack_weight, configured_honest_weight
        ),
        "configured_quorum_reached": configured_attack_weight
        >= model["configured_directory_quorum"],
    }


def analyze(model: dict[str, int] | None = None) -> dict[str, Any]:
    selected = dict(DEFAULT_MODEL if model is None else model)
    for key, value in selected.items():
        if not isinstance(value, int) or isinstance(value, bool) or value < 1:
            raise ValueError(f"{key} must be a positive integer")
    if selected["configured_directory_quorum"] > selected["configured_directories"]:
        raise ValueError("quorum cannot exceed configured directory count")
    rows = [evaluate_scenario(scenario, selected) for scenario in SCENARIOS]
    raw_majority_identities = selected["honest_endorsements"] + 1
    minimum_open_directories = (
        math.floor(selected["honest_endorsements"] / selected["open_directory_cap"]) + 1
    )
    return {
        "schema": "htmltrust-endorsement-sybil-sensitivity/v1",
        "model": selected,
        "minimum_attack_capability": {
            "raw_count_majority_identities": raw_majority_identities,
            "open_cap_majority_directories": minimum_open_directories,
            "configured_quorum_directory_compromises": selected[
                "configured_directory_quorum"
            ],
        },
        "scenarios": rows,
        "interpretation_limits": [
            "The model assigns no monetary or operational cost to an identity, directory, or compromise.",
            "The configured-directory policy inherits the user's directory selection and cannot protect a compromised quorum.",
            "Scores describe attacker weight in this model; they do not estimate real-world attack prevalence.",
        ],
    }


def render_markdown(document: dict[str, Any]) -> str:
    model = document["model"]
    capability = document["minimum_attack_capability"]
    lines = [
        "# HTMLTrust endorsement Sybil sensitivity analysis",
        "",
        f"This deterministic model starts with {model['honest_endorsements']} honest endorsements across {model['configured_directories']} user-configured directories. It compares raw signature count, an open directory score capped at {model['open_directory_cap']} endorsements per directory, and a {model['configured_directory_quorum']}-of-{model['configured_directories']} configured-directory quorum.",
        "",
        "| Attack | Sybil identities | Attacker directories | Compromised configured directories | Raw attacker share | Open-cap attacker share | Configured attacker share | Configured quorum |",
        "|---|---:|---:|---:|---:|---:|---:|---|",
    ]
    for row in document["scenarios"]:
        lines.append(
            f"| {row['name']} | {row['sybil_identities']} | {row['attacker_directories']} | {row['compromised_configured_directories']} | "
            f"{row['raw_count_attacker_fraction']:.1%} | {row['open_cap_attacker_fraction']:.1%} | "
            f"{row['configured_attacker_fraction']:.1%} | {'yes' if row['configured_quorum_reached'] else 'no'} |"
        )
    lines.extend(
        [
            "",
            "## What the model establishes",
            "",
            f"Raw counting reaches an attacker majority at {capability['raw_count_majority_identities']} identities under these assumptions. A {model['open_directory_cap']}-per-directory cap raises that threshold to control of at least {capability['open_cap_majority_directories']} open directories, but directory creation remains a Sybil surface. The configured policy ignores unconfigured directories and fails after compromise of {capability['configured_quorum_directory_compromises']} configured directories.",
            "",
            "The protocol therefore cannot assign trust from endorsement volume alone. A client policy needs an explicit configured trust root or an external identity-cost mechanism. Per-directory caps are useful only when directory admission itself resists Sybil creation.",
            "",
            "## Limits",
            "",
        ]
    )
    lines.extend(f"- {limit}" for limit in document["interpretation_limits"])
    lines.append("")
    return "\n".join(lines)


def write_csv(path: Path, document: dict[str, Any]) -> None:
    fieldnames = list(document["scenarios"][0].keys())
    with path.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(document["scenarios"])


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-csv", type=Path, required=True)
    parser.add_argument("--output-md", type=Path, required=True)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    document = analyze()
    for path in (args.output_json, args.output_csv, args.output_md):
        path.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(
        json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    write_csv(args.output_csv, document)
    args.output_md.write_text(render_markdown(document), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
