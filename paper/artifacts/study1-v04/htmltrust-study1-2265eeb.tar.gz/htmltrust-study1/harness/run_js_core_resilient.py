#!/usr/bin/env python3
"""Drive run_js_core.mjs to completion despite fatal wasm aborts on a small set
of pathological pages. Each pass filters out already-identified crashers so the
runner makes progress; the crasher of a failed pass is read from the progress
file. On success, crashers are appended as failures. Documents, rather than
hides, the wasm-binding robustness limitation.
  run_js_core_resilient.py <corpus.jsonl> <out.jsonl>
"""
import json, os, subprocess, sys, tempfile

corpus, out = sys.argv[1], sys.argv[2]
records = [json.loads(l) for l in open(corpus, encoding="utf-8") if l.strip()]
skip = set()
here = os.path.dirname(os.path.abspath(__file__))
runner = os.path.join(here, "runners", "run_js_core.mjs")

for _ in range(64):
    filt = tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False, encoding="utf-8")
    for r in records:
        if r["id"] not in skip:
            filt.write(json.dumps(r, ensure_ascii=False) + "\n")
    filt.close()
    prog = filt.name + ".prog"
    open(out, "w").close()
    rc = subprocess.run(["node", runner, filt.name, out, prog],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode
    processed = sum(1 for _ in open(out, encoding="utf-8"))
    want = len(records) - len(skip)
    os.unlink(filt.name)
    if rc == 0 and processed >= want:
        break
    crasher = ""
    if os.path.exists(prog):
        crasher = open(prog).read().strip()
        os.unlink(prog)
    if not crasher or crasher in skip:
        print(f"cannot identify crasher (rc={rc} processed={processed}/{want}); stopping", file=sys.stderr)
        break
    skip.add(crasher)
    print(f"  wasm-abort on {crasher} (skip set now {len(skip)})", file=sys.stderr)

with open(out, "a", encoding="utf-8") as f:
    for i in skip:
        f.write(json.dumps({"id": i, "ok": False, "err": "wasm-abort (wasm binding, native FFI unaffected)"}) + "\n")
print(f"js-core-resilient: {sum(1 for _ in open(out))} records, {len(skip)} wasm-aborts -> {out}")
