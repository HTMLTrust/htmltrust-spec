#!/usr/bin/env python3
"""Run parser, URL, Unicode, delimiter, and resource attacks across all ports.

The inputs come from the canonicalization repository's normative fixtures. The
evaluation records the fixture bytes and canonicalization revision, checks the
expected accept-or-reject outcome in every independent port, and requires a
single digest for every accepted case.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import tempfile
import time
from typing import Any

STUDY_ROOT = Path(__file__).resolve().parents[2]
if str(STUDY_ROOT) not in sys.path:
    sys.path.insert(0, str(STUDY_ROOT))

from harness.benchmarks.benchmark import LANGUAGES, runner_commands  # noqa: E402


SHA256_HEX_RE = re.compile(r"[0-9a-f]{64}\Z")
ERROR_CODE_RE = re.compile(r"[a-z][a-z0-9-]*\Z")
TREE_EXCLUDED_PARTS = {
    ".git",
    ".pytest_cache",
    "__pycache__",
    "coverage",
    "dist",
    "node_modules",
    "target",
    "vendor",
}


SELECTIONS: tuple[tuple[str, str, bool], ...] = (
    ("parser-differential", "conformance/fixtures/extract/parser-*.json", False),
    ("url-policy", "conformance/fixtures/extract/url-*.json", False),
    ("resource-ceiling", "conformance/fixtures/extract/resource-*.json", False),
    ("record-delimiter", "conformance/fixtures/extract/escape-at-*.json", False),
    (
        "signed-attribute",
        "conformance/fixtures/extract/signed-semantic-attributes.json",
        False,
    ),
    (
        "character-reference",
        "conformance/fixtures/extract/html-entities-*.json",
        False,
    ),
    (
        "excluded-subtree",
        "conformance/fixtures/extract/template-excluded.json",
        False,
    ),
    (
        "excluded-subtree",
        "conformance/fixtures/extract/iframe-excluded.json",
        False,
    ),
    (
        "unicode-format-control",
        "conformance/fixtures/normalize/strip-bidi-controls.json",
        True,
    ),
    (
        "unicode-format-control",
        "conformance/fixtures/normalize/strip-bom.json",
        True,
    ),
    (
        "unicode-format-control",
        "conformance/fixtures/normalize/strip-zwsp.json",
        True,
    ),
)


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def source_tree_identity(root: Path) -> dict[str, Any]:
    """Hash checked source files while excluding dependencies and outputs."""

    digest = hashlib.sha256()
    files = 0
    for path in sorted(
        candidate for candidate in root.rglob("*") if candidate.is_file()
    ):
        relative = path.relative_to(root)
        if any(part in TREE_EXCLUDED_PARTS for part in relative.parts):
            continue
        raw = path.read_bytes()
        encoded_path = relative.as_posix().encode("utf-8")
        digest.update(len(encoded_path).to_bytes(8, "big"))
        digest.update(encoded_path)
        digest.update(len(raw).to_bytes(8, "big"))
        digest.update(raw)
        files += 1
    if files == 0:
        raise ValueError(f"canonicalization source tree is empty: {root}")
    return {"sha256": digest.hexdigest(), "file_count": files}


def fixture_set_sha256(cases: list[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    for case in cases:
        identity = f"{case['source_fixture']}\0{case['source_fixture_sha256']}\n"
        digest.update(identity.encode("utf-8"))
    return digest.hexdigest()


def revision_evidence(
    study_root: Path,
    canon_root: Path,
    declared_revision: str | None,
    tree_identity: dict[str, Any],
) -> dict[str, Any]:
    """Explain whether the declared revision matches the measured source."""

    manifest_path = study_root / "vendor" / "CANON_SOURCE_TREE.json"
    vendored_root = (study_root / "vendor" / "htmltrust-canonicalization").resolve()
    if canon_root == vendored_root and manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        matched = (
            manifest.get("revision") == declared_revision
            and manifest.get("source_tree") == tree_identity
        )
        return {
            "method": "vendored-source-manifest",
            "matched": matched,
            "manifest": str(manifest_path),
        }

    top = subprocess.run(
        ["git", "-C", str(canon_root), "rev-parse", "--show-toplevel"],
        check=False,
        capture_output=True,
        text=True,
    )
    if top.returncode == 0 and Path(top.stdout.strip()).resolve() == canon_root:
        head = subprocess.run(
            ["git", "-C", str(canon_root), "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
        status = subprocess.run(
            ["git", "-C", str(canon_root), "status", "--porcelain"],
            check=True,
            capture_output=True,
            text=True,
        ).stdout
        return {
            "method": "git-head-and-clean-tree",
            "matched": head == declared_revision and not status,
            "head": head,
            "dirty": bool(status),
        }
    return {"method": "source-tree-digest-only", "matched": None}


def normalized_error_code(message: str) -> str | None:
    """Extract an exact protocol code from language prefixes and details."""

    value = message.strip()
    for prefix in ("ValueError: ", "InvalidArgumentException: "):
        if value.startswith(prefix):
            value = value[len(prefix) :]
            break
    candidate = value.split(":", 1)[0]
    return candidate if ERROR_CODE_RE.fullmatch(candidate) else None


def load_cases(canon_root: Path) -> list[dict[str, Any]]:
    """Load the explicitly selected normative fixtures in stable order."""

    canon_root = canon_root.resolve()
    cases: list[dict[str, Any]] = []
    names: set[str] = set()
    for category, pattern, wrap_as_text in SELECTIONS:
        matches = sorted(canon_root.glob(pattern))
        if not matches:
            raise ValueError(f"selection matched no fixtures: {pattern}")
        for path in matches:
            resolved = path.resolve()
            if canon_root not in resolved.parents:
                raise ValueError(f"fixture escapes canonicalization root: {path}")
            fixture = json.loads(path.read_text(encoding="utf-8"))
            name = fixture.get("name")
            raw_input = fixture.get("input")
            if not isinstance(name, str) or not name:
                raise ValueError(f"fixture has no name: {path}")
            if name in names:
                raise ValueError(f"duplicate fixture name: {name}")
            if not isinstance(raw_input, str):
                raise ValueError(f"fixture has no string input: {path}")
            names.add(name)
            repeat = fixture.get("repeat", 1)
            if not isinstance(repeat, int) or isinstance(repeat, bool) or repeat < 1:
                raise ValueError(f"fixture has invalid repeat count: {path}")
            html = raw_input * repeat
            if wrap_as_text:
                html = f"<p>{html}</p>"
            expected_error = fixture.get("error")
            if expected_error is not None and not isinstance(expected_error, str):
                raise ValueError(f"fixture has invalid error field: {path}")
            expected_canonical = fixture.get("expected")
            if expected_error is None and not isinstance(expected_canonical, str):
                raise ValueError(
                    f"accepted fixture has no canonical expected string: {path}"
                )
            if expected_error is not None and expected_canonical is not None:
                raise ValueError(
                    f"fixture supplies both expected output and error: {path}"
                )
            expected_bytes = (
                expected_canonical.encode("utf-8")
                if isinstance(expected_canonical, str)
                else None
            )
            cases.append(
                {
                    "id": name,
                    "category": category,
                    "html": html,
                    "base_url": fixture.get("baseURL"),
                    "expected": "reject" if expected_error else "accept",
                    "expected_error": expected_error,
                    "expected_canonical_sha256": (
                        hashlib.sha256(expected_bytes).hexdigest()
                        if expected_bytes is not None
                        else None
                    ),
                    "expected_canonical_bytes": (
                        len(expected_bytes) if expected_bytes is not None else None
                    ),
                    "source_fixture": str(path.relative_to(canon_root)),
                    "source_fixture_sha256": sha256_path(path),
                    "description": fixture.get("description", ""),
                }
            )
    return sorted(cases, key=lambda case: (case["category"], case["id"]))


def _write_input(path: Path, cases: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as output:
        for case in cases:
            record = {
                "id": case["id"],
                "html": case["html"],
                "base_url": case["base_url"],
            }
            output.write(
                json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n"
            )


def _read_output(path: Path, expected_ids: set[str]) -> dict[str, dict[str, Any]]:
    records: dict[str, dict[str, Any]] = {}
    with path.open(encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            if not line.strip():
                continue
            record = json.loads(line)
            record_id = record.get("id")
            if not isinstance(record_id, str) or record_id not in expected_ids:
                raise ValueError(
                    f"unexpected id on output line {line_number}: {record_id!r}"
                )
            if record_id in records:
                raise ValueError(f"duplicate output id: {record_id}")
            if record.get("ok") is True:
                digest = record.get("hash")
                if (
                    not isinstance(digest, str)
                    or SHA256_HEX_RE.fullmatch(digest) is None
                ):
                    raise ValueError(f"invalid digest for {record_id}")
                length = record.get("len")
                if (
                    not isinstance(length, int)
                    or isinstance(length, bool)
                    or length < 0
                ):
                    raise ValueError(f"invalid canonical byte length for {record_id}")
            elif record.get("ok") is False:
                if not isinstance(record.get("err"), str) or not record["err"]:
                    raise ValueError(f"invalid rejection for {record_id}")
            else:
                raise ValueError(f"invalid outcome for {record_id}")
            records[record_id] = record
    missing = expected_ids - records.keys()
    if missing:
        raise ValueError("missing output ids: " + ", ".join(sorted(missing)))
    return records


def run_port(
    language: str,
    command: list[str],
    input_path: Path,
    output_path: Path,
    expected_ids: set[str],
    environment: dict[str, str],
    timeout_seconds: float,
) -> tuple[dict[str, dict[str, Any]], float]:
    started = time.perf_counter_ns()
    completed = subprocess.run(
        command + [str(input_path), str(output_path)],
        check=False,
        capture_output=True,
        text=True,
        env=environment,
        timeout=timeout_seconds,
    )
    elapsed_ms = (time.perf_counter_ns() - started) / 1_000_000
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout).strip()[:500]
        raise RuntimeError(f"{language} runner exited {completed.returncode}: {detail}")
    return _read_output(output_path, expected_ids), elapsed_ms


def assess(
    cases: list[dict[str, Any]],
    outputs: dict[str, dict[str, dict[str, Any]]],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    results: list[dict[str, Any]] = []
    category_totals: dict[str, dict[str, int]] = {}
    outcome_passes = normative_passes = 0
    for case in cases:
        name = case["id"]
        port_results = {language: outputs[language][name] for language in LANGUAGES}
        if case["expected"] == "accept":
            expected_hash = case["expected_canonical_sha256"]
            expected_length = case["expected_canonical_bytes"]
            outcomes_match = all(
                result.get("ok") is True
                and result.get("hash") == expected_hash
                and result.get("len") == expected_length
                for result in port_results.values()
            )
            digest_consensus = outcomes_match
        else:
            expected_error = str(case["expected_error"])
            outcomes_match = all(
                result.get("ok") is False
                and normalized_error_code(str(result.get("err", ""))) == expected_error
                for result in port_results.values()
            )
            digest_consensus = True
        passed = outcomes_match and digest_consensus
        outcome_passes += int(outcomes_match)
        if case["expected"] == "accept":
            normative_passes += int(digest_consensus)
        category = category_totals.setdefault(
            case["category"], {"cases": 0, "passed": 0}
        )
        category["cases"] += 1
        category["passed"] += int(passed)
        results.append(
            {
                "id": name,
                "category": case["category"],
                "description": case["description"],
                "source_fixture": case["source_fixture"],
                "source_fixture_sha256": case["source_fixture_sha256"],
                "expected": case["expected"],
                "expected_error": case["expected_error"],
                "expected_canonical_sha256": case["expected_canonical_sha256"],
                "expected_canonical_bytes": case["expected_canonical_bytes"],
                "outcomes_match": outcomes_match,
                "digest_consensus": digest_consensus,
                "passed": passed,
                "ports": port_results,
            }
        )
    accepted = sum(case["expected"] == "accept" for case in cases)
    summary = {
        "cases": len(cases),
        "expected_acceptances": accepted,
        "expected_rejections": len(cases) - accepted,
        "outcome_conformance": outcome_passes,
        "accepted_normative_match": normative_passes,
        "all_passed": all(result["passed"] for result in results),
        "categories": category_totals,
    }
    return results, summary


def render_markdown(document: dict[str, Any]) -> str:
    summary = document["summary"]
    lines = [
        "# HTMLTrust adversarial canonicalization evaluation",
        "",
        f"Canonicalization revision: `{document['environment']['canonicalization_revision']}`",
        "",
        f"The evaluation runs {summary['cases']} selected normative parser, URL, Unicode, delimiter, signed-attribute, excluded-subtree, character-reference, and resource-ceiling fixtures through every independent language port.",
        "",
        "## Result",
        "",
        f"- Expected outcomes matched in {summary['outcome_conformance']}/{summary['cases']} cases.",
        f"- Accepted inputs matched the normative digest and byte length in every port for {summary['accepted_normative_match']}/{summary['expected_acceptances']} cases.",
        f"- Overall status: **{'pass' if summary['all_passed'] else 'fail'}**.",
        "",
        "| Category | Passed | Cases |",
        "|---|---:|---:|",
    ]
    for category, counts in sorted(summary["categories"].items()):
        lines.append(f"| {category} | {counts['passed']} | {counts['cases']} |")
    lines.extend(
        [
            "",
            "Each case records the source fixture path and SHA-256. Rejections pass only when every port returns the exact normative error code. Accepted cases pass only when every port returns the fixture's normative canonical digest and byte length.",
            "",
        ]
    )
    failures = [case for case in document["cases"] if not case["passed"]]
    if failures:
        lines.extend(["## Failures", ""])
        for case in failures:
            lines.append(f"- `{case['id']}` ({case['category']})")
        lines.append("")
    return "\n".join(lines)


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-md", type=Path, required=True)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[2]
    )
    parser.add_argument("--canon-root", type=Path)
    parser.add_argument("--timeout-seconds", type=float, default=120.0)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    if args.timeout_seconds <= 0:
        raise SystemExit("--timeout-seconds must be positive")
    root = args.root.resolve()
    canon_root = (
        args.canon_root.resolve()
        if args.canon_root
        else (root / "vendor" / "htmltrust-canonicalization").resolve()
    )
    cases = load_cases(canon_root)
    commands = runner_commands(root)
    environment = dict(os.environ)
    environment["CANON_ROOT"] = str(canon_root)
    scratch = Path(environment.get("TMPDIR") or "/var/tmp").expanduser().resolve()
    if scratch == Path("/tmp") or Path("/tmp") in scratch.parents:
        raise SystemExit("TMPDIR must not be the RAM-backed /tmp tree")
    scratch.mkdir(parents=True, exist_ok=True)
    outputs: dict[str, dict[str, dict[str, Any]]] = {}
    elapsed: dict[str, float] = {}
    with tempfile.TemporaryDirectory(
        prefix="htmltrust-adversarial-", dir=scratch
    ) as temp:
        temp_root = Path(temp)
        input_path = temp_root / "cases.jsonl"
        _write_input(input_path, cases)
        expected_ids = {case["id"] for case in cases}
        for language in LANGUAGES:
            outputs[language], elapsed[language] = run_port(
                language,
                commands[language],
                input_path,
                temp_root / f"{language}.jsonl",
                expected_ids,
                environment,
                args.timeout_seconds,
            )
    results, summary = assess(cases, outputs)
    version_path = root / "vendor" / "CANON_VERSION.txt"
    revision = (
        version_path.read_text(encoding="utf-8").splitlines()[0]
        if version_path.is_file()
        else None
    )
    tree_identity = source_tree_identity(canon_root)
    document = {
        "schema": "htmltrust-adversarial-canonicalization/v1",
        "created_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "environment": {
            "canonicalization_revision": revision,
            "canon_root": str(canon_root),
            "canonicalization_source_tree": tree_identity,
            "revision_evidence": revision_evidence(
                root, canon_root, revision, tree_identity
            ),
            "fixture_set_sha256": fixture_set_sha256(cases),
            "image_id": os.environ.get("HTMLTRUST_IMAGE_ID"),
            "platform": platform.platform(),
            "machine": platform.machine(),
            "runner_elapsed_ms": elapsed,
            "timing_note": "single process per port; recorded for audit, not a benchmark",
        },
        "summary": summary,
        "cases": results,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_md.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(
        json.dumps(document, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    args.output_md.write_text(render_markdown(document), encoding="utf-8")
    print(
        f"adversarial evaluation: {summary['outcome_conformance']}/{summary['cases']} outcomes, "
        f"{summary['accepted_normative_match']}/{summary['expected_acceptances']} accepted normative outputs",
        file=sys.stderr,
    )
    return 0 if summary["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
