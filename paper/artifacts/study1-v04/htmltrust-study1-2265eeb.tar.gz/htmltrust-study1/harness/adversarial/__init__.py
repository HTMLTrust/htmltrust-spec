"""Adversarial canonicalization evaluation."""
