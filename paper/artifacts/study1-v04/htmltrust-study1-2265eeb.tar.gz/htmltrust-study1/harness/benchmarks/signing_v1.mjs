#!/usr/bin/env node
/**
 * Reproducible HTMLTrust v1 signing benchmark.
 *
 * This measures in-process canonicalization, Ed25519 signing, and
 * Ed25519 verification path for deterministic synthetic signed-sections. It
 * is process/in-process evidence, with no browser, network, or human timing
 * claim. The generated envelope is retained only as a byte-count model for
 * protocol metadata overhead.
 */

import { createHash, createPrivateKey, createPublicKey, sign, verify } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { performance } from "node:perf_hooks";
import process from "node:process";
import { extractCanonicalText, canonicalizeClaims, buildSigningPayloadV1 } from "../../vendor/htmltrust-canonicalization/javascript/index.js";

const SIZES = [1 << 10, 10 << 10, 100 << 10, 1 << 20];
const PROFILE = "htmltrust-signature-v1";
const SCOPE = "url";
const ALGORITHM = "ed25519";
const KEYID = "https://bench.example.test/keys/study1-v1";
const DOCUMENT_URL = "https://bench.example.test/articles/deterministic";
const SIGNED_AT = "2026-08-01T00:00:00Z";
// Fixed Ed25519 key material makes signatures and byte counts reproducible.
const PRIVATE_KEY_DER = "MC4CAQAwBQYDK2VwBCIEIE4mOxNbEx46MpqNLCknlof/qRdWTdKDXJ3CoE/H5SJD";
const PUBLIC_KEY_DER = "MCowBQYDK2VwAyEA78/Nkj9VzWl1JEf06y1+UuZp2AzAqYtOgHtzwgE72SM=";

function syntheticHtml(size) {
  if (!Number.isInteger(size) || size < 1) throw new Error("size must be positive");
  const prefix = '<article data-bench="htmltrust-study1"><h1>Benchmark</h1>';
  const suffix = "</article>";
  const token = '<p class="copy">A deterministic page &amp; its URL stay stable.</p>';
  const minimum = Buffer.byteLength(prefix + suffix);
  if (size < minimum) return `<p>${"x".repeat(Math.max(0, size - 7))}</p>`.slice(0, size);
  const room = size - minimum;
  const repeats = Math.floor(room / Buffer.byteLength(token));
  const remainder = room % Buffer.byteLength(token);
  const html = prefix + token.repeat(repeats) + "x".repeat(remainder) + suffix;
  if (Buffer.byteLength(html) !== size) throw new Error(`failed to make ${size}-byte HTML`);
  return html;
}

function sha256Hex(value) {
  return createHash("sha256").update(value).digest("hex");
}

function hashCanonical(value) {
  const digest = createHash("sha256").update(value, "utf8").digest("base64").replace(/=+$/u, "");
  return `sha256:${digest}`;
}

function makeEnvelope(html, contentHash, signature) {
  return `<signed-section profile="${PROFILE}" signature-scope="${SCOPE}" keyid="${KEYID}" content-hash="${contentHash}" signature="${signature}" algorithm="${ALGORITHM}"><meta name="author" content="HTMLTrust Study"><meta name="signed-at" content="${SIGNED_AT}">${html}</signed-section>`;
}

function metadataFromSample(sample) {
  const content = Buffer.byteLength(sample.canonicalContent);
  const claims = Buffer.byteLength(sample.claims);
  const payload = Buffer.byteLength(sample.payload);
  const signature = sample.signature.length;
  const signatureB64 = Buffer.byteLength(sample.signatureB64);
  const markup = Buffer.byteLength(sample.markup);
  return {
    input_html_bytes: Buffer.byteLength(sample.html),
    canonical_content_bytes: content,
    claims_bytes: claims,
    signing_payload_bytes: payload,
    signature_bytes: signature,
    signature_base64_bytes: signatureB64,
    signed_section_markup_bytes: markup,
    markup_overhead_bytes: markup - Buffer.byteLength(sample.html),
    markup_overhead_ratio_to_input: (markup - Buffer.byteLength(sample.html)) / Buffer.byteLength(sample.html),
    content_hash: sample.contentHash,
    claims_hash: sample.claimsHash,
    signing_payload_sha256: sha256Hex(sample.payload),
  };
}

function prepare(size, privateKey, publicKey) {
  const html = syntheticHtml(size);
  const claimsObject = { author: "HTMLTrust Study", "signed-at": SIGNED_AT };
  const canonicalContent = extractCanonicalText(html);
  const claims = canonicalizeClaims(claimsObject);
  const contentHash = hashCanonical(canonicalContent);
  const claimsHash = hashCanonical(claims);
  const payload = buildSigningPayloadV1({
    contentHash,
    claimsHash,
    documentURL: DOCUMENT_URL,
    scope: SCOPE,
    keyid: KEYID,
    algorithm: ALGORITHM,
    signedAt: SIGNED_AT,
  });
  const payloadBytes = Buffer.from(payload, "utf8");
  return { html, canonicalContent, claims, contentHash, claimsHash, payload, payloadBytes };
}

function measure(size, warmups, iterations, privateKey, publicKey) {
  const warmupSamples = [];
  for (let i = 0; i < warmups; i += 1) warmupSamples.push(runOnce(size, privateKey, publicKey));
  const timings = [];
  let representative;
  for (let i = 0; i < iterations; i += 1) {
    const result = runOnce(size, privateKey, publicKey);
    representative = result.sample;
    timings.push(result.timings);
  }
  if (!representative) throw new Error("benchmark produced no sample");
  return {
    size_bytes: size,
    ...metadataFromSample(representative),
    timings_ns: timings,
    warmup_iterations: warmups,
    iterations,
  };
}

function runOnce(size, privateKey, publicKey) {
  const totalStart = process.hrtime.bigint();
  const canonStart = process.hrtime.bigint();
  const sample = prepare(size, privateKey, publicKey);
  const canonEnd = process.hrtime.bigint();
  const signStart = process.hrtime.bigint();
  const signature = sign(null, sample.payloadBytes, privateKey);
  const signEnd = process.hrtime.bigint();
  const valid = verify(null, sample.payloadBytes, publicKey, signature);
  const verifyEnd = process.hrtime.bigint();
  if (!valid) throw new Error("Ed25519 verification failed");
  // Include the actual measured signature in the retained byte-count sample.
  sample.signature = signature;
  sample.signatureB64 = signature.toString("base64").replace(/=+$/, "");
  sample.markup = makeEnvelope(sample.html, sample.contentHash, sample.signatureB64);
  return {
    sample,
    timings: {
      canonicalize_and_prepare_ns: Number(canonEnd - canonStart),
      sign_ns: Number(signEnd - signStart),
      verify_ns: Number(verifyEnd - signEnd),
      total_ns: Number(verifyEnd - totalStart),
    },
  };
}

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function percentile(values, fraction) {
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.max(0, Math.ceil(fraction * sorted.length) - 1)];
}

function summarizeTiming(row, field) {
  const values = row.timings_ns.map((timing) => timing[field]);
  return { median_ns: median(values), p95_ns: percentile(values, 0.95), samples_ns: values };
}

function markdown(document) {
  const lines = [
    "# HTMLTrust v1 signing benchmark",
    "",
    "This benchmark runs inside one pinned Node.js process. Each sample canonicalizes synthetic HTML and claims, builds the RFC 8785 signing payload, signs it with Ed25519, and verifies it with Node crypto. Process startup is excluded. It does not measure browser, network, or user-perceived performance.",
    "",
    `- Canonicalization revision: \`${document.canonicalization_revision}\``,
    `- Canonicalization source tree: \`${document.canonicalization_source_tree.sha256}\` (${document.canonicalization_source_tree.file_count} files)`,
    `- Container image: \`${document.image_id}\``,
    `- Warmups / measured iterations: ${document.warmups} / ${document.iterations}`,
    `- Fixed key: ${document.key_algorithm}, key id \`${KEYID}\``,
    "",
    "## Timing medians and metadata bytes",
    "",
    "| HTML bytes | canonical bytes | claims | payload | signature | markup | markup overhead | total median (ms) | verify median (ms) |",
    "| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
  ];
  for (const row of document.results) {
    const total = summarizeTiming(row, "total_ns");
    const verifyTiming = summarizeTiming(row, "verify_ns");
    lines.push(`| ${row.input_html_bytes.toLocaleString("en-US")} | ${row.canonical_content_bytes.toLocaleString("en-US")} | ${row.claims_bytes} | ${row.signing_payload_bytes} | ${row.signature_bytes} | ${row.signed_section_markup_bytes.toLocaleString("en-US")} | ${row.markup_overhead_bytes.toLocaleString("en-US")} (${(row.markup_overhead_ratio_to_input * 100).toFixed(2)}%) | ${(total.median_ns / 1e6).toFixed(3)} | ${(verifyTiming.median_ns / 1e6).toFixed(3)} |`);
  }
  lines.push("", "Raw per-iteration timings are retained in the JSON artifact under `timings_ns`. Byte counts describe the synthetic signed-section envelope generated by this harness.", "");
  return lines.join("\n");
}

async function main() {
  const args = new Map();
  for (let i = 2; i < process.argv.length; i += 1) {
    if (process.argv[i].startsWith("--")) args.set(process.argv[i], process.argv[++i]);
  }
  if (args.has("--help")) {
    console.log("usage: signing_v1.mjs --output FILE --markdown FILE [--warmups N] [--iterations N]");
    return;
  }
  const output = args.get("--output");
  const markdownOutput = args.get("--markdown");
  if (!output || !markdownOutput) throw new Error("--output and --markdown are required");
  const warmups = Number(args.get("--warmups") ?? 3);
  const iterations = Number(args.get("--iterations") ?? 20);
  if (!Number.isInteger(warmups) || warmups < 0 || !Number.isInteger(iterations) || iterations < 1) throw new Error("invalid warmups or iterations");
  const imageId = process.env.HTMLTRUST_IMAGE_ID;
  if (!imageId || !/^sha256:[0-9a-f]{64}$/.test(imageId)) throw new Error("HTMLTRUST_IMAGE_ID must be the immutable sha256 container image ID");
  const studyRoot = new URL("../../", import.meta.url);
  const version = (await readFile(new URL("vendor/CANON_VERSION.txt", studyRoot), "utf8")).trim().split("\n")[0];
  const sourceManifest = JSON.parse(await readFile(new URL("vendor/CANON_SOURCE_TREE.json", studyRoot), "utf8"));
  if (sourceManifest.revision !== version) throw new Error("canonicalization source manifest revision mismatch");
  const privateKey = createPrivateKey({ key: Buffer.from(PRIVATE_KEY_DER, "base64"), format: "der", type: "pkcs8" });
  const publicKey = createPublicKey({ key: Buffer.from(PUBLIC_KEY_DER, "base64"), format: "der", type: "spki" });
  const results = SIZES.map((size) => measure(size, warmups, iterations, privateKey, publicKey));
  const document = {
    schema: "htmltrust-study1-signing-benchmark-v1",
    benchmark_scope: "node_in_process_canonicalization_ed25519_sign_verify",
    canonicalization_revision: version,
    canonicalization_source_tree: sourceManifest.source_tree,
    image_id: imageId,
    node: process.version,
    key_algorithm: ALGORITHM,
    keyid: KEYID,
    document_url: DOCUMENT_URL,
    scope: SCOPE,
    signed_at: SIGNED_AT,
    warmups,
    iterations,
    sizes_bytes: SIZES,
    results,
  };
  await writeFile(output, `${JSON.stringify(document, null, 2)}\n`, "utf8");
  await writeFile(markdownOutput, `${markdown(document)}\n`, "utf8");
}

main().catch((error) => { console.error(error?.stack || error); process.exitCode = 1; });
