#!/usr/bin/env python3
"""Validate and summarize a Study 1 process benchmark JSONL file."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import statistics
import sys
from typing import Any

STUDY_ROOT = Path(__file__).resolve().parents[2]
if str(STUDY_ROOT) not in sys.path:
    sys.path.insert(0, str(STUDY_ROOT))

from harness.benchmarks.benchmark import (  # noqa: E402
    LANGUAGES,
    SIZES,
    percentile,
)


SOURCE_SCHEMA = "htmltrust-study1-canonicalization-benchmark/v1"
TIMING_SCOPE = "runner_process_including_jsonl_io_and_canonicalization"


def _integer(value: Any, name: str, minimum: int = 0) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def _finite(value: Any, name: str, minimum: float = 0.0) -> float:
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(value)
        or value < minimum
    ):
        raise ValueError(f"{name} must be finite and >= {minimum}")
    return float(value)


def validate_document(metadata: dict[str, Any], results: list[dict[str, Any]]) -> None:
    if metadata.get("schema") != SOURCE_SCHEMA:
        raise ValueError(f"unexpected metadata schema: {metadata.get('schema')!r}")
    environment = metadata.get("environment")
    if not isinstance(environment, dict):
        raise ValueError("metadata environment must be an object")
    iterations = _integer(environment.get("iterations"), "environment.iterations", 1)
    warmups = _integer(environment.get("warmups"), "environment.warmups")
    if environment.get("synthetic_sizes_bytes") != list(SIZES):
        raise ValueError("metadata synthetic size matrix does not match the study")

    for index, result in enumerate(results):
        prefix = f"result[{index}]"
        if result.get("schema") != SOURCE_SCHEMA:
            raise ValueError(f"{prefix}.schema is invalid")
        if result.get("language") not in LANGUAGES:
            raise ValueError(f"{prefix}.language is invalid")
        if not isinstance(result.get("fixture"), str) or not result["fixture"]:
            raise ValueError(f"{prefix}.fixture is invalid")
        input_size = _integer(
            result.get("input_size_bytes"), f"{prefix}.input_size_bytes", 1
        )
        input_records = _integer(
            result.get("input_records"), f"{prefix}.input_records", 1
        )
        row_iterations = _integer(result.get("iterations"), f"{prefix}.iterations", 1)
        row_warmups = _integer(
            result.get("warmup_iterations"), f"{prefix}.warmup_iterations"
        )
        if row_iterations != iterations or row_warmups != warmups:
            raise ValueError(f"{prefix} iteration settings differ from metadata")
        if result.get("timing_scope") != TIMING_SCOPE:
            raise ValueError(f"{prefix}.timing_scope is invalid")
        _finite(result.get("timeout_seconds"), f"{prefix}.timeout_seconds", 0.000001)
        times = result.get("times_ns")
        if not isinstance(times, list) or len(times) != iterations:
            raise ValueError(f"{prefix}.times_ns must contain one value per iteration")
        measured = [
            _integer(value, f"{prefix}.times_ns[{position}]", 1)
            for position, value in enumerate(times)
        ]
        median_ns = _finite(result.get("median_ns"), f"{prefix}.median_ns", 0.000001)
        p95_ns = _finite(result.get("p95_ns"), f"{prefix}.p95_ns", 0.000001)
        expected_median = float(statistics.median(measured))
        expected_p95 = percentile(measured, 0.95)
        if median_ns != expected_median or p95_ns != expected_p95:
            raise ValueError(f"{prefix} timing statistics do not match raw samples")
        throughput = _finite(
            result.get("throughput_bytes_per_second"),
            f"{prefix}.throughput_bytes_per_second",
        )
        expected_throughput = input_size * 1_000_000_000 / median_ns
        if not math.isclose(throughput, expected_throughput, rel_tol=1e-12):
            raise ValueError(
                f"{prefix} throughput does not match input size and median"
            )

        successes = _integer(result.get("success_count"), f"{prefix}.success_count")
        rejections = _integer(
            result.get("rejection_count"), f"{prefix}.rejection_count"
        )
        failures = _integer(
            result.get("runner_failure_count"), f"{prefix}.runner_failure_count"
        )
        expected_outcomes = iterations * input_records
        if successes + rejections + failures != expected_outcomes:
            raise ValueError(f"{prefix} outcome counts do not cover every input")
        for field, count in (
            ("success_count_per_iteration", successes),
            ("rejection_count_per_iteration", rejections),
            ("runner_failure_count_per_iteration", failures),
        ):
            reported = _finite(result.get(field), f"{prefix}.{field}")
            if reported != count / iterations:
                raise ValueError(f"{prefix}.{field} does not match its total")
        expected_status = "ok" if failures == 0 else "error"
        if result.get("status") != expected_status:
            raise ValueError(f"{prefix}.status does not match runner failures")
        for field in (
            "output_length_bytes",
            "output_length_mean_bytes",
            "output_length_min_bytes",
            "output_length_max_bytes",
        ):
            _finite(result.get(field), f"{prefix}.{field}")

    expected_fixtures = {f"synthetic-{size}" for size in SIZES}
    corpus_fixtures = {
        str(result.get("fixture"))
        for result in results
        if str(result.get("fixture", "")).startswith("corpus-sample-")
    }
    if len(corpus_fixtures) != 1:
        raise ValueError("expected exactly one corpus-sample fixture")
    expected_pairs = {
        (language, fixture)
        for language in LANGUAGES
        for fixture in expected_fixtures | corpus_fixtures
    }
    actual_pairs = {
        (str(result.get("language")), str(result.get("fixture"))) for result in results
    }
    if actual_pairs != expected_pairs or len(results) != len(expected_pairs):
        missing = sorted(expected_pairs - actual_pairs)
        extra = sorted(actual_pairs - expected_pairs)
        raise ValueError(
            f"incomplete benchmark matrix; missing={missing}, extra={extra}"
        )


def read_benchmark(path: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    documents = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    metadata = [
        document for document in documents if document.get("record_type") == "metadata"
    ]
    results = [
        document for document in documents if document.get("record_type") != "metadata"
    ]
    if len(metadata) != 1:
        raise ValueError(f"expected one metadata record; found {len(metadata)}")
    validate_document(metadata[0], results)
    return metadata[0], results


def summarize(
    metadata: dict[str, Any], results: list[dict[str, Any]]
) -> dict[str, Any]:
    validate_document(metadata, results)
    rows: list[dict[str, Any]] = []
    valid = True
    for result in sorted(results, key=lambda row: (row["fixture"], row["language"])):
        runner_failures = int(result.get("runner_failure_count", -1))
        status_ok = result.get("status") == "ok"
        valid = valid and runner_failures == 0 and status_ok
        rows.append(
            {
                "language": result["language"],
                "fixture": result["fixture"],
                "input_size_bytes": result["input_size_bytes"],
                "input_records": result["input_records"],
                "median_ms": result["median_ns"] / 1_000_000,
                "p95_ms": result["p95_ns"] / 1_000_000,
                "throughput_mib_s": result["throughput_bytes_per_second"] / (1 << 20),
                "accepted_per_iteration": result["success_count_per_iteration"],
                "rejected_per_iteration": result["rejection_count_per_iteration"],
                "runner_failures": runner_failures,
            }
        )
    one_mib = {
        row["language"]: row for row in rows if row["fixture"] == "synthetic-1048576"
    }
    corpus_rows = [
        result
        for result in results
        if str(result["fixture"]).startswith("corpus-sample-")
    ]
    corpus_records = {result["input_records"] for result in corpus_rows}
    if len(corpus_records) != 1:
        raise ValueError("corpus sample record count differs across ports")
    corpus_all_rejected = all(
        result["success_count"] == 0
        and result["runner_failure_count"] == 0
        and result["rejection_count"] == result["iterations"] * result["input_records"]
        for result in corpus_rows
    )
    return {
        "schema": "htmltrust-study1-benchmark-summary/v1",
        "source_schema": metadata["schema"],
        "environment": metadata["environment"],
        "matrix_complete": len(rows) == len(LANGUAGES) * (len(SIZES) + 1),
        "runner_failures": sum(row["runner_failures"] for row in rows),
        "all_runs_valid": valid,
        "iterations": metadata["environment"]["iterations"],
        "warmups": metadata["environment"]["warmups"],
        "corpus_sample_records": next(iter(corpus_records)),
        "corpus_sample_all_rejected": corpus_all_rejected,
        "one_mib_median_ms_range": {
            "minimum": min(row["median_ms"] for row in one_mib.values()),
            "maximum": max(row["median_ms"] for row in one_mib.values()),
        },
        "rows": rows,
    }


def render_markdown(summary: dict[str, Any]) -> str:
    revision = summary["environment"].get("canonicalization_revision")
    lines = [
        "# HTMLTrust canonicalization process benchmark",
        "",
        f"Canonicalization revision: `{revision}`",
        "",
        f"Each measurement starts one language runner, reads JSONL, canonicalizes and hashes the input, then writes JSONL. Medians and p95 values use {summary['iterations']} measured iterations after {summary['warmups']} warmups. They include process startup and file I/O.",
        "",
        "## One MiB synthetic region",
        "",
        "| Port | Median (ms) | p95 (ms) | Throughput (MiB/s) |",
        "|---|---:|---:|---:|",
    ]
    one_mib = [row for row in summary["rows"] if row["fixture"] == "synthetic-1048576"]
    for row in sorted(one_mib, key=lambda item: item["language"]):
        lines.append(
            f"| {row['language']} | {row['median_ms']:.1f} | {row['p95_ms']:.1f} | {row['throughput_mib_s']:.2f} |"
        )
    lines.extend(
        [
            "",
            f"All {len(summary['rows'])} matrix cells completed with {summary['runner_failures']} runner failures.",
            "",
            (
                f"The {summary['corpus_sample_records']}-record corpus sample is a rejection-path measurement because every selected record was rejected by every port. It must not be interpreted as successful canonicalization throughput."
                if summary["corpus_sample_all_rejected"]
                else f"The corpus measurement contains {summary['corpus_sample_records']} records. Per-port acceptance and rejection counts are recorded in the JSON summary."
            ),
            "",
        ]
    )
    return "\n".join(lines)


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-md", type=Path, required=True)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    metadata, results = read_benchmark(args.input)
    document = summarize(metadata, results)
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_md.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(
        json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    args.output_md.write_text(render_markdown(document), encoding="utf-8")
    return 0 if document["matrix_complete"] and document["all_runs_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
