#!/usr/bin/env python3
"""Benchmark the five Study 1 canonicalization bindings.

The study image exposes one runner per binding.  Each measured invocation is
given a JSONL input file and writes a JSONL output file.  This keeps the
benchmark independent of language-specific FFI details and makes the exact
input and output available for inspection.  Timings include runner startup,
JSONL I/O, hashing, and canonicalization; this scope is recorded in every
result instead of being presented as an in-process library microbenchmark.
"""

from __future__ import annotations

import argparse
from collections import Counter
import datetime as dt
import hashlib
import json
import math
import os
import platform
import re
import shlex
import shutil
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Iterable

SIZES: tuple[int, ...] = (1 << 10, 10 << 10, 100 << 10, 1 << 20)
LANGUAGES = ("javascript", "go", "php", "python", "rust")
SHA256_HEX_RE = re.compile(r"[0-9a-f]{64}\Z")


def synthetic_html(size: int) -> str:
    """Return deterministic, valid HTML whose UTF-8 byte length is *size*.

    The template is ASCII, so character and byte lengths are identical.  The
    repeated text has a few entities and attributes that exercise the normal
    canonicalization path while remaining independent of locale or timezone.
    """

    if size < 1:
        raise ValueError("size must be positive")
    prefix = '<article data-bench="htmltrust-study1"><h1>Benchmark</h1>'
    suffix = "</article>"
    token = '<p class="copy">A deterministic page &amp; its URL stay stable.</p>'
    minimum = len(prefix) + len(suffix)
    if size < minimum:
        # A tiny valid document is useful to callers even though the standard
        # benchmark sizes are all larger than this minimum.
        short_prefix = "<p>"
        short_suffix = "</p>"
        if size < len(short_prefix) + len(short_suffix):
            return "x" * size
        return (
            short_prefix
            + ("x" * (size - len(short_prefix) - len(short_suffix)))
            + short_suffix
        )

    room = size - minimum
    repeats, remainder = divmod(room, len(token))
    # Plain text padding remains inside the article and cannot create a partial
    # tag for small remainders.
    html = prefix + (token * repeats) + ("x" * remainder) + suffix
    assert len(html.encode("utf-8")) == size
    return html


def synthetic_record(size: int) -> dict[str, str]:
    return {
        "id": f"synthetic-{size}",
        "html": synthetic_html(size),
        "base_url": "https://bench.example.test/articles/deterministic",
    }


def _jsonl(records: Iterable[dict[str, Any]]) -> str:
    return "".join(
        json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n"
        for record in records
    )


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_corpus_sample(path: Path, limit: int) -> list[dict[str, Any]]:
    """Select the same corpus records on every machine.

    Selection is by SHA-256 of the record id (or URL), sorted by digest.  The
    corpus itself is never rewritten; only the selected records are passed to
    a runner.
    """

    if limit < 1:
        raise ValueError("corpus limit must be positive")
    selected: list[tuple[str, str, str, str, str, dict[str, Any]]] = []
    with path.open(encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"invalid JSON on corpus line {line_number}: {exc}"
                ) from exc
            if not isinstance(record, dict) or not isinstance(record.get("html"), str):
                continue
            base_url = str(record.get("base_url") or record.get("url") or "")
            source_key = record.get("id") or record.get("url")
            if source_key is None:
                stable_source = json.dumps(
                    {"html": record["html"], "base_url": base_url},
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                source_key = (
                    "content:"
                    + hashlib.sha256(stable_source.encode("utf-8")).hexdigest()
                )
            key = str(source_key)
            digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
            stable_record = json.dumps(
                record, ensure_ascii=False, sort_keys=True, separators=(",", ":")
            )
            selected.append(
                (
                    digest,
                    key,
                    record["html"],
                    base_url,
                    stable_record,
                    {"id": key, "html": record["html"], "base_url": base_url},
                )
            )
    # Include the base URL and stable source record as tie-breakers so duplicate
    # identifiers cannot make selection depend on the source file's order.
    selected.sort(key=lambda item: item[:5])
    return [record for _, _, _, _, _, record in selected[:limit]]


def percentile(values: list[int], fraction: float) -> float:
    """Nearest-rank percentile, with a documented deterministic definition."""

    if not values:
        raise ValueError("percentile requires at least one value")
    ordered = sorted(values)
    rank = max(1, math.ceil(fraction * len(ordered)))
    return float(ordered[rank - 1])


def _version(command: list[str]) -> str | None:
    try:
        result = subprocess.run(
            command, check=False, capture_output=True, text=True, timeout=5
        )
    except (OSError, subprocess.SubprocessError):
        return None
    line = (result.stdout or result.stderr).splitlines()
    return line[0].strip() if line else None


def environment_metadata(
    cargo_target_dir: Path, runners: dict[str, list[str]]
) -> dict[str, Any]:
    return {
        "timestamp_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "python": sys.version.split()[0],
        "node": _version(["node", "--version"]),
        "php": _version(["php", "--version"]),
        "go": _version(["go", "version"]),
        "rustc": _version(["rustc", "--version"]),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "cwd": str(Path.cwd()),
        "tmpdir": os.environ.get("TMPDIR", ""),
        "cargo_target_dir": str(cargo_target_dir),
        "runners": {name: command for name, command in runners.items()},
    }


def runner_commands(root: Path) -> dict[str, list[str]]:
    runner_dir = root / "harness" / "runners"
    overrides = {
        "javascript": os.environ.get("BENCH_JS_RUNNER"),
        "go": os.environ.get("BENCH_GO_RUNNER"),
        "php": os.environ.get("BENCH_PHP_RUNNER"),
        "python": os.environ.get("BENCH_PYTHON_RUNNER"),
        "rust": os.environ.get("BENCH_RUST_RUNNER"),
    }
    paths = {
        "javascript": ["node", str(runner_dir / "run_js.mjs")],
        "go": [str(runner_dir / "run_go" / "run-go")],
        "php": ["php", str(runner_dir / "run_php.php")],
        "python": [sys.executable, str(runner_dir / "run_python.py")],
        "rust": [str(runner_dir / "run_rust" / "run-rust")],
    }
    for language, override in overrides.items():
        if override:
            paths[language] = shlex.split(override)
    return paths


def _parse_output(
    path: Path, expected_ids: list[str]
) -> tuple[int, int, int, list[str], list[str]]:
    """Validate output and separate profile rejections from runner failures."""
    expected = len(expected_ids)
    if not path.is_file():
        return 0, 0, 0, [], ["runner did not create its output file"]

    records: list[dict[str, Any]] = []
    structural_errors: list[str] = []
    with path.open(encoding="utf-8") as output:
        for line_number, line in enumerate(output, 1):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError as exc:
                structural_errors.append(
                    f"invalid JSON on output line {line_number}: {exc}"
                )
                continue
            if not isinstance(record, dict):
                structural_errors.append(f"output line {line_number} is not an object")
                continue
            records.append(record)

    actual_ids = [str(record.get("id", "")) for record in records]
    if Counter(actual_ids) != Counter(expected_ids):
        structural_errors.append("runner output IDs do not match input IDs")
    if len(records) != expected:
        structural_errors.append(
            f"runner returned {len(records)} records; expected {expected}"
        )
    if structural_errors:
        return 0, 0, 0, [], structural_errors[:5]

    successes = rejections = output_length = 0
    rejection_messages: list[str] = []
    validation_errors: list[str] = []
    for record in records:
        if record.get("ok") is True:
            digest = record.get("hash")
            if not isinstance(digest, str) or SHA256_HEX_RE.fullmatch(digest) is None:
                validation_errors.append(
                    f"runner returned invalid SHA-256 digest for {record['id']}"
                )
                continue
            if "len" not in record:
                validation_errors.append(
                    f"runner omitted output length for {record['id']}"
                )
                continue
            raw_length = record["len"]
            if not isinstance(raw_length, int) or isinstance(raw_length, bool):
                validation_errors.append(
                    f"runner returned invalid output length for {record['id']}"
                )
                continue
            record_length = raw_length
            if record_length < 0:
                validation_errors.append(
                    f"runner returned negative output length for {record['id']}"
                )
                continue
            successes += 1
            output_length += record_length
        elif record.get("ok") is False and isinstance(record.get("err"), str) and record["err"]:
            rejections += 1
            rejection_messages.append(str(record["err"])[:160])
        else:
            validation_errors.append(
                f"runner returned invalid rejection record for {record.get('id', '')}"
            )
    if validation_errors:
        return 0, 0, 0, [], validation_errors[:5]
    return successes, rejections, output_length, rejection_messages[:5], []


def benchmark_case(
    language: str,
    fixture: str,
    records: list[dict[str, Any]],
    command: list[str],
    warmups: int,
    iterations: int,
    temp_root: Path,
    environment: dict[str, str],
    timeout_seconds: float = 120.0,
) -> dict[str, Any]:
    input_path = temp_root / f"{language}-{fixture.replace('/', '_')}.jsonl"
    input_path.write_text(_jsonl(records), encoding="utf-8")
    input_bytes = sum(len(str(record["html"]).encode("utf-8")) for record in records)
    successes = rejections = runner_failures = 0
    output_lengths: list[int] = []
    times_ns: list[int] = []
    rejection_messages: list[str] = []
    runner_error_messages: list[str] = []

    def once() -> None:
        nonlocal successes, rejections, runner_failures
        output_path = (
            temp_root
            / f"{language}-{fixture.replace('/', '_')}-{time.time_ns()}.out.jsonl"
        )
        started = time.perf_counter_ns()
        try:
            completed = subprocess.run(
                command + [str(input_path), str(output_path)],
                check=False,
                capture_output=True,
                text=True,
                env=environment,
                timeout=timeout_seconds,
            )
        except subprocess.TimeoutExpired:
            elapsed = time.perf_counter_ns() - started
            runner_failures += len(records)
            runner_error_messages.append(
                f"runner timed out after {timeout_seconds:g} seconds"
            )
            times_ns.append(elapsed)
            output_path.unlink(missing_ok=True)
            return
        elapsed = time.perf_counter_ns() - started
        if completed.returncode != 0:
            count = len(records)
            runner_failures += count
            runner_error_messages.append(
                (completed.stderr or f"runner exited {completed.returncode}")[:160]
            )
        else:
            ok, rejected, length, rejected_messages, validation_errors = _parse_output(
                output_path,
                [str(record["id"]) for record in records],
            )
            successes += ok
            rejections += rejected
            if validation_errors:
                runner_failures += len(records)
                runner_error_messages.extend(validation_errors)
            else:
                output_lengths.append(length)
                rejection_messages.extend(rejected_messages)
        times_ns.append(elapsed)
        output_path.unlink(missing_ok=True)

    for _ in range(warmups):
        once()
    # Warmups are excluded from all reported counts and timing statistics.
    successes = rejections = runner_failures = 0
    output_lengths.clear()
    times_ns.clear()
    rejection_messages.clear()
    runner_error_messages.clear()
    for _ in range(iterations):
        once()

    median_ns = float(statistics.median(times_ns))
    p95_ns = percentile(times_ns, 0.95)
    successful_runs = max(1, len(output_lengths))
    median_output = int(statistics.median(output_lengths)) if output_lengths else 0
    return {
        "schema": "htmltrust-study1-canonicalization-benchmark/v1",
        "language": language,
        "fixture": fixture,
        "input_size_bytes": input_bytes,
        "input_records": len(records),
        "warmup_iterations": warmups,
        "iterations": iterations,
        "timing_scope": "runner_process_including_jsonl_io_and_canonicalization",
        "timeout_seconds": timeout_seconds,
        "times_ns": times_ns,
        "median_ns": median_ns,
        "p95_ns": p95_ns,
        "throughput_bytes_per_second": (input_bytes * 1_000_000_000 / median_ns)
        if median_ns
        else 0.0,
        "success_count": successes,
        "rejection_count": rejections,
        "runner_failure_count": runner_failures,
        "success_count_per_iteration": successes / iterations,
        "rejection_count_per_iteration": rejections / iterations,
        "runner_failure_count_per_iteration": runner_failures / iterations,
        "output_length_bytes": median_output,
        "output_length_mean_bytes": (sum(output_lengths) / successful_runs)
        if output_lengths
        else 0.0,
        "output_length_min_bytes": min(output_lengths) if output_lengths else 0,
        "output_length_max_bytes": max(output_lengths) if output_lengths else 0,
        "rejections": rejection_messages[:5],
        "runner_errors": runner_error_messages[:5],
        "command": command,
        "status": "ok" if runner_failures == 0 else "error",
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="JSONL result path")
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parents[2],
        help="study1 root",
    )
    parser.add_argument("--warmups", type=int, default=2)
    parser.add_argument("--iterations", type=int, default=10)
    parser.add_argument(
        "--language", choices=LANGUAGES, action="append", dest="languages"
    )
    parser.add_argument("--corpus", type=Path, help="optional corpus.jsonl")
    parser.add_argument("--corpus-limit", type=int, default=8)
    parser.add_argument("--timeout-seconds", type=float, default=120.0)
    parser.add_argument(
        "--keep-inputs", action="store_true", help="retain generated input files"
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    if args.warmups < 0 or args.iterations < 1 or args.timeout_seconds <= 0:
        raise SystemExit(
            "--warmups must be >= 0, --iterations must be >= 1, and --timeout-seconds must be positive"
        )
    raw_tmpdir = os.environ.get("TMPDIR") or "/var/tmp"
    tmp_root = Path(raw_tmpdir).expanduser().resolve()
    if tmp_root == Path("/tmp") or Path("/tmp") in tmp_root.parents:
        raise SystemExit("TMPDIR must not be the RAM-backed /tmp tree")
    tmp_root.mkdir(parents=True, exist_ok=True)
    target = Path(
        os.environ.get(
            "CARGO_TARGET_DIR", str(tmp_root / f"cargo-target-{os.getpid()}")
        )
    )
    target.mkdir(parents=True, exist_ok=True)
    commands = runner_commands(args.root)
    languages = args.languages or list(LANGUAGES)
    missing = [
        name
        for name in languages
        if name not in commands
        or (len(commands[name]) > 1 and shutil.which(commands[name][0]) is None)
        or (len(commands[name]) == 1 and not Path(commands[name][0]).exists())
    ]
    if missing:
        raise SystemExit("runner unavailable: " + ", ".join(missing))

    fixtures: list[tuple[str, list[dict[str, Any]]]] = [
        (f"synthetic-{size}", [synthetic_record(size)]) for size in SIZES
    ]
    if args.corpus:
        fixtures.append(
            (
                f"corpus-sample-{args.corpus_limit}",
                read_corpus_sample(args.corpus, args.corpus_limit),
            )
        )
    environment = dict(os.environ)
    environment["TMPDIR"] = str(tmp_root)
    environment["CARGO_TARGET_DIR"] = str(target)
    # Pin the interpreted bindings to the same vendored snapshot used by the
    # image, even when this script is run from a host checkout.
    environment.setdefault(
        "CANON_ROOT", str(args.root / "vendor" / "htmltrust-canonicalization")
    )
    run_environment = environment_metadata(target, commands)
    run_environment["tmpdir"] = str(tmp_root)
    run_environment["canon_root"] = environment["CANON_ROOT"]
    run_environment["corpus"] = str(args.corpus) if args.corpus else None
    corpus_digest = sha256_path(args.corpus) if args.corpus else None
    run_environment["corpus_sha256"] = corpus_digest
    if args.corpus:
        manifest_path = args.corpus.with_name(args.corpus.stem + ".manifest.json")
        run_environment["corpus_manifest"] = (
            str(manifest_path) if manifest_path.is_file() else None
        )
        run_environment["corpus_manifest_sha256"] = (
            sha256_path(manifest_path) if manifest_path.is_file() else None
        )
        if manifest_path.is_file():
            corpus_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            declared_digest = corpus_manifest.get("corpus_sha256")
            if declared_digest != corpus_digest:
                raise SystemExit(
                    "corpus manifest hash mismatch: "
                    f"declared={declared_digest!r} actual={corpus_digest!r}"
                )
            run_environment["corpus_manifest_status"] = "verified"
        else:
            run_environment["corpus_manifest_status"] = "missing"
    else:
        run_environment["corpus_manifest"] = None
        run_environment["corpus_manifest_sha256"] = None
        run_environment["corpus_manifest_status"] = "not-applicable"
    run_environment["warmups"] = args.warmups
    run_environment["iterations"] = args.iterations
    run_environment["timeout_seconds"] = args.timeout_seconds
    run_environment["synthetic_sizes_bytes"] = list(SIZES)
    version_path = args.root / "vendor" / "CANON_VERSION.txt"
    run_environment["canonicalization_revision"] = (
        version_path.read_text(encoding="utf-8").splitlines()[0]
        if version_path.is_file()
        else None
    )
    toolchains_path = args.root / "TOOLCHAINS.txt"
    run_environment["toolchains"] = (
        toolchains_path.read_text(encoding="utf-8").splitlines()
        if toolchains_path.is_file()
        else []
    )
    run_environment["image_id"] = os.environ.get("HTMLTRUST_IMAGE_ID")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    failed = False
    with tempfile.TemporaryDirectory(
        prefix="htmltrust-bench-", dir=tmp_root
    ) as temp_dir:
        temp_root = Path(temp_dir)
        with args.output.open("w", encoding="utf-8") as output:
            header = {
                "schema": "htmltrust-study1-canonicalization-benchmark/v1",
                "record_type": "metadata",
                "environment": run_environment,
            }
            output.write(json.dumps(header, sort_keys=True) + "\n")
            for language in languages:
                for fixture, records in fixtures:
                    if not records:
                        continue
                    result = benchmark_case(
                        language,
                        fixture,
                        records,
                        commands[language],
                        args.warmups,
                        args.iterations,
                        temp_root,
                        environment,
                        args.timeout_seconds,
                    )
                    output.write(json.dumps(result, sort_keys=True) + "\n")
                    output.flush()
                    failed = failed or result["status"] != "ok"
                    print(
                        f"{language} {fixture}: {result['status']} median={result['median_ns']:.0f}ns",
                        file=sys.stderr,
                    )
        if args.keep_inputs:
            keep = args.output.parent / (args.output.stem + "-inputs")
            if keep.exists():
                raise SystemExit(
                    f"refusing to overwrite existing input directory: {keep}"
                )
            shutil.copytree(temp_root, keep)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
