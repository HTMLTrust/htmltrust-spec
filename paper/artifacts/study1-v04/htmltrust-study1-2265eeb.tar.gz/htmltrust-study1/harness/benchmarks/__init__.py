"""Reproducible Study 1 canonicalization benchmarks."""
