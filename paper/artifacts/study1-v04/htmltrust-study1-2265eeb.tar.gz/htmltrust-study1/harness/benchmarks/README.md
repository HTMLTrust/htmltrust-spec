# Canonicalization benchmark harness

`benchmark.py` measures the five pinned Study 1 runners on deterministic HTML
inputs of exactly 1 KiB, 10 KiB, 100 KiB, and 1 MiB. It writes one metadata
record followed by one result record per language and fixture to JSONL.

Run it in the Study 1 image from `/work/htmltrust-study1`:

```sh
export TMPDIR="$HOME/tmp"
python3 harness/benchmarks/benchmark.py \
  --output /data/runs/htmltrust-study1-benchmark.jsonl \
  --warmups 3 --iterations 20
```

From the host checkout, the equivalent Compose invocation is:

```sh
docker compose run --rm --entrypoint python3 study1-analyze \
  /work/htmltrust-study1/harness/benchmarks/benchmark.py \
  --output /data/runs/htmltrust-study1-benchmark.jsonl \
  --warmups 3 --iterations 20
```

The image contains the Go and Rust runner binaries built from `vendor/`.
JavaScript, PHP, and Python use the corresponding scripts in
`harness/runners/`. Set `BENCH_*_RUNNER` to override a runner when testing a
different build. A corpus sample can be added with
`--corpus /path/to/corpus.jsonl --corpus-limit 8`; selection is the lowest
SHA-256 digests of stable record ids, so it does not depend on file order.
The runtime image omits the Go and Rust compilers, so their live-command fields
in benchmark metadata are null. `TOOLCHAINS.txt` records the build-stage Go and
Rust versions used for the runner binaries.

Each timing includes process startup, JSONL I/O, hashing, and canonicalization.
The result records include the raw timings, nearest-rank median and p95,
throughput based on input HTML bytes, accepted and rejected record counts,
runner-failure counts, canonical output length, command, and environment
metadata. A portable-profile rejection is a valid canonicalizer result. A
successful runner record must include a lowercase 64-character SHA-256 digest
in its `hash` field. Timeouts, nonzero process exits, missing records, and
malformed output fail the benchmark. This scope avoids implying that the
process-level measurements are browser or UX data.

The harness uses `TMPDIR` and places its unique default `CARGO_TARGET_DIR`
below that directory. Set `TMPDIR` to a disk-backed absolute path before a host
run. The container defaults to `/var/tmp`. Use
`--keep-inputs` to preserve the exact generated JSONL inputs beside the result
file for audit.
