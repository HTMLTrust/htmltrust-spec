# HTMLTrust Study 1 v0.3 evidence

This directory contains the compact evidence snapshot used by the HTMLTrust
paper. The run analyzed 4,846 Common Crawl News response-body regions with
canonicalization revision
`12bc7e839d5e2a858c29bba651e704e8ed036d95`.

## Result summary

| E1 configuration | Accepted by all bindings | Matching digests among jointly accepted regions | Accept-or-reject agreement |
|---|---:|---:|---:|
| Independent language ports | 121/4,846 | 119/121 (98.3%) | 4,777/4,846 (98.6%) |
| Shared Rust core adapters | 174/4,846 | 174/174 (100.0%) | 4,846/4,846 (100.0%) |

The digest percentages are conditional on every binding accepting the region.
The corresponding full-corpus digest-agreement counts are 119/4,846 for the
independent ports and 174/4,846 for the shared core. The observed pages were
not authored for HTMLTrust, so the low acceptance rate describes the strict
v1 profile's applicability to this sample.

E2 used the 121 regions accepted by the independent Python port. Python
`html.parser` re-serialization preserved 121/121 hashes. lxml re-serialization
caused 121/121 transformed inputs to be rejected by preflight. Intertag
whitespace insertion preserved 89/121 hashes. These are source-level probes;
they do not establish rendered semantic equivalence.

## Evidence map

- [`independent/results.md`](independent/results.md) is the generated E1 and E2
  report for the five independent ports.
- [`shared-core/results.md`](shared-core/results.md) is the corresponding report
  for adapters using the shared Rust core.
- Each result directory includes machine-readable statistics, taxonomy,
  stability measurements, a run manifest, binding mode, and process timing.
- [`benchmark.jsonl`](benchmark.jsonl) contains 25 process-level measurements:
  five bindings over four synthetic sizes and an eight-record corpus sample.
  Every runner completed; the corpus sample records valid profile rejections
  separately from runner failures.
- [`corpus.manifest.json`](corpus.manifest.json) records the five WARC names and
  hashes, selection parameters, skip counts, and corpus digest.
- [`TOOLCHAINS.txt`](TOOLCHAINS.txt), [`CANON_VERSION.txt`](CANON_VERSION.txt),
  and [`BENCHMARK_IMAGE_ID.txt`](BENCHMARK_IMAGE_ID.txt) identify the build.

The archived container image ID is
`sha256:2cea8d3af40cf4815ff7f38693901cd554e271ef374b5cb0704827182db626aa`.
The corpus SHA-256 is
`8c6831bece6f45f25622cf011ac1fcf45d1fcda36f14b8e111566317c12c7f92`.

## Verify or reproduce

Verify every compact evidence file:

```sh
cd results/v03
sha256sum -c SHA256SUMS
```

The checksum list excludes itself. Raw corpus and per-record runner JSONL files
are excluded from Git. To regenerate them, follow the root README and run:

```sh
make image
make test
make analyze
make analyze-core
WARMUPS=3 ITERATIONS=20 CORPUS_LIMIT=8 make benchmark
```

The run manifests explain the timing scope. Benchmark medians include process
startup, JSONL input and output, and canonicalization; they are not in-process
library-call timings.
