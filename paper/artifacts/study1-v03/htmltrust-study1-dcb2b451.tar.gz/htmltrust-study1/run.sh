#!/usr/bin/env bash
# Study 1 orchestrator (runs inside the pinned Docker image).
#   run.sh corpus    # build corpus.jsonl from mounted WARCs (needs WARC_DIR)
#   run.sh analyze   # run all 5 canonicalizers + E1 stats/taxonomy + E2 stability
#   run.sh benchmark # process-level benchmarks for all five implementations
#   run.sh all       # corpus then analyze
set -euo pipefail
HERE=/work/htmltrust-study1
export CANON_ROOT="${CANON_ROOT:-$HERE/vendor/htmltrust-canonicalization}"
export PYTHONPATH="$CANON_ROOT/python:${PYTHONPATH:-}"
MODE="${1:-all}"
CORPUS="${CORPUS:-/data/corpus/corpus.jsonl}"
OUT="${OUT:-/data/runs}"
LANGS=(python js go rust php)
case "$MODE" in
  analyze|benchmark|all)
    : "${HTMLTRUST_IMAGE_ID:?set HTMLTRUST_IMAGE_ID to the immutable container image ID}"
    ;;
esac
# Set CORE_LANGS to a space-separated subset of LANGS (or "all") to exercise
# the v0.3 Rust core bindings. The default remains the five independent ports,
# which is the Study 1 E1 baseline. CORE=1 is a shorthand for CORE_LANGS=all.
CORE_LANGS="${CORE_LANGS:-}"
if [[ "${CORE:-0}" == "1" && -z "$CORE_LANGS" ]]; then CORE_LANGS=all; fi
HTMLTRUST_CANON_SO="${HTMLTRUST_CANON_SO:-$HERE/lib/libhtmltrust_canonicalization_ffi.so}"
HTMLTRUST_WASM_PKG="${HTMLTRUST_WASM_PKG:-$HERE/wasm/htmltrust_canonicalization_ffi.js}"
export HTMLTRUST_CANON_SO HTMLTRUST_WASM_PKG
mkdir -p "$(dirname "$CORPUS")" "$OUT" "$OUT/dump"

build_corpus() {
  python3 "$HERE/harness/build_corpus.py" \
    --warc-dir "${WARC_DIR:?set WARC_DIR (mount CC-NEWS WARCs)}" \
    --warc-limit "${WARC_LIMIT:-3}" --target "${TARGET:-10000}" \
    --stride "${STRIDE:-17}" --residue "${RESIDUE:-0}" --region "${REGION:-body}" \
    --out "$CORPUS"
}

run_lang() { # <lang> <corpus> <out> [--dump]
  local l="$1" c="$2" o="$3" d="${4:-}"
  local -a extra=()
  [[ "$d" == "--dump" ]] && extra+=(--dump)
  local timing_label="$l"
  [[ "$d" == "--dump" ]] && timing_label+="-dump"
  local use_core=0
  [[ "$CORE_LANGS" == "all" || " $CORE_LANGS " == *" $l "* ]] && use_core=1
  case "$l:$use_core" in
    python:0) time_run "$timing_label" python3 "$HERE/harness/runners/run_python.py" "$c" "$o" "${extra[@]}" ;;
    python:1) time_run "$timing_label" python3 "$HERE/harness/runners/run_python_core.py" "$c" "$o" "${extra[@]}" ;;
    js:0)     time_run "$timing_label" node "$HERE/harness/runners/run_js.mjs" "$c" "$o" "${extra[@]}" ;;
    js:1)     time_run "$timing_label" "$HERE/harness/runners/run_js_core_batch.sh" "$c" "$o" "${extra[@]}" ;;
    go:0)     time_run "$timing_label" "$HERE/harness/runners/run_go/run-go" "$c" "$o" "${extra[@]}" ;;
    go:1)     time_run "$timing_label" "$HERE/harness/runners/run_go_core/run-go-core" "$c" "$o" "${extra[@]}" ;;
    rust:*)  time_run "$timing_label" "$HERE/harness/runners/run_rust/run-rust" "$c" "$o" "${extra[@]}" ;;
    php:0)    time_run "$timing_label" php "$HERE/harness/runners/run_php.php" "$c" "$o" "${extra[@]}" ;;
    php:1)    time_run "$timing_label" php "$HERE/harness/runners/run_php_core.php" "$c" "$o" "${extra[@]}" ;;
    *) echo "unknown language: $l" >&2; return 2 ;;
  esac
}

time_run() {
  local label="$1"; shift
  if [[ -x /usr/bin/time ]]; then
    /usr/bin/time -f $'elapsed_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' \
      -o "$OUT/time-${label}.txt" "$@"
  else
    "$@"
  fi
}

analyze() {
  # Keep the runtime and input identity alongside every result set. This is
  # intentionally in /data, outside the repository and corpus source tree.
  cp "$HERE/vendor/CANON_VERSION.txt" "$OUT/CANON_VERSION.txt"
  [[ -f "$HERE/TOOLCHAINS.txt" ]] && cp "$HERE/TOOLCHAINS.txt" "$OUT/TOOLCHAINS.txt"
  corpus_manifest="${CORPUS%.jsonl}.manifest.json"
  [[ -f "$corpus_manifest" ]] && cp "$corpus_manifest" "$OUT/corpus.manifest.json"
  if [[ -n "$CORE_LANGS" ]]; then
    printf 'shared Rust core: %s\n' "$CORE_LANGS" > "$OUT/BINDING_MODE.txt"
  else
    printf 'independent language implementations\n' > "$OUT/BINDING_MODE.txt"
  fi
  {
    printf 'corpus_path=%s\n' "$CORPUS"
    if command -v sha256sum >/dev/null 2>&1; then
      sha256sum "$CORPUS"
    else
      shasum -a 256 "$CORPUS"
    fi
  } > "$OUT/corpus.sha256"
  python3 - "$OUT/run.manifest.json" "$MODE" "$CORE_LANGS" "$HTMLTRUST_IMAGE_ID" \
    "$HERE/vendor/CANON_VERSION.txt" "$HERE/TOOLCHAINS.txt" "$OUT/corpus.sha256" \
    "$corpus_manifest" <<'PY'
import datetime
import hashlib
import json
import pathlib
import sys

output, mode, core_languages, image_id, revision_path, toolchains_path, corpus_hash_path, corpus_manifest_path = sys.argv[1:]
hash_lines = pathlib.Path(corpus_hash_path).read_text(encoding="utf-8").splitlines()
actual_hash = None
for line in hash_lines:
    parts = line.split()
    if parts and len(parts[0]) == 64 and all(char in "0123456789abcdef" for char in parts[0]):
        actual_hash = parts[0]
        break
if actual_hash is None:
    raise SystemExit("could not read the computed corpus SHA-256")

manifest_path = pathlib.Path(corpus_manifest_path)
manifest_status = "missing"
declared_hash = None
manifest_hash = None
if manifest_path.is_file():
    manifest_bytes = manifest_path.read_bytes()
    manifest_hash = hashlib.sha256(manifest_bytes).hexdigest()
    corpus_manifest = json.loads(manifest_bytes)
    declared_hash = corpus_manifest.get("corpus_sha256")
    if declared_hash != actual_hash:
        raise SystemExit(
            f"corpus manifest hash mismatch: declared={declared_hash!r} actual={actual_hash!r}"
        )
    manifest_status = "verified"
manifest = {
    "schema": "htmltrust-study1-run-manifest/v1",
    "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "mode": mode,
    "languages": ["python", "js", "go", "rust", "php"],
    "e1_binding_mode": "shared-rust-core" if core_languages else "independent-ports",
    "e1_core_languages": (
        core_languages.split()
        if core_languages and core_languages != "all"
        else (["python", "js", "go", "rust", "php"] if core_languages == "all" else [])
    ),
    "e2_binding": "python-independent-port",
    "image_id": image_id,
    "canonicalization_revision": pathlib.Path(revision_path).read_text(encoding="utf-8").splitlines()[0],
    "toolchains": pathlib.Path(toolchains_path).read_text(encoding="utf-8").splitlines(),
    "corpus_sha256": actual_hash,
    "corpus_manifest_sha256": manifest_hash,
    "corpus_manifest_declared_corpus_sha256": declared_hash,
    "corpus_manifest_status": manifest_status,
    "runner_timing": {
        "clock": "GNU time elapsed wall clock",
        "units": "seconds and KiB",
        "scope": "one process over the full corpus, including JSONL input, canonicalization, hashing, and JSONL output",
    },
}
pathlib.Path(output).write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
PY
  echo ">> E1: canonicalize with all five implementations"
  for l in "${LANGS[@]}"; do run_lang "$l" "$CORPUS" "$OUT/$l.jsonl"; done
  echo ">> E1: cross-implementation agreement"
  python3 "$HERE/harness/analyze.py" stats "$OUT" "${LANGS[@]}" --corpus "$CORPUS"
  echo ">> E1: dumping disagreement subset for taxonomy"
  python3 - "$CORPUS" "$OUT/disagree.ids" "$OUT/disagree.jsonl" <<'PY'
import sys, json
ids = set(open(sys.argv[2]).read().split())
with open(sys.argv[3], "w") as f:
    for line in open(sys.argv[1]):
        if line.strip() and json.loads(line)["id"] in ids:
            f.write(line)
PY
  for l in "${LANGS[@]}"; do
    run_lang "$l" "$OUT/disagree.jsonl" "$OUT/dump/$l.jsonl" --dump
  done
  echo ">> E1: disagreement taxonomy (vs rust reference)"
  python3 "$HERE/harness/analyze.py" taxonomy "$OUT" rust "${LANGS[@]}"
  echo ">> E2: canonicalization sensitivity to publishing transformations"
  python3 "$HERE/harness/stability.py" "$CORPUS" "$OUT/stability.json"
  echo ">> assembling results.md"
  python3 "$HERE/harness/analyze.py" report "$OUT" "${LANGS[@]}"
  echo ">> done. results in $OUT/results.md"
}

benchmark() {
  [[ -f "$CORPUS" ]] || { echo "corpus not found: $CORPUS" >&2; return 2; }
  python3 "$HERE/harness/benchmarks/benchmark.py" \
    --output "$OUT/benchmark.jsonl" \
    --corpus "$CORPUS" \
    --corpus-limit "${CORPUS_LIMIT:-8}" \
    --warmups "${WARMUPS:-3}" \
    --iterations "${ITERATIONS:-20}"
  printf '%s\n' "$HTMLTRUST_IMAGE_ID" > "$OUT/BENCHMARK_IMAGE_ID.txt"
}

case "$MODE" in
  corpus)  build_corpus ;;
  analyze) analyze ;;
  benchmark) benchmark ;;
  all)     build_corpus; analyze ;;
  *) echo "usage: run.sh {corpus|analyze|benchmark|all}"; exit 2 ;;
esac
