# HTMLTrust Study 1

Runnable Docker harness for measuring HTMLTrust canonicalization against real
HTML. The current workflow is v0.3. The older result files in this checkout
describe v0.2 and remain as historical records.

| Field | Value |
|---|---|
| Status | Runnable research artifact with a checked-in v0.3 evidence snapshot |
| Primary readers | Researchers reproducing or reviewing the study |
| Inputs | Common Crawl CC-NEWS WARC files |
| Runtime | Docker Engine with Docker Compose |

## Current result

The final v0.3 run analyzed 4,846 Common Crawl News response-body regions.
Among the 121 regions accepted by all five independent ports, 119 produced the
same digest (98.3% conditional agreement). The ports agreed on accept-or-reject
status for 4,777/4,846 regions (98.6%). When every language adapter used the
shared Rust core, status agreement was 4,846/4,846 and all 174 jointly accepted
regions produced matching digests.

Read [`results/v03/README.md`](results/v03/README.md) for the result boundaries,
provenance, machine-readable evidence, and reproduction commands. The corpus
and raw per-record outputs remain outside Git because the corpus is 1.2 GB.

## Start here

Place the study and canonicalization checkouts beside each other. This study
checkout currently has no configured Git remote, so this document does not
claim a public clone URL for it.

```sh
cd htmltrust-study1
git clone https://github.com/HTMLTrust/htmltrust-canonicalization.git \
  ../htmltrust-canonicalization
```

The default `CANON_REPO=../htmltrust-canonicalization` is optional. `make prep`
uses that checkout when it contains the exact revision in
`vendor/CANON_VERSION.txt`; otherwise it fetches that revision from
`CANON_URL`. It archives the revision into `vendor/`, so uncommitted files in a
sibling checkout do not affect a run.

Set a disk-backed directory for generated data. The harness rejects host
`/tmp`, because the corpus and result files can be large:

```sh
export STUDY1_DATA="$HOME/tmp/htmltrust-study1/v03"
export WARC_MOUNT=/absolute/path/to/cc-news-warcs
```

Run the complete workflow:

```sh
make preflight
make image
make test
make all
```

`make all` prepares the vendored canonicalization revision, checks the paths,
reuses or rebuilds the Docker image, creates the corpus, and runs the
independent five-language analysis. The separate `make image` above makes the
image available for the test step; the later build is normally served from
Docker's cache. The corpus and results are written below `$STUDY1_DATA`.

## Commands

Run these commands from the repository root.

| Command | What it does | Input or output |
|---|---|---|
| `make preflight` | Checks the WARC mount and data path | Requires `WARC_MOUNT` |
| `make prep` | Archives the exact canonicalization revision into `vendor/` | Uses `CANON_REPO` or `CANON_URL` |
| `make image` | Builds the pinned multi-language image | Requires Docker Compose |
| `make test` | Runs the harness unit tests in the analysis image | Build `make image` first |
| `make corpus` | Streams WARCs and writes `corpus/corpus.jsonl` plus its manifest | Requires `WARC_MOUNT` |
| `make analyze` | Runs independent Python, JavaScript, Go, Rust, and PHP bindings, E1, and E2 | Requires an existing corpus and image |
| `make analyze-core` | Repeats E1 through the shared Rust core adapters | Writes `runs-core/` |
| `make benchmark` | Runs the process-level benchmark | Defaults to 3 warmups, 20 iterations, 8 records |
| `make clean` | Removes `runs/` and `runs-core/` only | Keeps the corpus and manifests |

Useful overrides include `WARC_LIMIT`, `TARGET`, `STRIDE`, `RESIDUE`, and
`REGION` for corpus construction. Benchmark overrides are `WARMUPS`,
`ITERATIONS`, and `CORPUS_LIMIT`. For example:

```sh
WARC_LIMIT=5 TARGET=10000 make corpus
make analyze
make analyze-core
WARMUPS=3 ITERATIONS=20 CORPUS_LIMIT=8 make benchmark
```

To analyze an existing corpus, set `STUDY1_DATA` to the directory containing
`corpus/corpus.jsonl`, build the image, and run `make analyze`. This path does
not need `WARC_MOUNT`.

## What the study measures

E1 sends the same raw HTML body region to five bindings and compares canonical
output hashes. It records success, pairwise agreement, all-binding agreement,
failure reasons, and a disagreement taxonomy.

E2 applies source-level transformations and compares canonical hashes. These
transformations are byte-level perturbations of the signing input. The harness
does not guarantee that every transformation preserves rendered meaning. In
particular, whitespace changes can alter text content even when they look like
formatting changes.

Common Crawl provides server responses. The study does not measure scripts that
mutate a live DOM after page load.

## Corpus scope and reproducibility

The strict v0.3 operational sample uses the first five explicitly recorded
Common Crawl News WARC files selected by the run configuration. The corpus
manifest records the source filenames and SHA-256 hashes, along with the
sampling parameters and corpus hash. It also counts records whose unknown
declared charset was decoded with the UTF-8 fallback, and each corpus record
retains both `declared_charset` and the charset actually used for decoding.
Corpus IDs are the first 16 hexadecimal characters of the URL's SHA-1 digest;
the builder rejects a collision between distinct URLs. This corpus is a
reproducible operational sample for this study. It is not a uniform sample of
the web, Common Crawl, or all news publishers, so results should not be
generalized beyond that scope.

The Docker image records language runtimes, package versions, the vendored
canonicalization revision, and its image identifier in each run. Base images
are pinned by digest. Debian and NodeSource package repositories and language
package registries remain mutable, so a future rebuild is not guaranteed to
produce identical layers. Retain or export the exact image named in the run
manifest when byte-for-byte environment recovery matters.

The Makefile passes the host user and group IDs into Compose. Corpus and result
files therefore remain writable by the user who started the run on Linux.

## Repository map

```text
harness/build_corpus.py       WARC to deterministic JSONL corpus
harness/runners/               independent and shared-core runners
harness/analyze.py             E1 statistics, taxonomy, and report
harness/stability.py           E2 source-transformation analysis
harness/benchmarks/            process-level benchmark
harness/tests/                 harness unit tests
results/v03/                   compact final evidence and provenance
vendor/                       pinned canonicalization source snapshot
Dockerfile / docker-compose.yml / Makefile
                              build and run the study
run.sh                        in-container workflow
```

## Historical documents

The following files contain v0.2 measurements and notebook notes. They are
useful for understanding the earlier baseline and fixes, but they are not the
v0.3 result set and should not be cited as current output:

- [`RESULTS.md`](RESULTS.md), the v0.2 narrative report
- [`results.baseline.md`](results.baseline.md), the pre-fix v0.2 measurement
- [`results.postfix.md`](results.postfix.md), the post-fix v0.2 measurement
- [`notebook/NOTEBOOK.md`](notebook/NOTEBOOK.md), the v0.2 round notebook

Current raw run output is generated under `$STUDY1_DATA/runs/` or
`$STUDY1_DATA/runs-core/`. Keep the corpus and per-record JSONL outputs outside
the Git repository. The compact final snapshot is under `results/v03/`.
