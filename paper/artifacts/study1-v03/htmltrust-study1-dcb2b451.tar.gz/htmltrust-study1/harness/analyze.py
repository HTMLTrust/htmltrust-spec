#!/usr/bin/env python3
"""Study 1 analyzer.

Usage:
  analyze.py stats    <run_dir> <langs...> --corpus <corpus.jsonl>
                                                       # E1 stats -> stats.json, disagree.ids
  analyze.py taxonomy <run_dir> <ref_lang> <langs...> # categorize dumps -> taxonomy.json
  analyze.py report   <run_dir> <langs...>            # merge -> results.json + results.md

Run outputs live in <run_dir>: <lang>.jsonl (hash mode) and dump/<lang>.jsonl
(dump mode, disagreement subset only).
"""

from __future__ import annotations
import json
import sys
import itertools
import re
from pathlib import Path
from collections import Counter


def load(p, result_mode="hash"):
    d = {}
    with open(p, encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            if line.strip():
                r = json.loads(line)
                record_id = r.get("id")
                if not isinstance(record_id, str) or not record_id:
                    raise ValueError(f"{p}:{line_number}: missing string id")
                if record_id in d:
                    raise ValueError(f"{p}:{line_number}: duplicate id {record_id!r}")
                ok = r.get("ok")
                if not isinstance(ok, bool):
                    raise ValueError(f"{p}:{line_number}: ok must be boolean")
                if ok and result_mode == "hash":
                    digest = r.get("hash")
                    length = r.get("len")
                    if (
                        not isinstance(digest, str)
                        or re.fullmatch(r"[0-9a-f]{64}", digest) is None
                    ):
                        raise ValueError(f"{p}:{line_number}: invalid SHA-256 hash")
                    if (
                        not isinstance(length, int)
                        or isinstance(length, bool)
                        or length < 0
                    ):
                        raise ValueError(f"{p}:{line_number}: invalid output length")
                elif ok and result_mode == "dump":
                    if not isinstance(r.get("canon"), str):
                        raise ValueError(f"{p}:{line_number}: missing canonical text")
                elif not isinstance(r.get("err"), str) or not r["err"]:
                    raise ValueError(f"{p}:{line_number}: missing error string")
                d[record_id] = r
    return d


def load_corpus_ids(path):
    ids = []
    seen = set()
    with open(path, encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            if not line.strip():
                continue
            record = json.loads(line)
            record_id = record.get("id")
            if not isinstance(record_id, str) or not record_id:
                raise ValueError(f"{path}:{line_number}: missing string id")
            if record_id in seen:
                raise ValueError(f"{path}:{line_number}: duplicate id {record_id!r}")
            seen.add(record_id)
            ids.append(record_id)
    return sorted(ids)


def load_expected_ids(path):
    ids = []
    seen = set()
    with open(path, encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            record_id = line.strip()
            if not record_id:
                continue
            if record_id in seen:
                raise ValueError(f"{path}:{line_number}: duplicate id {record_id!r}")
            seen.add(record_id)
            ids.append(record_id)
    return sorted(ids)


URL_SCHEME_RE = re.compile(r"@attr:[a-z0-9-]+:(?:href|src):([a-z][a-z0-9+.-]*):", re.I)
ATTR_LINE_RE = re.compile(r"@attr:[a-z0-9-]+:(href|src|alt|aria-label):")


def classify_diff(ref: str, other: str) -> str:
    """Bucket the first meaningful difference between two canonical strings."""
    if ref == other:
        return "identical"
    ra, oa = ref.split("\n"), other.split("\n")
    # find first differing line index
    i = 0
    for i, (a, b) in enumerate(zip(ra, oa)):
        if a != b:
            break
    else:
        # one is a prefix of the other -> extra trailing content
        return "content-length"
    a = ra[i] if i < len(ra) else ""
    b = oa[i] if i < len(oa) else ""
    # attribute-record differences
    am, bm = ATTR_LINE_RE.match(a), ATTR_LINE_RE.match(b)
    if am or bm:
        sm = URL_SCHEME_RE.match(a) or URL_SCHEME_RE.match(b)
        if sm and sm.group(1).lower() not in ("http", "https"):
            return "url-scheme"
        if (am and am.group(1) in ("href", "src")) or (
            bm and bm.group(1) in ("href", "src")
        ):
            return "url-serialization"
        return "attr-other"
    # one side has an attr line the other doesn't (structural: attr present/absent)
    if a.startswith("@attr:") != b.startswith("@attr:"):
        return "attr-presence"
    # entity-related: one side still has a raw entity
    entity_pattern = r"&[a-zA-Z#][a-zA-Z0-9]*;"
    if set(re.findall(entity_pattern, a)) != set(re.findall(entity_pattern, b)):
        return "entity"
    # whitespace-only difference on this line
    if re.sub(r"\s+", "", a) == re.sub(r"\s+", "", b):
        return "whitespace"
    # different number of lines overall -> structural (implied tags / block boundaries)
    if len(ra) != len(oa):
        return "structure"
    return "text-other"


def cmd_stats(run_dir, langs, corpus=None):
    if not langs:
        raise ValueError("stats requires at least one language")
    rd = Path(run_dir)
    data = {language: load(rd / f"{language}.jsonl") for language in langs}
    if corpus is not None:
        ids = load_corpus_ids(corpus)
        id_source = str(corpus)
    else:
        ids = sorted(data[langs[0]])
        id_source = f"runner:{langs[0]}"
    if not ids:
        raise ValueError(f"no records found in {id_source}")
    expected_ids = set(ids)
    for language in langs:
        actual_ids = set(data[language])
        if actual_ids != expected_ids:
            missing = sorted(expected_ids - actual_ids)
            extra = sorted(actual_ids - expected_ids)
            raise ValueError(
                f"{language} output IDs do not match {id_source}: "
                f"{len(missing)} missing, {len(extra)} extra; "
                f"examples missing={missing[:3]} extra={extra[:3]}"
            )
    stats = {
        "n": len(ids),
        "langs": langs,
        "id_validation": {"validated": True, "source": id_source},
        "ok_rate": {},
        "error_types": {},
    }
    for language in langs:
        ok = [record_id for record_id in ids if data[language][record_id]["ok"]]
        stats["ok_rate"][language] = len(ok) / len(ids)
        errs = Counter(
            data[language][record_id]["err"].split(":")[0]
            for record_id in ids
            if not data[language][record_id]["ok"]
        )
        # also break out attribute-canonicalization-failed etc by message
        messages = Counter(
            data[language][record_id]["err"]
            for record_id in ids
            if not data[language][record_id]["ok"]
        )
        stats["error_types"][language] = {
            "by_type": dict(errs.most_common()),
            "by_msg": dict(messages.most_common(6)),
        }
    all_ok = [
        record_id
        for record_id in ids
        if all(data[language][record_id]["ok"] for language in langs)
    ]
    agree = [
        record_id
        for record_id in all_ok
        if len({data[language][record_id]["hash"] for language in langs}) == 1
    ]
    status_agree = [
        record_id
        for record_id in ids
        if len({data[language][record_id]["ok"] for language in langs}) == 1
    ]
    stats["all_ok"] = len(all_ok)
    stats["all_ok_rate"] = len(all_ok) / max(len(ids), 1)
    stats["all_agree"] = len(agree)
    stats["all_agree_rate"] = len(agree) / len(all_ok) if all_ok else None
    stats["all_agree_corpus_rate"] = len(agree) / max(len(ids), 1)
    stats["status_agree"] = len(status_agree)
    stats["status_agree_rate"] = len(status_agree) / max(len(ids), 1)
    stats["pairwise"] = {}
    for a, b in itertools.combinations(langs, 2):
        both = [
            record_id
            for record_id in ids
            if data[a][record_id]["ok"] and data[b][record_id]["ok"]
        ]
        matching = sum(
            1
            for record_id in both
            if data[a][record_id]["hash"] == data[b][record_id]["hash"]
        )
        stats["pairwise"][f"{a}-{b}"] = {
            "both_ok": len(both),
            "both_ok_rate": len(both) / len(ids),
            "agree": matching,
            "rate": matching / len(both) if both else None,
            "agree_corpus_rate": matching / len(ids),
        }
    # disagreement ids: all-ok but not identical, OR ok-status differs
    disagree = [
        record_id
        for record_id in ids
        if (
            all(data[language][record_id]["ok"] for language in langs)
            and len({data[language][record_id]["hash"] for language in langs}) > 1
        )
        or len({data[language][record_id]["ok"] for language in langs}) > 1
    ]
    (rd / "disagree.ids").write_text("\n".join(disagree) + "\n")
    (rd / "stats.json").write_text(json.dumps(stats, indent=2) + "\n")
    print(
        json.dumps(
            {
                k: stats[k]
                for k in ("n", "ok_rate", "all_ok", "all_agree", "all_agree_rate")
            },
            indent=2,
        )
    )
    print(f"disagreement ids: {len(disagree)} -> {rd / 'disagree.ids'}")


def cmd_taxonomy(run_dir, ref_lang, langs):
    rd = Path(run_dir)
    all_langs = list(dict.fromkeys([ref_lang, *langs]))
    dumps = {
        language: load(rd / "dump" / f"{language}.jsonl", result_mode="dump")
        for language in all_langs
    }
    expected_ids = set(load_expected_ids(rd / "disagree.ids"))
    for language in all_langs:
        actual_ids = set(dumps[language])
        if actual_ids != expected_ids:
            missing = sorted(expected_ids - actual_ids)
            extra = sorted(actual_ids - expected_ids)
            raise ValueError(
                f"{language} dump IDs do not match disagree.ids: "
                f"{len(missing)} missing, {len(extra)} extra; "
                f"examples missing={missing[:3]} extra={extra[:3]}"
            )
    ref = dumps[ref_lang]
    tax = {language: Counter() for language in langs if language != ref_lang}
    for record_id, reference_record in ref.items():
        for language in langs:
            if language == ref_lang:
                continue
            other_record = dumps[language].get(record_id)
            if other_record is None:
                continue
            if reference_record["ok"] and other_record["ok"]:
                category = classify_diff(
                    reference_record["canon"], other_record["canon"]
                )
                tax[language][category] += 1
            elif reference_record["ok"] != other_record["ok"]:
                tax[language]["ok-status-divergence"] += 1
    out = {language: dict(counts.most_common()) for language, counts in tax.items()}
    (rd / "taxonomy.json").write_text(
        json.dumps({"reference": ref_lang, "vs_reference": out}, indent=2) + "\n"
    )
    print(json.dumps({"reference": ref_lang, "vs_reference": out}, indent=2))


def _pct(x):
    if x is None:
        return "N/A"
    return f"{x * 100:.1f}%"


def cmd_report(run_dir, langs):
    rd = Path(run_dir)
    stats = json.loads((rd / "stats.json").read_text())
    if stats.get("langs") != langs:
        raise ValueError(
            f"report languages {langs!r} do not match stats languages {stats.get('langs')!r}"
        )
    tax = (
        json.loads((rd / "taxonomy.json").read_text())
        if (rd / "taxonomy.json").exists()
        else None
    )
    stab = (
        json.loads((rd / "stability.json").read_text())
        if (rd / "stability.json").exists()
        else None
    )
    binding_mode = (
        (rd / "BINDING_MODE.txt").read_text(encoding="utf-8").strip()
        if (rd / "BINDING_MODE.txt").exists()
        else "unspecified"
    )
    revision = (
        (rd / "CANON_VERSION.txt").read_text(encoding="utf-8").splitlines()[0]
        if (rd / "CANON_VERSION.txt").exists()
        else "unknown"
    )
    corpus_hash = "unknown"
    if (rd / "corpus.sha256").exists():
        for line in (rd / "corpus.sha256").read_text(encoding="utf-8").splitlines():
            candidate = line.split()[0] if line.split() else ""
            if re.fullmatch(r"[0-9a-f]{64}", candidate):
                corpus_hash = candidate
                break
    L = []
    implementation_label = f"All {len(langs)} implementations"
    L.append("# HTMLTrust Study 1 results\n")
    L.append(
        f"Corpus: **{stats['n']}** real news-article body regions (Common Crawl CC-NEWS). "
        f"Implementations: {', '.join(langs)}.\n"
    )
    L.append(
        f"E1 binding mode: **{binding_mode}**. Canonicalization revision: `{revision}`. "
        f"Corpus SHA-256: `{corpus_hash}`.\n"
    )
    L.append("## E1: Cross-implementation canonicalization on real HTML\n")
    L.append(
        "### Per-implementation success rate (fraction of pages that canonicalize without error)\n"
    )
    L.append("| implementation | success rate |")
    L.append("|---|---|")
    for language in langs:
        L.append(f"| {language} | {_pct(stats['ok_rate'][language])} |")
    L.append("")
    L.append(
        f"{implementation_label} accepted **{stats['all_ok']}/{stats['n']}** pages "
        f"({_pct(stats['all_ok_rate'])}). Of those accepted pages, "
        f"**{stats['all_agree']}/{stats['all_ok']}** produced matching SHA-256 digests "
        f"({_pct(stats['all_agree_rate'])}). This is **{_pct(stats['all_agree_corpus_rate'])}** "
        "of the full corpus.\n"
    )
    L.append(
        f"{implementation_label} agreed on accept-or-reject status for "
        f"**{stats['status_agree']}/{stats['n']}** "
        f"pages ({_pct(stats['status_agree_rate'])}).\n"
    )
    L.append(
        "### Pairwise matching digests among pages both implementations accepted\n"
    )
    L.append(
        "| pair | both accepted | accepted coverage | matching digest | conditional agreement | corpus agreement |"
    )
    L.append("|---|---:|---:|---:|---:|---:|")
    for k, v in stats["pairwise"].items():
        L.append(
            f"| {k} | {v['both_ok']} | {_pct(v['both_ok_rate'])} | {v['agree']} | "
            f"{_pct(v['rate'])} | {_pct(v['agree_corpus_rate'])} |"
        )
    L.append("")
    L.append("### Failure reasons\n")
    for language in langs:
        errors = stats["error_types"][language]["by_msg"]
        if errors:
            L.append(
                f"- **{language}**: "
                + "; ".join(
                    f"`{message}` ×{count}" for message, count in errors.items()
                )
            )
    L.append("")
    if tax:
        cats = sorted({c for values in tax["vs_reference"].values() for c in values})
        L.append(
            f"### Disagreement taxonomy (each implementation vs the `{tax['reference']}` reference)\n"
        )
        if cats:
            L.append(
                "Counts of disagreeing records bucketed by the first meaningful difference.\n"
            )
            L.append("| category | " + " | ".join(tax["vs_reference"].keys()) + " |")
            L.append("|---" * (len(tax["vs_reference"]) + 1) + "|")
            for category in cats:
                L.append(
                    f"| {category} | "
                    + " | ".join(
                        str(tax["vs_reference"][language].get(category, 0))
                        for language in tax["vs_reference"]
                    )
                    + " |"
                )
        else:
            L.append("No cross-implementation disagreements were observed.\n")
        L.append("")
    if stab:
        L.append("## E2: Python-binding sensitivity to publishing transformations\n")
        page_word = "page" if stab["n_canonicalizable"] == 1 else "pages"
        L.append(
            f"Measured on {stab['n_canonicalizable']} {page_word} accepted by the Python binding. "
            "The measurements report byte-level signature stability. They do not establish "
            "that every transformation preserves rendered meaning.\n"
        )
        L.append(
            "| transformation | attempted | evaluated | transform failed | rejected after transform | hash changed | preserved | preservation rate |"
        )
        L.append("|---|---:|---:|---:|---:|---:|---:|---:|")
        for name, v in stab["transforms"].items():
            L.append(
                f"| {name} | {v.get('attempted', v['tested'])} | {v['tested']} | "
                f"{v.get('transform_failed', 0)} | {v.get('rejected', 0)} | "
                f"{v.get('hash_changed', v['tested'] - v['preserved'])} | {v['preserved']} | "
                f"{_pct(v['preservation_rate'])} |"
            )
        L.append("")
    (rd / "results.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "stats":
        args = sys.argv[2:]
        corpus = None
        if "--corpus" in args:
            option_index = args.index("--corpus")
            try:
                corpus = args[option_index + 1]
            except IndexError as exc:
                raise SystemExit("--corpus requires a path") from exc
            del args[option_index : option_index + 2]
        cmd_stats(args[0], args[1:], corpus)
    elif cmd == "taxonomy":
        cmd_taxonomy(sys.argv[2], sys.argv[3], sys.argv[4:])
    elif cmd == "report":
        cmd_report(sys.argv[2], sys.argv[3:])
    else:
        print("unknown command", file=sys.stderr)
        sys.exit(2)
