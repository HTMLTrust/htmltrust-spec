// Rust canonicalization runner for Study 1.
//   run-rust <corpus.jsonl> <out.jsonl> [--dump]
use htmltrust_canonicalization::try_extract_canonical_text_with_base_url as extract;
use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::io::{BufRead, BufReader, BufWriter, Write};

#[derive(Deserialize)]
struct InRec {
    id: String,
    html: String,
    #[serde(default)]
    base_url: String,
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 3 {
        eprintln!("usage: run-rust <corpus> <out> [--dump]");
        std::process::exit(2);
    }
    let dump = args[3..].iter().any(|a| a == "--dump");
    let fin = std::fs::File::open(&args[1]).expect("open corpus");
    let fout = std::fs::File::create(&args[2]).expect("create out");
    let reader = BufReader::with_capacity(1 << 20, fin);
    let mut w = BufWriter::with_capacity(1 << 20, fout);

    let mut n = 0usize;
    for line in reader.lines() {
        let line = match line {
            Ok(l) => l,
            Err(_) => break,
        };
        if line.trim().is_empty() {
            continue;
        }
        let r: InRec = match serde_json::from_str(&line) {
            Ok(r) => r,
            Err(_) => continue,
        };
        let base = if r.base_url.is_empty() { None } else { Some(r.base_url.as_str()) };
        let out = match extract(&r.html, base) {
            Ok(canon) => {
                if dump {
                    serde_json::json!({"id": r.id, "ok": true, "canon": canon})
                } else {
                    let mut h = Sha256::new();
                    h.update(canon.as_bytes());
                    let hash = hex(&h.finalize());
                    serde_json::json!({"id": r.id, "ok": true, "hash": hash, "len": canon.as_bytes().len()})
                }
            }
            Err(e) => {
                let mut e = e;
                e.truncate(160);
                serde_json::json!({"id": r.id, "ok": false, "err": e})
            }
        };
        writeln!(w, "{}", out).ok();
        n += 1;
    }
    w.flush().ok();
    eprintln!("rust: {} records -> {}", n, args[2]);
}

fn hex(bytes: &[u8]) -> String {
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push_str(&format!("{:02x}", b));
    }
    s
}
